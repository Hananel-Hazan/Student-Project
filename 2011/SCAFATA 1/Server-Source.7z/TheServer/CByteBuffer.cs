﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Globalization;
using System.Threading;
using System.Collections;

namespace TheServer
{
    // this class implament data-struct buffer, enable read and write simultaniously
    class CByteBuffer
    {
        // list of byte[], contain all the data
        List<byte[]> m_pData;

        // constructor
        public CByteBuffer()
        {
            // initialize all members
            m_pData = new List<byte[]>();
        }

        // get byte[] data
        // write the data to the buffer
        public void WriteToBuffer(byte[] pData)
        {
            // add data to end of list 
            m_pData.Add(pData);
        }

        // return all the data in the buffer as byte[]
        // ( while this function is ruuning, more elements could be added to the list
        //   those elemenst will return in the next activation of the function )
        public byte[] ReadFromBuffer()
        {
            // get number of elements (byte[]) in list 
            int iNumberOfElements = m_pData.Count;
            
            // sum all the elements size
            int iDataSize = 0;
            for (int i = 0; i < iNumberOfElements; i++)
            {
                if (m_pData.ElementAt(i) != null)
                {
                    iDataSize = iDataSize + m_pData.ElementAt(i).Length;
                }
            }

            // go over all elements and copy them to the return value
            byte[] pData = new byte[iDataSize + 1]; // return value
            int iEndIndex = 0; // indicate where the last copy ended, where this copy should start
            for (int j = 0; j < iNumberOfElements; j++)
            {
                if (m_pData.ElementAt(j) != null)
                {
                    Buffer.BlockCopy(m_pData.ElementAt(j), 0, pData, iEndIndex, m_pData.ElementAt(j).Length);
                    iEndIndex = iEndIndex + m_pData.ElementAt(j).Length; // update where last copy ended
                }
            }

            // remove from list all the elmenets that have been copyed
            if (!IsEmpty()) { m_pData.RemoveRange(0, iNumberOfElements); }

            return pData;
        }

        // return true if list is empty, false if not
        public bool IsEmpty()
        {
            if (m_pData.Count == 0) { return true; }
            return false;
        }

        // some test for writing while reading
        public void TestWrite()
        {
            int i = 0;
            while (true)
            {
                WriteToBuffer(System.Text.Encoding.ASCII.GetBytes(i.ToString() + " "));
                i++;
                if (i >= 5000) { i = 0; }
            }
        }

        // some test for writing while reading 
        public void TestRead()
        {
            while (true)
            {
                if (!IsEmpty())
                {
                    Console.Write(System.Text.Encoding.ASCII.GetString(ReadFromBuffer()));
                }
            }
        }
    }
}
