﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Net.Security;
using System.Threading;

namespace TheServer
{
    // struct that contain all client information
    struct SClientDeTailes
    {
        public bool bIsActive;              // is client active
        public string sName;                // client name
        public string sPassword;            // client password
        public bool bInRelationship;        // is client in relationship with another client
        public int iFriendId;               // client relationship friend id
        public bool bHaveDataForTransfer;   // is there any data to send to this client
        public byte[] pDataForTransfer;     // data to send for this client
    }

    // this class is the main class for the server, handles all server ability
    class CServer
    {
        bool m_pIsRunning;                      // is the server active
        HttpListener m_pServer;                 // the http server
        SClientDeTailes[] m_pClients;           // DB - data base that contain all clients
        string[] m_sClientCommunicatorUris;     // communicators URI - URI to listen to specific client 
        /* m_pClients[i] communicate with server with URI m_sClientCommunicatorUris[i] */ 
               
        // constructor - empty                               
        public CServer() { }

        // init all class members
        void MembersInitializtion()
        {
            // creating new http server, and adding the listening URI
            m_pServer = new HttpListener();
            m_pServer.Prefixes.Add(CConst.MAIN_URI_);
            m_pIsRunning = false;

            // init client DB by reseting all clients
            m_pClients = new SClientDeTailes[CConst.SUPPORTS_CLIENTS_COUNT_];
            for (int i = 0; i < CConst.SUPPORTS_CLIENTS_COUNT_; i++) { ResetClient(i); }

            // init all the URI 
            m_sClientCommunicatorUris = new string[CConst.SUPPORTS_CLIENTS_COUNT_];
            for (int i = 0; i < CConst.SUPPORTS_CLIENTS_COUNT_; i++)
            {
                m_sClientCommunicatorUris[i] = CConst.SECONDARY_URI_ + i.ToString() + "/";
            }
        }

        // get client id
        // init in DB this client id
        void ResetClient(int Clientid)
        {
                bool WasAcvite = m_pClients[Clientid].bIsActive;
                m_pClients[Clientid].bIsActive = false;
                m_pClients[Clientid].sName = null;
                m_pClients[Clientid].sPassword = null;
                m_pClients[Clientid].bInRelationship = false;
                m_pClients[Clientid].iFriendId = CConst.NULL_INT_;
                m_pClients[Clientid].bHaveDataForTransfer = false;
                m_pClients[Clientid].pDataForTransfer = null;

                // if client was active, notify all over clients that client-list changed
                if (WasAcvite)
                {
                    NotifyClientListChanges();
                    Console.WriteLine("Clinet Left server");
                }
        }
        
        // return the name of all active clients that is not in relationship
        string GetClientList()
        {
            try
            {
                string sClientList = null;  
                // go over all DB and add the name of fitting clients
                for (int i = 0; i < CConst.SUPPORTS_CLIENTS_COUNT_; i++){
                    if( (m_pClients[i].bIsActive) && (!m_pClients[i].bInRelationship) && (m_pClients[i].sName != null) ){ 
                        sClientList = sClientList + m_pClients[i].sName + "\r\n";}}
                if (sClientList == null) { return "ClientListIsEmpty"; }
                return sClientList;
            }
            catch { return null; } // return null when failed
        }

        // update the DataForTransfer member of all active not in relationship clients with client-list
        void NotifyClientListChanges()
        {
            try
            {
                // get client list
                string sClientList = GetClientList();
                if (sClientList != null)
                {
                    // go over DB send the client-list to the active non-relationship clients
                    byte[] bClientList = CParsing.String2Byte(sClientList);
                    for (int i = 0; i < CConst.SUPPORTS_CLIENTS_COUNT_; i++)
                    {
                        if ((m_pClients[i].bIsActive) && (!m_pClients[i].bInRelationship))
                        {
                            m_pClients[i].pDataForTransfer = bClientList;
                            m_pClients[i].bHaveDataForTransfer = true;
                        }
                    }
                }
                else { Console.WriteLine("GetClientList faild"); }
            }
            catch { Console.WriteLine("NotifyClientListChanges faild"); }
        }

        // get 2 clients id
        // remove clients from DB and notify them
        void StopRelationship(int iClientId, int iFriendId)
        {
            try
            {
                m_pClients[iFriendId].pDataForTransfer = CParsing.String2Byte(CConst.MASG_DISSCONECTED_);
                m_pClients[iFriendId].bHaveDataForTransfer = true;
                Thread.Sleep(1000); // make shure the disconnect message was sent befrom removing form DB
                m_pClients[iFriendId].bIsActive = false;
                m_pClients[iClientId].bIsActive = false;
            }
            catch { m_pClients[iFriendId].bIsActive = false; m_pClients[iClientId].bIsActive = false; }
            /* when failes - change the clients to not active - they will be sent to ResetClient */
        }

        // get Context with forwording request, and the client-id that sent the request
        // handle the forwording request, and send response
        bool HundleForwordingRequest(HttpListenerContext pContext,int iClientId)
        {
            try
            {
                // get freind-id
                int iFriendId = m_pClients[iClientId].iFriendId;
                
                // get request data from context
                byte[] pRequest = CHundleHTTP.GetRequest(pContext);
                string sRequest = CParsing.Byte2String(pRequest);
                
                // if request is empty do nothing
                if (sRequest == CConst.MASG_DEMI_MASG_) { }
                //if request is disconect , end relationship client-id and frined-id 
                else if (sRequest == CConst.MASG_DISSCONECTED_)
                {
                    StopRelationship(iClientId, iFriendId);
                    return false;
                }
                else // the request has data to forword, update friend member dataToTransfer with data
                {
                    m_pClients[iFriendId].pDataForTransfer = pRequest;
                    m_pClients[iFriendId].bHaveDataForTransfer = true;
                }

                // if the client have dataToTransfer, send this data with the response, else send empty response
                if (m_pClients[iClientId].bHaveDataForTransfer)
                {
                    CHundleHTTP.SendResponse(pContext, m_pClients[iClientId].pDataForTransfer);
                    m_pClients[iClientId].pDataForTransfer = null;
                    m_pClients[iClientId].bHaveDataForTransfer = false;
                }
                else { CHundleHTTP.SendResponse(pContext, CParsing.String2Byte(CConst.MASG_DEMI_MASG_)); }
             
                return true;
            }
            catch { StopRelationship(iClientId, m_pClients[iClientId].iFriendId); return false; }
            /* when fails stop the relation ship of the client and his friend */
        }

        // get client name
        // if the client is in DB and active and not in relationship return his ID else return null
        int GetClientId(string sName)
        {
            try
            {
                int iClientId = CConst.NULL_INT_;
                for (int i = 0; i < CConst.SUPPORTS_CLIENTS_COUNT_; i++)
                {
                    if ((m_pClients[i].bIsActive) && (!m_pClients[i].bInRelationship) && (m_pClients[i].sName != null))
                    {
                        if (m_pClients[i].sName == sName)
                        {
                            iClientId = i;
                        }
                    }
                }
                return iClientId;
            }
            catch { return CConst.NULL_INT_; }
        }

        // get Context with relationship request, and the client-id that sent the request
        // handle the forwording request, and send response
        // return const null-int if request denied , return friend-id request aproved
        int HundleRelationShipRequest(HttpListenerContext pContext,int iClientId)
        {
            try
            {
                // default return null-int request denied 
                int iFriendId = CConst.NULL_INT_;

                //  get request data from context
                byte[] pRequest = CHundleHTTP.GetRequest(pContext);
                string sRequest = CParsing.Byte2String(pRequest);
                switch (sRequest)
                {
                    // if request is empty 
                    case CConst.MASG_DEMI_MASG_: 
                        // check if have dataToTransfer: yes- send data with response, no- sent empty response
                        if (m_pClients[iClientId].bHaveDataForTransfer)
                        {
                            CHundleHTTP.SendResponse(pContext, m_pClients[iClientId].pDataForTransfer);
                            m_pClients[iClientId].pDataForTransfer = null;
                            m_pClients[iClientId].bHaveDataForTransfer = false;
                        }
                        else { CHundleHTTP.SendResponse(pContext, CParsing.String2Byte(CConst.MASG_DEMI_MASG_)); }
                        break;
                    // if request is disconnected, deActive client - send disconect response
                    case CConst.MASG_DISSCONECTED_:
                        m_pClients[iClientId].bIsActive = false;
                        CHundleHTTP.SendResponse(pContext, CParsing.String2Byte(CConst.MASG_DISSCONECTED_));
                        break;
                    // request is relationship request - name and pass word
                    default:
                        // get name and password from the request
                        string sName = CParsing.DecodeName(pRequest);
                        string sPassword = CParsing.DecodePassword(pRequest);
                        if (sName == null) // no name send error name in response
                        { CHundleHTTP.SendResponse(pContext, CParsing.String2Byte(CConst.MASG_NO_CLIENT_NAME_)); break; }
                        if (sPassword == null) // no password send error password in response
                        { CHundleHTTP.SendResponse(pContext, CParsing.String2Byte(CConst.MASG_WRONG_PASSORD_)); break; }
                        iFriendId = GetClientId(sName); // get the friend id by name (return it mean aproved request)
                        if (iFriendId == CConst.NULL_INT_) // no client with that name send error name in response
                        { CHundleHTTP.SendResponse(pContext, CParsing.String2Byte(CConst.MASG_NO_CLIENT_NAME_)); break; }
                        // if name and pass dosent mach - return int-null send response with error password
                        if (m_pClients[iFriendId].sPassword != sPassword) 
                        {
                            CHundleHTTP.SendResponse(pContext, CParsing.String2Byte(CConst.MASG_WRONG_PASSORD_));
                            iFriendId = CConst.NULL_INT_;
                            break;
                        }
                        // passed all verifications , send respons with start relationship 
                        CHundleHTTP.SendResponse(pContext, CParsing.String2Byte(CConst.MASG_IN_RELATIONSHIP_));
                        break;
                }
                return iFriendId; //return const null-int if request denied , return friend-id request aproved
            }
            catch { m_pClients[iClientId].bIsActive = false; return CConst.NULL_INT_; }
            /*  when fails stop the deActive client return const null-int  */
        }

        // get comuniccator-id as object (specific URI to listen to) ,new thread activation
        // endless loop that gets and handles request from specific client 
        void StartClientCommunicator(object CommunicatorId)
        {
            try
            {
                // start http server and listen on the input URI
                int iCommunicatorId = (int)CommunicatorId;
                Console.WriteLine("comunicator " + iCommunicatorId.ToString() + " started");
                HttpListener pServer = new HttpListener();
                pServer.Prefixes.Add(m_sClientCommunicatorUris[iCommunicatorId]);
                pServer.Start();
                HttpListenerContext pContext;

                // as long as client is active, receive requests and handles them
                int ifriendId;
                while (m_pClients[iCommunicatorId].bIsActive)
                {
                    pContext = pServer.GetContext(); // get context from client
                    
                    // if client is in relationship, handle the request as forwording request
                    if (m_pClients[iCommunicatorId].bInRelationship)
                    {
                        HundleForwordingRequest(pContext, iCommunicatorId);
                    }
                    else // if client is not in relationship, handle the request as relationship request
                    {
                        ifriendId = HundleRelationShipRequest(pContext, iCommunicatorId);
                        // if friend-id is not null - the request aproved
                        if (ifriendId != CConst.NULL_INT_)
                        {
                            // update friend dataForTransfer member with relationship start message 
                            m_pClients[ifriendId].pDataForTransfer = CParsing.String2Byte(CConst.MASG_IN_RELATIONSHIP_);
                            m_pClients[ifriendId].bHaveDataForTransfer = true;
                            
                            // update DB with the start of new relationship
                            m_pClients[iCommunicatorId].bInRelationship = true;
                            m_pClients[iCommunicatorId].iFriendId = ifriendId;
                            m_pClients[ifriendId].iFriendId = iCommunicatorId;
                            m_pClients[ifriendId].bInRelationship = true;
                            Console.WriteLine(m_pClients[iCommunicatorId].sName +" is in relationship with "+ m_pClients[ifriendId].sName);
                        }
                    }
                }
                // client is inActive close this comunicator remove from DB notify all other clients
                Console.WriteLine("Client with Id " + iCommunicatorId + " was deleted");
                pServer.Close();
                ResetClient(iCommunicatorId);
                NotifyClientListChanges();
            }
            catch { ResetClient((int)CommunicatorId); m_pServer.Stop(); NotifyClientListChanges(); }
            /*when fails, remove client from DB, notify all clients, close server */
        }

        // get name register request
        // return if verifed client-id (also the private URI to communicate with server)
        //        if not verifid a message why faild
        string VerifyNameRegistery(string sName, int iClientId)
        {
            try
            {
                // for all clients name DB if name allready exist return error
                for(int i = 0; i < CConst.SUPPORTS_CLIENTS_COUNT_; i++){
                        if(m_pClients[i].bIsActive == true){
                            if(m_pClients[i].sName != null){ 
                                if(m_pClients[i].sName == sName){ 
                                    return CConst.MASG_REG_NAME_TAKEN_;}}}}
                return iClientId.ToString(); // name isn't exist return client-id
            }
            catch { Console.WriteLine("VerifyNameRegistery() faild"); return CConst.MASG_REG_NAME_TAKEN_; } 
            /* when fails,  return name error */
        }

        // get context with registreation request and client id
        // handle the request
        // return true if verifyd, false if denied
        bool HundleRegisterationRequest(HttpListenerContext pContext, int iClientId)
        {
            try
            {
                // get the request data form context
                byte[] pRequestData = CHundleHTTP.GetRequest(pContext);
                
                // encode name and password form the request
                string sName = CParsing.DecodeName(pRequestData);
                string sPassword = CParsing.DecodePassword(pRequestData);
                
                // verify the request: if ok send private URI, if not send error number and exit
                string sResponse = VerifyNameRegistery(sName, iClientId);
                CHundleHTTP.SendResponse(pContext, CParsing.String2Byte(sResponse));            
                if (sResponse == CConst.MASG_REG_NAME_TAKEN_) { return false; }
               
                // verify ok - update DB with new client                
                m_pClients[iClientId].sName = sName;
                m_pClients[iClientId].sPassword = sPassword;
                m_pClients[iClientId].bIsActive = true;
                
                // start in new thread communicator that handle incoming requests form this specific client
                Thread tCommunicatorThread = new Thread(StartClientCommunicator);   
                tCommunicatorThread.Start(iClientId);

                // notify all client for new client
                NotifyClientListChanges();
                Console.Write(sName + " With Password " + sPassword); 
                return true;
            }
            catch { return false; } // return verify denied when fails
        }
        
        // return the next free space in DB
        int GetNextfreeCommunicatorId()
        {
            try
            {
                for (int i = 0; i < CConst.SUPPORTS_CLIENTS_COUNT_; i++)
                {
                    if (m_pClients[i].bIsActive == false) { return i; }
                }
                return CConst.NULL_INT_;
            }
            catch { return CConst.NULL_INT_; }
        }
        // endless loop, receive regetration requests on main URI and handle them
        void StartSigningInClients()
        {
            HttpListenerContext pContext;
            bool RegisterStatus;
            int iClientId;          
            try
            {
                // as long as the server is active
                while (m_pIsRunning)
                {
                    Console.WriteLine("Waiting For Clients");
                    RegisterStatus = true; 
    
                    // get new context with register request
                    pContext = m_pServer.GetContext();

                    // get next free space in DB
                    iClientId = GetNextfreeCommunicatorId();
                    Console.Write("incoming Registering Request: ");

                    // if threre is free space in DB handle the request
                    if (iClientId != CConst.NULL_INT_)
                    {
                        RegisterStatus = HundleRegisterationRequest(pContext, iClientId);
                        if (RegisterStatus) { Console.WriteLine(" has Registerd"); }
                        else { Console.WriteLine("Registry Refused - Name Already Taken "); }
                    }
                    else // if no free spacein DB send respons with server full message
                    {
                        CHundleHTTP.SendResponse(pContext, CParsing.String2Byte(CConst.MASG_REG_SERVER_FULL_));
                        Console.WriteLine("Registry Refused - Server Is Full ");
                    }
                }
            }
            catch { Console.WriteLine("StartSigningInClients() faild"); StartSigningInClients(); }
            /* when fails start again */
        }

        // the main function of the server
        // active this function with active the server
        // oopen server and start listening for new clients
        public void Run()
        {
            try
            {
                // init all the members
                MembersInitializtion();

                // start the server
                m_pServer.Start();
                Console.WriteLine("Server is on !");
                m_pIsRunning = true;

                // start listen for clients
                StartSigningInClients();
            }
            catch { Run(); m_pServer.Stop(); } // when fails restart
        }      
    }  
}
