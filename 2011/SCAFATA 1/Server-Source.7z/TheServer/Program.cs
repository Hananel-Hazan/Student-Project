﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TheServer
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                CServer MyServer = new CServer();
                MyServer.Run();

                Console.WriteLine("Somthing went Wrong Server Is closed!!!!!!!!!!!!!!!!!!!!!!!!!!");
                Console.ReadLine();
                Console.ReadLine();
                Console.ReadLine();
            }
            catch 
            {
                Console.WriteLine("Somthing went Wrong Server Is closed!!!!!!!!!!!!!!!!!!!!!!!!!!");
                Console.ReadLine();
                Console.ReadLine();
                Console.ReadLine();
            }
        }
    }
}
