﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Net.Security;
using System.Threading;

namespace TheServer
{
    // this class handles HTTP packages send and receive 
    public class CHundleHTTP
    {
        // get HttpListenerContext and byte[]
        // send the contents of the byte[] to the HttpListenerContext
        static public void SendResponse(HttpListenerContext pContext, byte[] pData)
        {
            // get Context Response Stream
            HttpListenerResponse pResponse = pContext.Response;
            Stream pStream = pResponse.OutputStream;
            
            // write on the stream the, data + data length
            pResponse.ContentLength64 = pData.LongLength;
            pStream.Write(pData, 0, pData.Length);
        }

        // get HttpListenerContext
        // return the data on this Context request stream
        static public byte[] GetRequest(HttpListenerContext pContext)
        {
            //find the Context request stream
            HttpListenerRequest pRequest = pContext.Request;
            Stream pStream = pRequest.InputStream;

            // find data size
            long iDataSize = pRequest.ContentLength64;
            
            // read the data from the stream
            byte[] pData = new byte[iDataSize];
            pStream.Read(pData, 0, (int)iDataSize);
            
            return pData;
        }
    }
}
