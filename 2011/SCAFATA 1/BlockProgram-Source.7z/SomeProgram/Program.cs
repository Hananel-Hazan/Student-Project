﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SomeProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the port line to connect to: ");
            CSomeProgram pSomeProgram = new CSomeProgram(Convert.ToInt32(Console.ReadLine()));
            //pSomeProgram.RunClient();
            pSomeProgram.RunServer();
        }
    }
}
