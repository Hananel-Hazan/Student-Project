﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace SomeProgram
{
    class CSomeProgram
    {
        TcpListener m_pServer;
        Int32 m_iPort;
        TcpClient m_pClient;
        String m_sServerUri;
        NetworkStream m_pStream;
        Thread m_pSendThread;

        public CSomeProgram(int iPort)
        {
            m_iPort = iPort;
            m_sServerUri = "127.0.0.1";
            m_pClient = null;
            m_pServer = null;
            m_pStream = null;
            m_pSendThread = new Thread(SendMassageLoop);
        }

        public void SendMassageLoop()
        {
            Console.WriteLine("Sending Started");
            String sMassage;
            Byte[] pData;
            while (true)
            {
                sMassage = Console.ReadLine();
                pData = System.Text.Encoding.ASCII.GetBytes(sMassage);
                try { m_pStream.Write(pData, 0, pData.Length); }
                catch { }
            }
        }

        public void ReciveMasssageLoop()
        {
            try
            {
                Byte[] pData;
                StringBuilder sMessage;
                int iBytesReadCount;
                string sCompleteMessage;
                while (true)
                {
                    if (m_pStream.CanRead)
                    {
                        pData = new byte[1024];
                        sMessage = new StringBuilder();
                        iBytesReadCount = 0;
                        do
                        {
                            iBytesReadCount = m_pStream.Read(pData, 0, pData.Length);
                            sMessage.AppendFormat("{0}", Encoding.ASCII.GetString(pData, 0, iBytesReadCount));

                        } while (m_pStream.DataAvailable);
                        sCompleteMessage = sMessage.ToString();
                        Console.WriteLine("<< " + sCompleteMessage + " >>");
                    }
                }
            }
            catch { }
        }

        public void RunClient()
        {
            try
            {
                m_pClient = new TcpClient(m_sServerUri, m_iPort);
                m_pStream = m_pClient.GetStream();
                Console.WriteLine("Established Server Conection");
                m_pSendThread.Start();
                ReciveMasssageLoop();
            }
            catch { Console.WriteLine("Faild to connect! "); }
        }

        public void RunServer()
        {
            try
            {
                IPAddress pLocalAddr = IPAddress.Parse("127.0.0.1");
                m_pServer = new TcpListener(pLocalAddr, m_iPort);
                m_pServer.Start();
                TcpClient Client = m_pServer.AcceptTcpClient();
                m_pStream = Client.GetStream();
                m_pSendThread.Start();
                ReciveMasssageLoop();
            }
            catch { Console.WriteLine("Faild to connect! "); }
        }


    }
}
