﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TheClient
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                CClientGUI MyClient = new CClientGUI();
                Application.Run(MyClient);
            }
            catch { }
        }
    }
}
