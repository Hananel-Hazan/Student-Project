﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Net.Security;
using System.Threading;

namespace TheClient
{
    // this class handls all the logic, communication with server\local-program
    class CClientLogicLayer
    {
        WebClient m_pClient;                    // client communicate with server
        public string m_sUri;                   // Server URI
        public bool m_bIsActive;                // if this client active
        public string m_sName;                  // this client name
        public string m_sPassword;              // this client password
        public bool m_bInRelationship;          // if client connected with other client
        public CByteBuffer m_pData4Transfer;
        
        public bool m_bInTunnelingMode;             // is listening on local port
        public bool m_bEstablishedLocalConnection;  // is connected with local program
        public int m_iLocalPort;                   // the local port listen to
        public TcpListener m_pLocalServer;               // server that listen on local port
        public IPAddress m_pLocalAddr;              // local ip listen on
        public NetworkStream m_pStream;             // stream to send/receive from local 
        public TcpClient m_pLocalClient;

        // constructor 
        public CClientLogicLayer()
        {
            InitMembers();
        }

        // initialize all members
        public void InitMembers()
        {
            m_pClient = new WebClient();
            m_sUri = CConst.MAIN_URI_;
            m_bIsActive = true;
            m_sName = null;
            m_sPassword = null;
            m_bInRelationship = false;
            m_pData4Transfer = new CByteBuffer();
            
            m_bInTunnelingMode = false;
            m_bEstablishedLocalConnection = false;
            m_iLocalPort = CConst.NULL_INT_;
            m_pLocalServer = null;
            m_pLocalClient = null;
            m_pLocalAddr = IPAddress.Parse("127.0.0.1");
            m_pStream = null;
        }

        // gets a string name and string password
        // send a registration request to the server 
        // return the server response
        public string RegisterToServer(string sName, string sPassword)
        {
            try
            {
                // for securety, endocde the name and pass, send the request to server
                byte[] pRegisteryRequest = CParsing.EncodeNameAndPaswword(sName, sPassword);
                byte[] pResponseData = m_pClient.UploadData(m_sUri, pRegisteryRequest);
                
                // convert server response to string 
                string sResponseMassage = CParsing.Byte2String(pResponseData);

                if (sResponseMassage == CConst.MESG_REG_NAME_TAKEN_)  //server response, name allready taken
                { return "this name is already used by another user"; }
                else if (sResponseMassage == CConst.MESG_REG_SERVER_FULL_) // server respons, server is full
                { return "Sorry but the server is full"; }
                else // server response, register succesfull
                {
                    m_sUri = CConst.SECONDARY_URI_ + sResponseMassage + "/";
                    m_sName = sName;
                    m_sPassword = sPassword;
                    return CConst.NOTIFY_REGISTER_OK;
                }

            }
            catch { return "Connections problam, can not find server"; }
            // when fails return message, could not find server
        }

        // send data to server (if have)
        // return the server response
        public byte[] WebSendAndReceive()
        {
            try
            {
                byte[] pRequest = null;
                byte[] pResponse = null;

                // if there is data to send to the server
                if (!m_pData4Transfer.IsEmpty())
                {
                    // sent the data in DataForTransfer member to the server
                    pRequest = m_pData4Transfer.ReadFromBuffer(); 
                    pResponse = m_pClient.UploadData(m_sUri, pRequest);
                }
                else
                {
                    pRequest = CParsing.String2Byte(CConst.MESG_DEMI_MASG_);
                    pResponse = m_pClient.UploadData(m_sUri, pRequest);
                }
                return pResponse;
            }
            catch { m_bIsActive = false; return null; }
        }
    
        public byte[] Append2ByteArr(byte[] pFirstArr, byte[] pSecondArr,int iCopyNumberByte)
        {
            if ( (pFirstArr != null) && (pSecondArr != null) )
            {
                int iReturnArrSize = pFirstArr.Length + iCopyNumberByte;
                byte[] pReturnArr = new byte[iReturnArrSize];
                Buffer.BlockCopy(pFirstArr, 0, pReturnArr, 0, pFirstArr.Length);
                Buffer.BlockCopy(pSecondArr, 0, pReturnArr, pFirstArr.Length, iCopyNumberByte);
                return pReturnArr;
            }
            else if ((pFirstArr != null) && (pSecondArr == null)) 
            {
                int iReturnArrSize = pFirstArr.Length;
                byte[] pReturnArr = new byte[iReturnArrSize];
                Buffer.BlockCopy(pFirstArr, 0, pReturnArr, 0, pFirstArr.Length);
                return pReturnArr; 
            }
            else if ( (pFirstArr == null) && (pSecondArr != null) ) 
            {
                int iReturnArrSize = iCopyNumberByte;
                byte[] pReturnArr = new byte[iReturnArrSize];
                Buffer.BlockCopy(pSecondArr, 0, pReturnArr, 0, iCopyNumberByte);
                return pReturnArr; 
            }  
            else { return null; }   
        }

        public void StartRecivedFromLocal()
        {
            try
            {
                byte[] pBuffer;
                byte[] pData;
                int iBytesReadCount;
                while (true)
                {
                    if (m_pStream.CanRead)
                    {
                        pBuffer = new byte[1024];
                        pData = null;
                        iBytesReadCount = 0;
                        do
                        {
                            iBytesReadCount = m_pStream.Read(pBuffer, 0, pBuffer.Length);
                            pData = Append2ByteArr(pData, pBuffer, iBytesReadCount);

                        } while (m_pStream.DataAvailable);
                        m_pData4Transfer.WriteToBuffer(pData);
                    }
                }
            }
            catch { Console.WriteLine("StartRecivedFromLocal faild!"); }
        }

        public bool SendToLocal(byte[] pData)
        {
            try
            {
                if (!m_bEstablishedLocalConnection) { return true; }
                m_pStream.Write(pData, 0, pData.Length);
                return true;
            }
            catch { m_bEstablishedLocalConnection = false; return false; }
        }

        public void InitSocketAndStartReciveFromLocal()
        {
            try
            {
                if (m_iLocalPort != CConst.NULL_INT_)
                {
                    m_pLocalServer = new TcpListener(m_pLocalAddr, m_iLocalPort);
                    m_pLocalServer.Start();

                    TcpClient Client = m_pLocalServer.AcceptTcpClient();

                    m_pStream = Client.GetStream();
                    Thread.Sleep(100);
                    m_bEstablishedLocalConnection = true;
                    StartRecivedFromLocal();
                }
            }
            catch { Console.WriteLine("InitSocketAndStartReciveFromLocal failed"); }
        }

        public void ConnectSocketAndStartReciveFromLocal()
        {
            try
            {
                if (m_iLocalPort != CConst.NULL_INT_)
                {
                    m_pLocalClient = new TcpClient("127.0.0.1", m_iLocalPort);
                    m_pStream = m_pLocalClient.GetStream();            
                    Thread.Sleep(100);
                    m_bEstablishedLocalConnection = true;
                    StartRecivedFromLocal();
                }
            }
            catch { Console.WriteLine("InitSocketAndStartReciveFromLocal failed"); }
        }

    }
}
