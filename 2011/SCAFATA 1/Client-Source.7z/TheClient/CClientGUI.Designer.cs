﻿namespace TheClient
{
    partial class CClientGUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CClientGUI));
            this.LabelRights = new System.Windows.Forms.Label();
            this.TextBoxName = new System.Windows.Forms.TextBox();
            this.TextBoxPass = new System.Windows.Forms.TextBox();
            this.LabelName = new System.Windows.Forms.Label();
            this.LabelPass = new System.Windows.Forms.Label();
            this.LabelRegister = new System.Windows.Forms.Label();
            this.textBoxInput = new System.Windows.Forms.TextBox();
            this.textBoxClientList = new System.Windows.Forms.TextBox();
            this.textBoxchat = new System.Windows.Forms.TextBox();
            this.TimerServerComunication = new System.Windows.Forms.Timer(this.components);
            this.textBoxClientPass = new System.Windows.Forms.TextBox();
            this.textBoxClientName = new System.Windows.Forms.TextBox();
            this.LabelClientList = new System.Windows.Forms.Label();
            this.LabelChatList = new System.Windows.Forms.Label();
            this.LlabelConnect = new System.Windows.Forms.Label();
            this.LabelClientName = new System.Windows.Forms.Label();
            this.LabelClientPass = new System.Windows.Forms.Label();
            this.LabelInputText = new System.Windows.Forms.Label();
            this.textBoxClientPort = new System.Windows.Forms.TextBox();
            this.labelClientPort = new System.Windows.Forms.Label();
            this.checkBoxTunneLingListening = new System.Windows.Forms.CheckBox();
            this.TimerTunnelingEfect = new System.Windows.Forms.Timer(this.components);
            this.pictureLightOn = new System.Windows.Forms.PictureBox();
            this.pictureLightOff = new System.Windows.Forms.PictureBox();
            this.pictureBoxConnect = new System.Windows.Forms.PictureBox();
            this.pictureRegister = new System.Windows.Forms.PictureBox();
            this.PictureLogo = new System.Windows.Forms.PictureBox();
            this.IncomingMesg = new System.Windows.Forms.PictureBox();
            this.PictureHeadLine = new System.Windows.Forms.PictureBox();
            this.PictureHeadLineBlack = new System.Windows.Forms.PictureBox();
            this.pictureBoxTunnelingLabel = new System.Windows.Forms.PictureBox();
            this.pictureBoxTunneling = new System.Windows.Forms.PictureBox();
            this.labelWelcomeUser = new System.Windows.Forms.Label();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.checkBoxTunneLingConnect = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureLightOn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureLightOff)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxConnect)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureRegister)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IncomingMesg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureHeadLine)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureHeadLineBlack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTunnelingLabel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTunneling)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // LabelRights
            // 
            this.LabelRights.AutoSize = true;
            this.LabelRights.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelRights.ForeColor = System.Drawing.Color.Black;
            this.LabelRights.Location = new System.Drawing.Point(20, 486);
            this.LabelRights.Name = "LabelRights";
            this.LabelRights.Size = new System.Drawing.Size(175, 15);
            this.LabelRights.TabIndex = 0;
            this.LabelRights.Text = "© Zahi Kfir And Nadim Zubidat";
            this.LabelRights.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TextBoxName
            // 
            this.TextBoxName.Location = new System.Drawing.Point(296, 466);
            this.TextBoxName.Name = "TextBoxName";
            this.TextBoxName.Size = new System.Drawing.Size(166, 20);
            this.TextBoxName.TabIndex = 3;
            // 
            // TextBoxPass
            // 
            this.TextBoxPass.Location = new System.Drawing.Point(492, 466);
            this.TextBoxPass.Name = "TextBoxPass";
            this.TextBoxPass.PasswordChar = '*';
            this.TextBoxPass.Size = new System.Drawing.Size(165, 20);
            this.TextBoxPass.TabIndex = 4;
            // 
            // LabelName
            // 
            this.LabelName.AutoSize = true;
            this.LabelName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.LabelName.Location = new System.Drawing.Point(322, 440);
            this.LabelName.Name = "LabelName";
            this.LabelName.Size = new System.Drawing.Size(106, 17);
            this.LabelName.TabIndex = 5;
            this.LabelName.Text = "Enter your name";
            // 
            // LabelPass
            // 
            this.LabelPass.AutoSize = true;
            this.LabelPass.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.LabelPass.ForeColor = System.Drawing.Color.Black;
            this.LabelPass.Location = new System.Drawing.Point(510, 440);
            this.LabelPass.Name = "LabelPass";
            this.LabelPass.Size = new System.Drawing.Size(130, 17);
            this.LabelPass.TabIndex = 6;
            this.LabelPass.Text = "Enter your password";
            // 
            // LabelRegister
            // 
            this.LabelRegister.AutoSize = true;
            this.LabelRegister.Location = new System.Drawing.Point(704, 477);
            this.LabelRegister.Name = "LabelRegister";
            this.LabelRegister.Size = new System.Drawing.Size(46, 13);
            this.LabelRegister.TabIndex = 8;
            this.LabelRegister.Text = "Register";
            // 
            // textBoxInput
            // 
            this.textBoxInput.Location = new System.Drawing.Point(296, 366);
            this.textBoxInput.Name = "textBoxInput";
            this.textBoxInput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxInput.Size = new System.Drawing.Size(436, 20);
            this.textBoxInput.TabIndex = 9;
            this.textBoxInput.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxInput_KeyDown);
            // 
            // textBoxClientList
            // 
            this.textBoxClientList.Enabled = false;
            this.textBoxClientList.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.textBoxClientList.ForeColor = System.Drawing.SystemColors.Desktop;
            this.textBoxClientList.Location = new System.Drawing.Point(296, 107);
            this.textBoxClientList.Multiline = true;
            this.textBoxClientList.Name = "textBoxClientList";
            this.textBoxClientList.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxClientList.Size = new System.Drawing.Size(156, 214);
            this.textBoxClientList.TabIndex = 10;
            // 
            // textBoxchat
            // 
            this.textBoxchat.Enabled = false;
            this.textBoxchat.Location = new System.Drawing.Point(474, 108);
            this.textBoxchat.Multiline = true;
            this.textBoxchat.Name = "textBoxchat";
            this.textBoxchat.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxchat.Size = new System.Drawing.Size(258, 214);
            this.textBoxchat.TabIndex = 11;
            // 
            // TimerServerComunication
            // 
            this.TimerServerComunication.Interval = 300;
            this.TimerServerComunication.Tick += new System.EventHandler(this.TimerStartServerCommunication);
            // 
            // textBoxClientPass
            // 
            this.textBoxClientPass.Location = new System.Drawing.Point(36, 192);
            this.textBoxClientPass.Name = "textBoxClientPass";
            this.textBoxClientPass.PasswordChar = '*';
            this.textBoxClientPass.Size = new System.Drawing.Size(142, 20);
            this.textBoxClientPass.TabIndex = 12;
            // 
            // textBoxClientName
            // 
            this.textBoxClientName.Location = new System.Drawing.Point(36, 134);
            this.textBoxClientName.Name = "textBoxClientName";
            this.textBoxClientName.Size = new System.Drawing.Size(142, 20);
            this.textBoxClientName.TabIndex = 13;
            // 
            // LabelClientList
            // 
            this.LabelClientList.AutoSize = true;
            this.LabelClientList.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.LabelClientList.Location = new System.Drawing.Point(293, 324);
            this.LabelClientList.Name = "LabelClientList";
            this.LabelClientList.Size = new System.Drawing.Size(58, 15);
            this.LabelClientList.TabIndex = 17;
            this.LabelClientList.Text = "Client List";
            // 
            // LabelChatList
            // 
            this.LabelChatList.AutoSize = true;
            this.LabelChatList.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.LabelChatList.Location = new System.Drawing.Point(677, 325);
            this.LabelChatList.Name = "LabelChatList";
            this.LabelChatList.Size = new System.Drawing.Size(52, 15);
            this.LabelChatList.TabIndex = 18;
            this.LabelChatList.Text = "Chat List";
            // 
            // LlabelConnect
            // 
            this.LlabelConnect.AutoSize = true;
            this.LlabelConnect.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.LlabelConnect.Location = new System.Drawing.Point(222, 210);
            this.LlabelConnect.Name = "LlabelConnect";
            this.LlabelConnect.Size = new System.Drawing.Size(47, 15);
            this.LlabelConnect.TabIndex = 20;
            this.LlabelConnect.Text = "Connect";
            // 
            // LabelClientName
            // 
            this.LabelClientName.AutoSize = true;
            this.LabelClientName.Location = new System.Drawing.Point(33, 114);
            this.LabelClientName.Name = "LabelClientName";
            this.LabelClientName.Size = new System.Drawing.Size(64, 13);
            this.LabelClientName.TabIndex = 21;
            this.LabelClientName.Text = "Client Name";
            // 
            // LabelClientPass
            // 
            this.LabelClientPass.AutoSize = true;
            this.LabelClientPass.Location = new System.Drawing.Point(33, 175);
            this.LabelClientPass.Name = "LabelClientPass";
            this.LabelClientPass.Size = new System.Drawing.Size(82, 13);
            this.LabelClientPass.TabIndex = 22;
            this.LabelClientPass.Text = "Client Password";
            // 
            // LabelInputText
            // 
            this.LabelInputText.AutoSize = true;
            this.LabelInputText.Location = new System.Drawing.Point(426, 389);
            this.LabelInputText.Name = "LabelInputText";
            this.LabelInputText.Size = new System.Drawing.Size(163, 13);
            this.LabelInputText.TabIndex = 23;
            this.LabelInputText.Text = "Insert your text and press \"Enter\"";
            // 
            // textBoxClientPort
            // 
            this.textBoxClientPort.Location = new System.Drawing.Point(36, 249);
            this.textBoxClientPort.Name = "textBoxClientPort";
            this.textBoxClientPort.Size = new System.Drawing.Size(100, 20);
            this.textBoxClientPort.TabIndex = 27;
            this.textBoxClientPort.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxClientPort_KeyPress);
            // 
            // labelClientPort
            // 
            this.labelClientPort.AutoSize = true;
            this.labelClientPort.Location = new System.Drawing.Point(34, 232);
            this.labelClientPort.Name = "labelClientPort";
            this.labelClientPort.Size = new System.Drawing.Size(57, 13);
            this.labelClientPort.TabIndex = 28;
            this.labelClientPort.Text = "Listen Prot";
            // 
            // checkBoxTunneLingListening
            // 
            this.checkBoxTunneLingListening.AutoSize = true;
            this.checkBoxTunneLingListening.Location = new System.Drawing.Point(158, 237);
            this.checkBoxTunneLingListening.Name = "checkBoxTunneLingListening";
            this.checkBoxTunneLingListening.Size = new System.Drawing.Size(107, 17);
            this.checkBoxTunneLingListening.TabIndex = 29;
            this.checkBoxTunneLingListening.Text = "Tunneling Server";
            this.checkBoxTunneLingListening.UseVisualStyleBackColor = true;
            this.checkBoxTunneLingListening.CheckedChanged += new System.EventHandler(this.checkBoxTunneling_CheckedChanged);
            // 
            // TimerTunnelingEfect
            // 
            this.TimerTunnelingEfect.Interval = 350;
            this.TimerTunnelingEfect.Tick += new System.EventHandler(this.TimerTunnelingEfect_Tick);
            // 
            // pictureLightOn
            // 
            this.pictureLightOn.Image = global::TheClient.Properties.Resources.LightOn;
            this.pictureLightOn.Location = new System.Drawing.Point(252, 119);
            this.pictureLightOn.Name = "pictureLightOn";
            this.pictureLightOn.Size = new System.Drawing.Size(32, 46);
            this.pictureLightOn.TabIndex = 26;
            this.pictureLightOn.TabStop = false;
            // 
            // pictureLightOff
            // 
            this.pictureLightOff.Image = global::TheClient.Properties.Resources.Light_Of;
            this.pictureLightOff.Location = new System.Drawing.Point(252, 119);
            this.pictureLightOff.Name = "pictureLightOff";
            this.pictureLightOff.Size = new System.Drawing.Size(29, 47);
            this.pictureLightOff.TabIndex = 25;
            this.pictureLightOff.TabStop = false;
            // 
            // pictureBoxConnect
            // 
            this.pictureBoxConnect.Image = global::TheClient.Properties.Resources.Connect;
            this.pictureBoxConnect.Location = new System.Drawing.Point(190, 145);
            this.pictureBoxConnect.Name = "pictureBoxConnect";
            this.pictureBoxConnect.Size = new System.Drawing.Size(79, 80);
            this.pictureBoxConnect.TabIndex = 19;
            this.pictureBoxConnect.TabStop = false;
            this.pictureBoxConnect.Click += new System.EventHandler(this.pictureBoxConnect_Click);
            // 
            // pictureRegister
            // 
            this.pictureRegister.Image = global::TheClient.Properties.Resources.register;
            this.pictureRegister.Location = new System.Drawing.Point(677, 440);
            this.pictureRegister.Name = "pictureRegister";
            this.pictureRegister.Size = new System.Drawing.Size(52, 50);
            this.pictureRegister.TabIndex = 7;
            this.pictureRegister.TabStop = false;
            this.pictureRegister.Click += new System.EventHandler(this.pictureRegister_Click);
            // 
            // PictureLogo
            // 
            this.PictureLogo.Image = global::TheClient.Properties.Resources.Icon;
            this.PictureLogo.Location = new System.Drawing.Point(1, 290);
            this.PictureLogo.Name = "PictureLogo";
            this.PictureLogo.Size = new System.Drawing.Size(237, 196);
            this.PictureLogo.TabIndex = 1;
            this.PictureLogo.TabStop = false;
            // 
            // IncomingMesg
            // 
            this.IncomingMesg.Image = global::TheClient.Properties.Resources.IncomingMesg;
            this.IncomingMesg.Location = new System.Drawing.Point(660, 32);
            this.IncomingMesg.Name = "IncomingMesg";
            this.IncomingMesg.Size = new System.Drawing.Size(70, 74);
            this.IncomingMesg.TabIndex = 24;
            this.IncomingMesg.TabStop = false;
            // 
            // PictureHeadLine
            // 
            this.PictureHeadLine.Image = global::TheClient.Properties.Resources.HeadLine;
            this.PictureHeadLine.Location = new System.Drawing.Point(144, 1);
            this.PictureHeadLine.Name = "PictureHeadLine";
            this.PictureHeadLine.Size = new System.Drawing.Size(477, 63);
            this.PictureHeadLine.TabIndex = 2;
            this.PictureHeadLine.TabStop = false;
            // 
            // PictureHeadLineBlack
            // 
            this.PictureHeadLineBlack.Image = global::TheClient.Properties.Resources.HeadLineBlack;
            this.PictureHeadLineBlack.Location = new System.Drawing.Point(144, 2);
            this.PictureHeadLineBlack.Name = "PictureHeadLineBlack";
            this.PictureHeadLineBlack.Size = new System.Drawing.Size(477, 62);
            this.PictureHeadLineBlack.TabIndex = 32;
            this.PictureHeadLineBlack.TabStop = false;
            // 
            // pictureBoxTunnelingLabel
            // 
            this.pictureBoxTunnelingLabel.Image = global::TheClient.Properties.Resources.TunnelingLabel1;
            this.pictureBoxTunnelingLabel.Location = new System.Drawing.Point(504, 352);
            this.pictureBoxTunnelingLabel.Name = "pictureBoxTunnelingLabel";
            this.pictureBoxTunnelingLabel.Size = new System.Drawing.Size(170, 50);
            this.pictureBoxTunnelingLabel.TabIndex = 33;
            this.pictureBoxTunnelingLabel.TabStop = false;
            // 
            // pictureBoxTunneling
            // 
            this.pictureBoxTunneling.Image = global::TheClient.Properties.Resources.Tunneling;
            this.pictureBoxTunneling.Location = new System.Drawing.Point(1, 2);
            this.pictureBoxTunneling.Name = "pictureBoxTunneling";
            this.pictureBoxTunneling.Size = new System.Drawing.Size(776, 507);
            this.pictureBoxTunneling.TabIndex = 31;
            this.pictureBoxTunneling.TabStop = false;
            // 
            // labelWelcomeUser
            // 
            this.labelWelcomeUser.AutoSize = true;
            this.labelWelcomeUser.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.labelWelcomeUser.Location = new System.Drawing.Point(351, 57);
            this.labelWelcomeUser.Name = "labelWelcomeUser";
            this.labelWelcomeUser.Size = new System.Drawing.Size(0, 14);
            this.labelWelcomeUser.TabIndex = 34;
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // checkBoxTunneLingConnect
            // 
            this.checkBoxTunneLingConnect.AutoSize = true;
            this.checkBoxTunneLingConnect.Location = new System.Drawing.Point(158, 261);
            this.checkBoxTunneLingConnect.Name = "checkBoxTunneLingConnect";
            this.checkBoxTunneLingConnect.Size = new System.Drawing.Size(102, 17);
            this.checkBoxTunneLingConnect.TabIndex = 35;
            this.checkBoxTunneLingConnect.Text = "Tunneling Client";
            this.checkBoxTunneLingConnect.UseVisualStyleBackColor = true;
            this.checkBoxTunneLingConnect.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // CClientGUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(775, 509);
            this.Controls.Add(this.checkBoxTunneLingConnect);
            this.Controls.Add(this.labelWelcomeUser);
            this.Controls.Add(this.PictureHeadLine);
            this.Controls.Add(this.checkBoxTunneLingListening);
            this.Controls.Add(this.labelClientPort);
            this.Controls.Add(this.textBoxClientPort);
            this.Controls.Add(this.pictureLightOn);
            this.Controls.Add(this.pictureLightOff);
            this.Controls.Add(this.LabelInputText);
            this.Controls.Add(this.LabelClientPass);
            this.Controls.Add(this.LabelClientName);
            this.Controls.Add(this.LlabelConnect);
            this.Controls.Add(this.pictureBoxConnect);
            this.Controls.Add(this.LabelChatList);
            this.Controls.Add(this.LabelClientList);
            this.Controls.Add(this.textBoxClientName);
            this.Controls.Add(this.textBoxClientPass);
            this.Controls.Add(this.textBoxchat);
            this.Controls.Add(this.textBoxClientList);
            this.Controls.Add(this.textBoxInput);
            this.Controls.Add(this.LabelRegister);
            this.Controls.Add(this.pictureRegister);
            this.Controls.Add(this.LabelPass);
            this.Controls.Add(this.LabelName);
            this.Controls.Add(this.TextBoxPass);
            this.Controls.Add(this.TextBoxName);
            this.Controls.Add(this.LabelRights);
            this.Controls.Add(this.PictureLogo);
            this.Controls.Add(this.IncomingMesg);
            this.Controls.Add(this.PictureHeadLineBlack);
            this.Controls.Add(this.pictureBoxTunnelingLabel);
            this.Controls.Add(this.pictureBoxTunneling);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CClientGUI";
            this.Text = "Connection to anywhere, from anywhere, any time.";
            ((System.ComponentModel.ISupportInitialize)(this.pictureLightOn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureLightOff)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxConnect)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureRegister)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IncomingMesg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureHeadLine)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureHeadLineBlack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTunnelingLabel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTunneling)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LabelRights;
        private System.Windows.Forms.PictureBox PictureLogo;
        private System.Windows.Forms.PictureBox PictureHeadLine;
        private System.Windows.Forms.TextBox TextBoxName;
        private System.Windows.Forms.TextBox TextBoxPass;
        private System.Windows.Forms.Label LabelName;
        private System.Windows.Forms.Label LabelPass;
        private System.Windows.Forms.PictureBox pictureRegister;
        private System.Windows.Forms.Label LabelRegister;
        private System.Windows.Forms.TextBox textBoxInput;
        private System.Windows.Forms.TextBox textBoxClientList;
        private System.Windows.Forms.TextBox textBoxchat;
        private System.Windows.Forms.Timer TimerServerComunication;
        private System.Windows.Forms.TextBox textBoxClientPass;
        private System.Windows.Forms.TextBox textBoxClientName;
        private System.Windows.Forms.Label LabelClientList;
        private System.Windows.Forms.Label LabelChatList;
        private System.Windows.Forms.PictureBox pictureBoxConnect;
        private System.Windows.Forms.Label LlabelConnect;
        private System.Windows.Forms.Label LabelClientName;
        private System.Windows.Forms.Label LabelClientPass;
        private System.Windows.Forms.Label LabelInputText;
        private System.Windows.Forms.PictureBox IncomingMesg;
        private System.Windows.Forms.PictureBox pictureLightOff;
        private System.Windows.Forms.PictureBox pictureLightOn;
        private System.Windows.Forms.TextBox textBoxClientPort;
        private System.Windows.Forms.Label labelClientPort;
        private System.Windows.Forms.CheckBox checkBoxTunneLingListening;
        private System.Windows.Forms.PictureBox PictureHeadLineBlack;
        private System.Windows.Forms.PictureBox pictureBoxTunneling;
        private System.Windows.Forms.Timer TimerTunnelingEfect;
        private System.Windows.Forms.PictureBox pictureBoxTunnelingLabel;
        private System.Windows.Forms.Label labelWelcomeUser;
        private System.Windows.Forms.ErrorProvider errorProvider;
        private System.Windows.Forms.CheckBox checkBoxTunneLingConnect;
    }
}