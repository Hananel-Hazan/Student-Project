﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net;

namespace TheClient
{
    public partial class CClientGUI : Form
    {
        CClientLogicLayer m_pLogicLayer;

        int m_pTunnelingEfectDB;

        public CClientGUI()
        {
                InitializeComponent();
                this.FormClosed += FormName_FormClosed;
                m_pLogicLayer = new CClientLogicLayer();
                ChangeGuiToRegisterMode();
                m_pTunnelingEfectDB = 0;
                
        }

        private void pictureRegister_Click(object sender, EventArgs e)
        {
            try
            {
                errorProvider.SetError(TextBoxName, null);
                errorProvider.SetError(TextBoxPass, null);
                if (!string.IsNullOrWhiteSpace(TextBoxName.Text))
                {
                    if (!string.IsNullOrWhiteSpace(TextBoxPass.Text))
                    {   
                        string sRespones = m_pLogicLayer.RegisterToServer(TextBoxName.Text, TextBoxPass.Text);
                        if (sRespones == CConst.NOTIFY_REGISTER_OK)
                        {
                            TextBoxPass.Enabled = false;
                            TextBoxName.Enabled = false;
                            pictureRegister.Enabled = false;
                            ChangeGuiToConnectMode();
                            TimerServerComunication.Start();
                        }
                        else { MessageBox.Show(sRespones); }
                    }
                    else { errorProvider.SetError(TextBoxPass, "Registeration required a password"); }
                }
                else { errorProvider.SetError(TextBoxName, "Registeration required a name"); }
                TextBoxName.Text = "";
                TextBoxPass.Text = "";
            }
            catch { MessageBox.Show("pictureRegister_Click Faild!"); Disconected(); }
        }

        private void pictureBoxConnect_Click(object sender, EventArgs e)
        {
            try
            {
                errorProvider.SetError(textBoxClientName, "");
                errorProvider.SetError(textBoxClientPass, "");
                if (!string.IsNullOrWhiteSpace(textBoxClientName.Text))
                {
                    if (!string.IsNullOrWhiteSpace(textBoxClientPass.Text))
                    {
                        byte[] pConnectionRequest = CParsing.EncodeNameAndPaswword(textBoxClientName.Text, textBoxClientPass.Text);
                        m_pLogicLayer.m_pData4Transfer.WriteToBuffer(pConnectionRequest);
                    }
                    else { errorProvider.SetError(textBoxClientPass, "Connection required a password"); }
                }
                else { errorProvider.SetError(textBoxClientName, "Connection requierd a name "); }
                textBoxClientName.Text = "";
                textBoxClientPass.Text = "";
            }
            catch { MessageBox.Show("pictureRegister_Click Faild!"); Disconected(); }
        }

        private void textBoxInput_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyData == Keys.Enter)
                {
                    if (!string.IsNullOrWhiteSpace(textBoxInput.Text))
                    {
                        m_pLogicLayer.m_pData4Transfer.WriteToBuffer( CParsing.String2Byte(textBoxInput.Text) );
                        textBoxchat.AppendText(textBoxInput.Text + "\r\n");
                        textBoxInput.Text = "";
                    }
                }
            }
            catch
            {
                Disconected();
            }
        }

        private void checkBoxTunneling_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                errorProvider.SetError(textBoxClientPort, "");
                if (checkBoxTunneLingListening.Checked)
                {
                    if (!string.IsNullOrWhiteSpace(textBoxClientPort.Text))
                    {
                        m_pLogicLayer.m_iLocalPort = Convert.ToInt32(textBoxClientPort.Text);                          
                        Thread TempThread = new Thread(m_pLogicLayer.InitSocketAndStartReciveFromLocal);
                        TempThread.Start();
                        ChangeGuiTunnelingMode();
                        m_pLogicLayer.m_bInTunnelingMode = true;
                    }
                    else { errorProvider.SetError(textBoxClientPort, "Tunneling required a port"); ; checkBoxTunneLingListening.Checked = false; }
                }
            }
            catch { MessageBox.Show("checkBoxTunneling_CheckedChanged Faild!"); Disconected(); }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                errorProvider.SetError(textBoxClientPort, "");
                if (checkBoxTunneLingConnect.Checked)
                {
                    if (!string.IsNullOrWhiteSpace(textBoxClientPort.Text))
                    {
                        m_pLogicLayer.m_iLocalPort = Convert.ToInt32(textBoxClientPort.Text);
                        Thread TempThread = new Thread(m_pLogicLayer.ConnectSocketAndStartReciveFromLocal);
                        TempThread.Start();
                        ChangeGuiTunnelingMode();
                        m_pLogicLayer.m_bInTunnelingMode = true;
                    }
                    else { errorProvider.SetError(textBoxClientPort, "Tunneling required a port"); ; checkBoxTunneLingConnect.Checked = false; }
                }
            }
            catch { MessageBox.Show("checkBoxTunneling_CheckedChanged Faild!"); Disconected(); }
        }

        private void TimerStartServerCommunication(object sender, EventArgs e)
        {
            try
            {
                byte[] pResponse = null;
                string sResponse = null;
                if (m_pLogicLayer.m_bIsActive)
                {
                    pResponse = m_pLogicLayer.WebSendAndReceive();
                    sResponse = CParsing.Byte2String(pResponse);
                    if (m_pLogicLayer.m_bInRelationship)
                    {
                        if (sResponse != CConst.MESG_DEMI_MASG_)
                        {
                            if (sResponse == CConst.MESG_DISSCONECTED_)
                            {
                                MessageBox.Show("Your Friend Has dissconnected");
                                m_pLogicLayer.m_bInRelationship = false;
                                string sName = m_pLogicLayer.m_sName;
                                string sPassword = m_pLogicLayer.m_sPassword;
                                Disconected();
                                Reconnect(sName, sPassword); 
                            }
                            else
                            {
                                if (m_pLogicLayer.m_bInTunnelingMode)
                                {
                                    if (!m_pLogicLayer.SendToLocal(pResponse))
                                    {
                                        string sName = m_pLogicLayer.m_sName;
                                        string sPassword = m_pLogicLayer.m_sPassword;
                                        Disconected(); 
                                        Reconnect(sName,sPassword); 
                                    }
                                }
                                else
                                {
                                    textBoxchat.AppendText("<< " + sResponse + " >>\r\n");
                                    IncomingMesg.Hide(); Thread.Sleep(20);
                                    IncomingMesg.Show(); Thread.Sleep(20);
                                    IncomingMesg.Hide(); Thread.Sleep(20);
                                    IncomingMesg.Show();
                                }
                            }
                        }
                    }
                    else
                    {
                        switch (sResponse)
                        {
                            case CConst.MESG_DEMI_MASG_:
                                break;
                            case CConst.MESG_IN_RELATIONSHIP_:
                                ChangeGuiToReltionshipMode();
                                m_pLogicLayer.m_bInRelationship = true;
                                break;
                            case CConst.MESG_NO_CLIENT_NAME_:
                                MessageBox.Show("No client with that name!");
                                break;
                            case CConst.MESG_WRONG_PASSORD_:
                                MessageBox.Show("Wrong Password!");
                                break;
                            case CConst.MESG_DISSCONECTED_:
                                MessageBox.Show("Server connection is lost");
                                Disconected();
                                break;
                            case null:
                                MessageBox.Show("Server connection is lost");
                                break;
                            default:
                                if (sResponse != null) { textBoxClientList.Text = ""; textBoxClientList.AppendText(sResponse); }
                                break;
                        }
                    }
                }
            }
            catch { MessageBox.Show("StartServerCommunication Faild!"); Disconected(); }
        }

        void ChangeGuiToRegisterMode()
        {
            try
            {
                m_pLogicLayer.InitMembers();

                TextBoxName.Enabled = true;
                TextBoxPass.Enabled = true;
                pictureRegister.Enabled = true;

                textBoxClientPass.Enabled = false;
                textBoxClientName.Enabled = false;
                pictureBoxConnect.Enabled = false;

                textBoxInput.Enabled = false;
                textBoxClientPort.Enabled = false;
                checkBoxTunneLingListening.Enabled = false;
                checkBoxTunneLingConnect.Enabled = false;

                pictureLightOff.Show();
                pictureLightOn.Hide();

                textBoxchat.Text = "";
                textBoxClientList.Text = "";
                textBoxInput.Text = "";
                textBoxClientPort.Text = "";
                textBoxClientName.Text = "";
                textBoxClientPass.Text = "";
                checkBoxTunneLingListening.Checked = false;
                checkBoxTunneLingConnect.Checked = false;

                checkBoxTunneLingListening.Show(); labelClientPort.Show(); textBoxClientPort.Show();
                LabelInputText.Show(); PictureLogo.Show(); IncomingMesg.Show();
                LabelClientPass.Show(); LabelClientName.Show(); LlabelConnect.Show();
                pictureBoxConnect.Show(); LabelChatList.Show(); LabelClientList.Show();
                textBoxClientName.Show(); textBoxClientPass.Show(); textBoxchat.Show();
                textBoxClientList.Show(); textBoxInput.Show(); LabelRegister.Show();
                pictureRegister.Show(); LabelPass.Show(); LabelName.Show();
                TextBoxPass.Show(); TextBoxName.Show(); LabelRights.Show();
                labelWelcomeUser.Hide(); checkBoxTunneLingConnect.Show();

                PictureHeadLine.Show();
                PictureHeadLineBlack.Hide();
                pictureBoxTunneling.Hide();
                pictureBoxTunnelingLabel.Hide();
                this.BackColor = Color.White;

                TimerTunnelingEfect.Stop();
                TimerServerComunication.Stop();
            }
            catch { this.Close(); }
        }

        void ChangeGuiToConnectMode()
        {
            try
            {
                TextBoxName.Enabled = false;
                TextBoxPass.Enabled = false;
                pictureRegister.Enabled = false;

                textBoxClientPass.Enabled = true;
                textBoxClientName.Enabled = true;
                pictureBoxConnect.Enabled = true;

                textBoxInput.Enabled = false;
                textBoxClientPort.Enabled = false;
                checkBoxTunneLingListening.Enabled = false;
                checkBoxTunneLingConnect.Enabled = false;

                pictureLightOff.Show();
                pictureLightOn.Hide();

                labelWelcomeUser.Text = "Welcome " + m_pLogicLayer.m_sName;
                labelWelcomeUser.Show();
            }
            catch { Disconected(); }
        }

        void ChangeGuiToReltionshipMode()
        {
            try
            {
                TextBoxName.Enabled = false;
                TextBoxPass.Enabled = false;
                pictureRegister.Enabled = false;

                textBoxClientPass.Enabled = false;
                textBoxClientName.Enabled = false;
                pictureBoxConnect.Enabled = false;

                textBoxInput.Enabled = true;
                textBoxClientPort.Enabled = true;
                checkBoxTunneLingListening.Enabled = true;
                checkBoxTunneLingConnect.Enabled = true;

                pictureLightOff.Hide();
                pictureLightOn.Show();

                textBoxClientList.Text = "";

                string sNotifyMyName = "Connected with " + m_pLogicLayer.m_sName.ToUpper() + " !";
                m_pLogicLayer.m_pData4Transfer.WriteToBuffer( CParsing.String2Byte(sNotifyMyName) );
            }
            catch { Disconected(); }
        }

        void ChangeGuiTunnelingMode()
        {
            try
            {
                checkBoxTunneLingListening.Hide(); labelClientPort.Hide(); textBoxClientPort.Hide();
                pictureLightOn.Hide(); pictureLightOff.Hide(); LabelInputText.Hide();
                LabelClientPass.Hide(); LabelClientName.Hide(); LlabelConnect.Hide();
                pictureBoxConnect.Hide(); LabelChatList.Hide(); LabelClientList.Hide();
                textBoxClientName.Hide(); textBoxClientPass.Hide(); textBoxchat.Hide();
                textBoxClientList.Hide(); textBoxInput.Hide(); LabelRegister.Hide();
                pictureRegister.Hide(); LabelPass.Hide(); LabelName.Hide();
                TextBoxPass.Hide(); TextBoxName.Hide(); LabelRights.Hide();
                PictureLogo.Hide(); IncomingMesg.Hide(); labelWelcomeUser.Hide();
                checkBoxTunneLingConnect.Hide();

                PictureHeadLine.Hide();
                PictureHeadLineBlack.Show();
                pictureBoxTunneling.Show();
                pictureBoxTunnelingLabel.Show();
                this.BackColor = Color.Black;

                TimerTunnelingEfect.Start();
            }
            catch { Disconected(); }
        }

        private void TimerTunnelingEfect_Tick(object sender, EventArgs e)
        {
            try
            {
                if (m_pLogicLayer.m_bEstablishedLocalConnection)
                {
                    if (m_pTunnelingEfectDB == 0)
                    {
                        m_pTunnelingEfectDB = 1;
                        pictureBoxTunneling.Show();
                        pictureBoxTunnelingLabel.Show();
                    }
                    else
                    {
                        m_pTunnelingEfectDB = 0;
                        pictureBoxTunneling.Hide();
                        pictureBoxTunnelingLabel.Hide();
                    }
                }
            }
            catch { }
        }

        private void textBoxClientPort_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar); 
        }

        void Reconnect(string sName, string sPassword)
        {
            try
            {
                if ((sName != null) && (sPassword != null))
                {
                    string sRespones = m_pLogicLayer.RegisterToServer(sName, sPassword);
                    if (sRespones == CConst.NOTIFY_REGISTER_OK)
                    {
                        TextBoxPass.Enabled = false;
                        TextBoxName.Enabled = false;
                        pictureRegister.Enabled = false;
                        ChangeGuiToConnectMode();
                        TimerServerComunication.Start();
                    }
                }
            }
            catch { MessageBox.Show(" Reconnect() Faild"); }
        }

        void Disconected()
        {
            try
            {
                if ((m_pLogicLayer.m_sUri != null) && (m_pLogicLayer.m_sUri != CConst.MAIN_URI_))
                {
                    WebClient pTempWebClient = new WebClient();
                    byte[] Temp = pTempWebClient.UploadData(m_pLogicLayer.m_sUri, CParsing.String2Byte(CConst.MESG_DISSCONECTED_));
                }
                ChangeGuiToRegisterMode();
            }
            catch { ChangeGuiToRegisterMode(); }
        }
        
        private void FormName_FormClosed(object sender, System.Windows.Forms.FormClosedEventArgs e)
        {
            try
            {
                TimerServerComunication.Stop();
                Thread.Sleep(500);
                if ( (m_pLogicLayer.m_sUri != null) && (m_pLogicLayer.m_sUri != CConst.MAIN_URI_) )
                {
                    WebClient pTempWebClient = new WebClient();
                    byte[] Temp = pTempWebClient.UploadData(m_pLogicLayer.m_sUri, CParsing.String2Byte(CConst.MESG_DISSCONECTED_));
                }
            }
            catch { }
        }

       



    }
}
