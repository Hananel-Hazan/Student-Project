﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TheClient
{
    // this class contain all the consts used in this solution
    class CConst
    {
        // indicate that some INT is equal to NULL
        public const int NULL_INT_ = -123456;

        // Shared with server! used allso at the server!
        // all the const messages to communicate with server
        public const string MAIN_URI_ = "http://192.168.1.100:8080/zkk/";       // the main URI the server will listen on
        public const string SECONDARY_URI_ = "http://192.168.1.100:8080/zkk";   // URI listen only to this client
        public const string MESG_REG_NAME_TAKEN_ = "NameAlreadyTaken";          // message - name already taken
        public const string MESG_REG_SERVER_FULL_ = "SorryServerIsFull";        // message - server is full
        public const string MESG_DEMI_MASG_ = "ThisIsDemiMasg";                 // message - empty/demi message 
        public const string MESG_NO_CLIENT_NAME_ = "NoClientWithThatName";      // message - cant find client name
        public const string MESG_WRONG_PASSORD_ = "SoryWrongPaswword";          // message - worng password
        public const string MESG_IN_RELATIONSHIP_ = "YouInRelationship";        // message - start relationship
        public const string MESG_DISSCONECTED_ = "YourFriendDisconected";       // message - friend has dissconnected

        // comunication with GUI
        public const string NOTIFY_REGISTER_OK = "TheRegisterIsOk";             // notify GUI regestered to server 
        
    }
}
