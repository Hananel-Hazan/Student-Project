﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Net.Security;
using System.Threading;

namespace TheClient
{
    // this class handle all the parsing
    public class CParsing
    {
        // get data as byte[]
        // return data as string 
        static public string Byte2String(byte[] pByteArr)
        {
            return System.Text.Encoding.UTF8.GetString(pByteArr);
        }

        // get data as string 
        // return data as byte[]
        static public byte[] String2Byte(string sString)
        {
            return System.Text.Encoding.UTF8.GetBytes(sString);
        }

        // get string name and string password
        // return encode name and password to encrypted byte[]
        // [name size]     [name]         [password]
        // [4 bytes]   [less 100 byets]  [some bytes]
        static public byte[] EncodeNameAndPaswword(string sName, string sPassword)
        {
            try
            {
                if (sName.Length < 100)
                {
                    // get byte[] size (the 4 byts for name size) 
                    int MassageLenght = 4 + sName.Length + sPassword.Length;
                    byte[] EncodedMassage = new byte[MassageLenght];
                    byte[] pNameSize = new byte[4];

                    // parse name size to byte and copy to returnd value
                    pNameSize = String2Byte(sName.Length.ToString());
                    Buffer.BlockCopy(pNameSize, 0, EncodedMassage, 0, pNameSize.Length);

                    // parse name and password to byte[] copy to returnd value
                    string sNameAndPassword = sName + sPassword;
                    byte[] pNameAndPassword = String2Byte(sNameAndPassword);
                    Buffer.BlockCopy(pNameAndPassword, 0, EncodedMassage, 4, pNameAndPassword.Length);

                    return EncodedMassage;
                }
                return null;
            }
            catch { return null; } // return null when failed
        }

        // get encoded name and password as byte[]
        // return only the name as string  
        static public string DecodeName(byte[] pMassage)
        {
            try
            {
                string sName = null;

                // get name size (read 4 first bytes of the byte[])
                byte[] pNameSize = new byte[4];
                Buffer.BlockCopy(pMassage, 0, pNameSize, 0, 4);
                int iNameSize = Convert.ToInt32(Byte2String(pNameSize));

                // get name  (got size, start reading from byte[4])
                byte[] pName = new byte[iNameSize];
                Buffer.BlockCopy(pMassage, 4, pName, 0, iNameSize);
                sName = Byte2String(pName);

                return sName;
            }
            catch { return null; } // return null at when failed
        }

        // get encoded name and password as byte[]
        // return only the password as string 
        static public string DecodePassword(byte[] pMassage)
        {
            try
            {
                string sPassword = null;

                // get name size (read 4 first bytes of the byte[])
                byte[] pNameSize = new byte[4];
                Buffer.BlockCopy(pMassage, 0, pNameSize, 0, 4);
                int iNameSize = Convert.ToInt32(Byte2String(pNameSize));

                // get password size (4 - the first 4 byte that indicate name size)
                // get password (got password size, start reading from name size + 4)
                int iPasswordSize = pMassage.Length - iNameSize - 4;
                byte[] pPassword = new byte[iPasswordSize];
                Buffer.BlockCopy(pMassage, iNameSize + 4, pPassword, 0, iPasswordSize);
                sPassword = Byte2String(pPassword);

                return sPassword;
            }
            catch { return null; } // return null at when failed
        }
    }
}
