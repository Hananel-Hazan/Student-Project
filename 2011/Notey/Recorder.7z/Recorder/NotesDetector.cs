﻿/*
* This file is Part of Notey
* LGPLv3 Licence:
*       Copyright (c) 2011 
*          Hila Shmuel [notey.recorder@gmail.com]
*          Hananel Hazan [hhazan01@CS.haifa.ac.il]
*          University of Haifa
* This Project is part of our B.Sc. Project course that under supervision
* of Hananel Hazan [hhazan01@CS.haifa.ac.il]
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without 
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice, this list of conditions 
*    and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice, this list of 
*    conditions and the following disclaimer in the documentation and/or other materials provided
*    with the distribution.
* 3. Neither the name of the <ORGANIZATION> nor the names of its contributors may be used to endorse
*    or promote products derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
* OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
* DAMAGE.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Notes
{
    /// <summary>
    /// Given last notes samples, detect which (if any) note has been played
    /// </summary>
    class NotesDetector
    {
        /// <summary>
        /// if captured the same samples at least in that time, declare it a note
        /// </summary>
        private const int minimalNoteTime = 70;
        private const int maximalNoteTime = 1000;
        private const int notesSamplesLimit = 10;
        private LimitedList<Note> playedNotes;
        private LimitedList<int> playedNotesTimes;

        /// <summary>
        /// constructor for the class NotesDetector
        /// </summary>
        public NotesDetector()
        {
            playedNotes = new LimitedList<Note>(notesSamplesLimit);
            playedNotesTimes = new LimitedList<int>(notesSamplesLimit);
        }

        /// <summary>
        /// Detect the note based on the last and current samples
        /// This function is used to be called repeatedly, once for every note sample.
        /// given a note, a check is perform based on the last samples, whether this note
        /// is a valid note (with sufficient length) or not.
        /// Based on the detection, if there are enough samples, the function return the 
        /// new note, or the same prevous note with longer duration.
        /// </summary>
        /// <param name="note">A note sample. This may not produce a note, in cases the the note's samples
        /// appears to be a noise</param>
        /// <param name="timePlayed">The time this note has been played</param>
        /// <returns>The Note played</returns>
        public Note DetectNote(Note note, int timePlayed)
        {
            playedNotes.AddAtStart(note);
            playedNotesTimes.AddAtStart(timePlayed);

            if (playedNotes.Count < playedNotes.Limit)
            {
                return null;
            }

            int duration = 0;
            for (int i = playedNotes.Count - 1; i >= 0; i--)
            {
                Note oldNote = playedNotes[i];
                int oldTime = playedNotesTimes[i];

                if (note.MIDI == oldNote.MIDI)
                {
                    duration = timePlayed - oldTime;
                }
                else
                {
                    if (duration < minimalNoteTime)
                    {
                        duration = 0;
                    }
                    break;
                }
            }

            // if duration reached max, clear buffer
            if (maximalNoteTime < duration)
            {
                playedNotes.Clear();
                playedNotesTimes.Clear();
            }

            // add note
            if (0 < duration)
            {
                note.Duration = duration;
                return note;
            }
            else
            {
                return null;
            }     
        }
    }

    /// <summary>
    /// Fixed Size List implematation
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class LimitedList<T> : List<T>
    {
        private int limit = -1;
        
        public int Limit
        {
            get { return limit; }
            set { limit = value; }
        }

        public LimitedList(int limit) : base(limit)
        {
            this.Limit = limit;
        }

        public new void AddAtStart(T item)
        {

            lock (this)
            {
                while (this.Count >= this.Limit)
                {
                    this.RemoveAt(0);
                }
            }

            base.Add(item);
        }
    }
}
