﻿/*
* This file is Part of Notey
* LGPLv3 Licence:
*       Copyright (c) 2011 
*          Hila Shmuel [notey.recorder@gmail.com]
*          Hananel Hazan [hhazan01@CS.haifa.ac.il]
*          University of Haifa
* This Project is part of our B.Sc. Project course that under supervision
* of Hananel Hazan [hhazan01@CS.haifa.ac.il]
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without 
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice, this list of conditions 
*    and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice, this list of 
*    conditions and the following disclaimer in the documentation and/or other materials provided
*    with the distribution.
* 3. Neither the name of the <ORGANIZATION> nor the names of its contributors may be used to endorse
*    or promote products derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
* OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
* DAMAGE.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Configuration;
using Notes;

namespace Recorder
{
    /// <summary>
    /// FilesHandler exception class
    /// </summary>
    public class FilesHandlerException : System.Exception
    {
        /// <summary>
        /// FilesHandler exception
        /// </summary>
        /// <param name="reason">String describing the cause of the error</param>
        public FilesHandlerException(string reason) : base(reason) { }
    }

    /// <summary>
    /// handle the program's output files formats:
    /// ABC, PostScript, PDF, Wave, MIDI.
    /// given a list of Notes, outputs the file containing
    /// the corresponding music data.
    /// </summary>
    static class FilesHandler
    {
        static public void CreateABCfile(RecordingData recordingData, string ABCfilePath)
        {
            try
            {
                FileStream ABCfile = System.IO.File.Create(ABCfilePath);

                // Write ABC file header
                string endl = "\r\n";
                AddText(ABCfile, "X:1" + endl);
                AddText(ABCfile, "T:" + recordingData.Title + endl);
                AddText(ABCfile, "C:" + recordingData.Composer + endl);
                AddText(ABCfile, "M:C" + endl);
                AddText(ABCfile, "L:1/4" + endl);
                AddText(ABCfile, "K:C" + endl); // Can be C or F

                // Write ABC file data - notes
                foreach (Note note in recordingData.Notes)
                {
                    AddText(ABCfile, note.ABC + " ");
                }

                ABCfile.Close();
            }
            catch (Exception ex)
            {
                string error_message = "FilesHandler Error: create ABC file failed:\n" + ex.Message;
                throw new FilesHandlerException(error_message);
            }
        }

        static public void CreatePostScriptFileFromABC(string ABCfilePath, string postScriptFilePath)
        {
            try
            {
                System.Diagnostics.Process pProcess = new System.Diagnostics.Process();
                pProcess.StartInfo.FileName = Properties.Settings.Default.abcm2psPath;
                pProcess.StartInfo.Arguments = "\"" + ABCfilePath + "\" -O \"" + postScriptFilePath + "\"";
                pProcess.StartInfo.UseShellExecute = false;
                pProcess.StartInfo.RedirectStandardOutput = false;
                pProcess.StartInfo.CreateNoWindow = true;
                pProcess.StartInfo.WorkingDirectory = System.IO.Path.GetTempPath();
                pProcess.Start();
                pProcess.WaitForExit();
            }
            catch (Exception ex)
            {
                string error_message = "FilesHandler Error: Error in convertin from .abc file to .ps file\n" + ex.Message;
                throw new FilesHandlerException(error_message);
            }
        }

        static public void CreatePostScriptfile(RecordingData recordingData, string postScriptFilePath)
        {
            try
            {
                string guid = Guid.NewGuid().ToString();
                string tmpPath = System.IO.Path.GetTempPath();
                string ABCfilePath = tmpPath + guid + ".abc";

                CreateABCfile(recordingData, ABCfilePath);
                CreatePostScriptFileFromABC(ABCfilePath, postScriptFilePath);

                File.Delete(ABCfilePath);
            }
            catch (Exception ex)
            {
                string error_message = "FilesHandler Error: create PostScript file failed:" + ex.Message;
                throw new FilesHandlerException(error_message);
            }
        }

        static public void CreatePDFfileFromPostScript(string postScriptFilePath, string PDFfilePath)
        {
            try
            {
                System.Diagnostics.Process pProcess = new System.Diagnostics.Process();
                pProcess.StartInfo.FileName = Properties.Settings.Default.GhostScriptPath;
                pProcess.StartInfo.Arguments = "-sDEVICE=pdfwrite -o \"" + PDFfilePath + "\" \"" + postScriptFilePath + "\"";
                pProcess.StartInfo.UseShellExecute = false;
                pProcess.StartInfo.RedirectStandardOutput = false;
                pProcess.StartInfo.CreateNoWindow = true;
                pProcess.StartInfo.WorkingDirectory = System.IO.Path.GetTempPath();
                pProcess.Start();
                pProcess.WaitForExit();
            }
            catch (Exception ex)
            {
                string error_message = "FilesHandler Error: Error in convertin from .ps file to .pdf file\n" + ex.Message;
                throw new FilesHandlerException(error_message);
            }
        }

        static public void CreatePDFfileFromABC(string ABCfilePath, string PDFfilePath)
        {
            try
            {
                string guid = Guid.NewGuid().ToString();
                string tmpPath = System.IO.Path.GetTempPath();
                string postScriptFilePath = tmpPath + guid + ".ps";

                CreatePostScriptFileFromABC(ABCfilePath, postScriptFilePath);
                CreatePDFfileFromPostScript(postScriptFilePath, PDFfilePath);

                File.Delete(postScriptFilePath);
            }
            catch (Exception ex)
            {
                string error_message = "FilesHandler Error: converting from .abc to .pdf failed" + ex.Message;
                throw new FilesHandlerException(error_message);
            }
        }

        static public void CreatePDFfile(RecordingData recordingData, string PDFfilePath)
        {
            try
            {
                string guid = Guid.NewGuid().ToString();
                string tmpPath = System.IO.Path.GetTempPath();
                string postScriptFilePath = tmpPath + guid + ".ps";

                CreatePostScriptfile(recordingData, postScriptFilePath);
                CreatePDFfileFromPostScript(postScriptFilePath, PDFfilePath);

                File.Delete(postScriptFilePath);
            }
            catch (Exception ex)
            {
                string error_message = "FilesHandler Error: creating PDF file failed" + ex.Message;
                throw new FilesHandlerException(error_message);
            }
        }

        private static void AddText(System.IO.FileStream fs, string value)
        {
            byte[] info = new UTF8Encoding(true).GetBytes(value);
            fs.Write(info, 0, info.Length);
        }
    }
}
