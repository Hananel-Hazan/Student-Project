﻿/*
* This file is Part of Notey
* LGPLv3 Licence:
*       Copyright (c) 2011 
*          Hila Shmuel [notey.recorder@gmail.com]
*          Hananel Hazan [hhazan01@CS.haifa.ac.il]
*          University of Haifa
* This Project is part of our B.Sc. Project course that under supervision
* of Hananel Hazan [hhazan01@CS.haifa.ac.il]
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without 
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice, this list of conditions 
*    and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice, this list of 
*    conditions and the following disclaimer in the documentation and/or other materials provided
*    with the distribution.
* 3. Neither the name of the <ORGANIZATION> nor the names of its contributors may be used to endorse
*    or promote products derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
* OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
* DAMAGE.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using Notes;

namespace Recorder
{
    enum HoleStatus { Covered, HalfCovered, Uncovered };

    public class RecorderFingeringsException : System.Exception
    {
        public RecorderFingeringsException(string reason) : base(reason) { }
    }


    class FingeringsPicture
    {
        const short recorderHolesNumber = 8;

        Image instrumentPicture;
        RecorderFingerings recorderFingerings;
        RecorderHoles recorderHoles;
        

        public FingeringsPicture()
        {
            instrumentPicture = Recorder.Properties.Resources.RecorderPicture;
            recorderFingerings = new RecorderFingerings(Recorder.Properties.Resources.recorderFingering);
            recorderHoles = new RecorderHoles(Recorder.Properties.Resources.recorderPictureHoles);    
        }

        public void createPicture(Graphics graph, Note note)
        {
            HoleStatus[] fingerings = recorderFingerings.getNoteFingerings(note);
            Image image = new Bitmap(instrumentPicture);
            Graphics ImageGraphics = Graphics.FromImage(image);
            Brush brush = new SolidBrush(Color.Black);

            if (null != fingerings)
            {
                for (byte holeIndex = 0; holeIndex < recorderHolesNumber; holeIndex++)
                {
                    if (fingerings[holeIndex] == HoleStatus.Covered)
                    {
                        ImageGraphics.FillEllipse(brush, recorderHoles.getHoleLocation(holeIndex));
                    }
                    else if (fingerings[holeIndex] == HoleStatus.HalfCovered)
                    {
                        ImageGraphics.FillPie(brush, recorderHoles.getHoleLocation(holeIndex),-90, 180);
                    }
                    else if (fingerings[holeIndex] == HoleStatus.Uncovered)
                    {
                        // do nothing
                    }
                }
            }

            graph.DrawImage(image, 0, 0);
        }
    }

    /// <summary>
    /// given a note & octave, create a picture of the recorder
    /// with the proper fingerings
    /// </summary>
    class RecorderFingerings
    {
        const short MaxMIDI = 100;
        const short recorderHolesNumber = 8;
        HoleStatus[][] fingeringsTable;

        public RecorderFingerings(string recorderFingerings)
        {
            fingeringsTable = new HoleStatus[MaxMIDI][];

            string[] lines = Regex.Split(recorderFingerings, "\r\n");

            foreach (string noteFingering in lines)
            {
                addNoteFingerings(fingeringsTable, noteFingering);
            }
        }

        static private void addNoteFingerings(HoleStatus[][] fingeringsTable, string noteFingering)
        {
            string[] tokens = noteFingering.Split(';');

            short MIDIindex = Convert.ToInt16(tokens[0]);
            fingeringsTable[MIDIindex] = new HoleStatus[recorderHolesNumber];

            for (int i = 0; i < recorderHolesNumber; i++)
            {
                switch (tokens[i + 1])
                {
                    case "c":
                        fingeringsTable[MIDIindex][i] = HoleStatus.Covered;
                        break;
                    case "h":
                        fingeringsTable[MIDIindex][i] = HoleStatus.HalfCovered;
                        break;
                    case "u":
                        fingeringsTable[MIDIindex][i] = HoleStatus.Uncovered;
                        break;
                    default:
                        throw new RecorderFingeringsException("parsing the fingering input invalid" +
                            "for note number: " + tokens[0] + " at index: " + i.ToString());
                }
            }
        }

        public HoleStatus[] getNoteFingerings(Note note)
        {
            if (null == note)
            {
                return null;
            }
            else if (0 <= note.MIDI && note.MIDI < fingeringsTable.Length)
            {
                return fingeringsTable[note.MIDI];
            }
            else
            {
                return null;
            }
        }
    }

    class RecorderHoles
    {
        const short recorderHolesNumber = 8;
        Rectangle[] holesLocationsTable;

        public RecorderHoles(string recorderHoles)
        {
            holesLocationsTable = new Rectangle[recorderHolesNumber];

            string[] lines = Regex.Split(recorderHoles, "\r\n");
            foreach (string holeLocation in lines)
            {
                addHoleLocation(holesLocationsTable, holeLocation);
            }
        }

        static private void addHoleLocation(Rectangle[] holesLocationsTable, string holeLocation)
        {
            string[] tokens = holeLocation.Split(';');

            short holeIndex = Convert.ToInt16(tokens[0]);

            int x = Convert.ToInt16(tokens[1]) -5 ;
            int y = Convert.ToInt16(tokens[2]) -5;
            int width = Convert.ToInt16(tokens[3]);
            int height = Convert.ToInt16(tokens[4]);

            holesLocationsTable[holeIndex] = new Rectangle(x, y, width, height);
        }

        public Rectangle getHoleLocation(short holeIndex)
        {
            return holesLocationsTable[holeIndex];
        }
    }
}
