﻿/*
* This file is Part of Notey
* LGPLv3 Licence:
*       Copyright (c) 2011 
*          Hila Shmuel [notey.recorder@gmail.com]
*          Hananel Hazan [hhazan01@CS.haifa.ac.il]
*          University of Haifa
* This Project is part of our B.Sc. Project course that under supervision
* of Hananel Hazan [hhazan01@CS.haifa.ac.il]
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without 
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice, this list of conditions 
*    and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice, this list of 
*    conditions and the following disclaimer in the documentation and/or other materials provided
*    with the distribution.
* 3. Neither the name of the <ORGANIZATION> nor the names of its contributors may be used to endorse
*    or promote products derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
* OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
* DAMAGE.
*/
using System;
using System.Runtime.InteropServices;
using System.Text;
using System.IO;

namespace Win32
{
    public struct WAVEHDR
    {
        public IntPtr lpData;
        public int dwBufferLength;
        public int dwBytesRecorded;
        public int dwUser;
        public int dwFlags;
        public int dwLoops;
        public int lpNext;
        public int Reserved;
    }

    public struct WAVEINCAPS
    {
        public short wMid;
        public short wPid;
        public int vDriverVersion;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = WinMM.MAXPNAMELEN)]
        public string szPname;
        public int dwFormats;
        public short wChannels;
    }

    public struct WAVEFORMATEX
    {
        public ushort wFormatTag;
        public ushort nChannels;
        public uint nSamplesPerSec;
        public uint nAvgBytesPerSec;
        public ushort nBlockAlign;
        public ushort wBitsPerSample;
        public ushort cbSize;
    }

    public abstract class WinMM
    {
        [DllImport("winmm")] public static extern int waveInGetNumDevs();
        [DllImport("winmm")] public static extern int waveInGetDevCaps(int uDeviceID, ref WAVEINCAPS lpCaps, int uSize);
        [DllImport("winmm")] public static extern int waveInGetErrorText(int err, string lpText, int uSize);
        [DllImport("winmm")] public static extern int waveInOpen(ref IntPtr lphWaveIn, uint DEVICEID, ref WAVEFORMATEX lpWaveFormat, uint dwCallback, uint dwInstance, uint dwFlags);
        [DllImport("winmm")] public static extern int waveInStart(IntPtr hWaveIn);
        [DllImport("winmm")] public static extern int waveInPrepareHeader(IntPtr hWaveIn, ref WAVEHDR lpWaveInHdr, int uSize);
        [DllImport("winmm")] public static extern int waveInAddBuffer(IntPtr hWaveIn, ref WAVEHDR lpWaveInHdr, int uSize);
        [DllImport("winmm")] public static extern int waveInStop(IntPtr hWaveIn);
        [DllImport("winmm")] public static extern int waveInReset(IntPtr hWaveIn);
        [DllImport("winmm")] public static extern int waveInClose(IntPtr hWaveIn);
        [DllImport("winmm")] public static extern int waveInUnprepareHeader(IntPtr hWaveIn, ref WAVEHDR lpWaveInHdr, int uSize);


        public const int MAXPNAMELEN = 32;
        public const int MMSYSERR_NOERROR = 0;
        public const int CALLBACK_NULL = 0x0;
        public const int WAVE_FORMAT_PCM = 1;
        public const int WHDR_DONE = 0x1;

        /* taken from PInvokeLibrary */

        // Can be used instead of a device id to open a device
        public const uint WAVE_MAPPER = unchecked((uint)(-1));

        // Flag specifying the use of a callback window for sound messages
        public const uint CALLBACK_WINDOW = 0x10000;

        // Error information...
        private const int WAVERR_BASE = 32;
        private const int MMSYSERR_BASE = 0;

        // Enum equivalent to MMSYSERR_*
        public enum MMSYSERR : int
        {
            NOERROR = 0,
            ERROR = (MMSYSERR_BASE + 1),
            BADDEVICEID = (MMSYSERR_BASE + 2),
            NOTENABLED = (MMSYSERR_BASE + 3),
            ALLOCATED = (MMSYSERR_BASE + 4),
            INVALHANDLE = (MMSYSERR_BASE + 5),
            NODRIVER = (MMSYSERR_BASE + 6),
            NOMEM = (MMSYSERR_BASE + 7),
            NOTSUPPORTED = (MMSYSERR_BASE + 8),
            BADERRNUM = (MMSYSERR_BASE + 9),
            INVALFLAG = (MMSYSERR_BASE + 10),
            INVALPARAM = (MMSYSERR_BASE + 11),
            HANDLEBUSY = (MMSYSERR_BASE + 12),
            INVALIDALIAS = (MMSYSERR_BASE + 13),
            BADDB = (MMSYSERR_BASE + 14),
            KEYNOTFOUND = (MMSYSERR_BASE + 15),
            READERROR = (MMSYSERR_BASE + 16),
            WRITEERROR = (MMSYSERR_BASE + 17),
            DELETEERROR = (MMSYSERR_BASE + 18),
            VALNOTFOUND = (MMSYSERR_BASE + 19),
            NODRIVERCB = (MMSYSERR_BASE + 20),
            LASTERROR = (MMSYSERR_BASE + 20)
        }

        // Enum equivalent to WAVERR_*
        public enum WAVERR : int
        {
            NONE = 0,
            BADFORMAT = WAVERR_BASE + 0,
            STILLPLAYING = WAVERR_BASE + 1,
            UNPREPARED = WAVERR_BASE + 2,
            SYNC = WAVERR_BASE + 3,
            LASTERROR = WAVERR_BASE + 3
        }

        /// <summary>
        /// Used by dwFormats in WAVEINCAPS and WAVEOUTCAPS
        /// Invalid format
        /// </summary>
        public const uint WAVE_INVALIDFORMAT = 0x00000000;
        /// <summary>
        /// Used by dwFormats in WAVEINCAPS and WAVEOUTCAPS
        /// 11.025 kHz, Mono,   8-bit
        /// </summary>
        public const uint WAVE_FORMAT_1M08 = 0x00000001;
        /// <summary>
        /// Used by dwFormats in WAVEINCAPS and WAVEOUTCAPS
        /// 11.025 kHz, Stereo, 8-bit
        /// </summary>
        public const uint WAVE_FORMAT_1S08 = 0x00000002;
        /// <summary>
        /// Used by dwFormats in WAVEINCAPS and WAVEOUTCAPS
        /// 11.025 kHz, Mono,   16-bit
        /// </summary>
        public const uint WAVE_FORMAT_1M16 = 0x00000004;
        /// <summary>
        /// Used by dwFormats in WAVEINCAPS and WAVEOUTCAPS
        /// 11.025 kHz, Stereo, 16-bit
        /// </summary>
        public const uint WAVE_FORMAT_1S16 = 0x00000008;
        /// <summary>
        /// Used by dwFormats in WAVEINCAPS and WAVEOUTCAPS
        /// 22.05  kHz, Mono,   8-bit
        /// </summary>
        public const uint WAVE_FORMAT_2M08 = 0x00000010;
        /// <summary>
        /// Used by dwFormats in WAVEINCAPS and WAVEOUTCAPS
        /// 22.05  kHz, Stereo, 8-bit
        /// </summary>
        public const uint WAVE_FORMAT_2S08 = 0x00000020;
        /// <summary>
        /// Used by dwFormats in WAVEINCAPS and WAVEOUTCAPS
        /// 22.05  kHz, Mono,   16-bit
        /// </summary>
        public const uint WAVE_FORMAT_2M16 = 0x00000040;
        /// <summary>
        /// Used by dwFormats in WAVEINCAPS and WAVEOUTCAPS
        /// 22.05  kHz, Stereo, 16-bit
        /// </summary>
        public const uint WAVE_FORMAT_2S16 = 0x00000080;
        /// <summary>
        /// Used by dwFormats in WAVEINCAPS and WAVEOUTCAPS
        /// 44.1   kHz, Mono,   8-bit
        /// </summary>
        public const uint WAVE_FORMAT_4M08 = 0x00000100;
        /// <summary>
        /// Used by dwFormats in WAVEINCAPS and WAVEOUTCAPS
        /// 44.1   kHz, Stereo, 8-bit
        /// </summary>
        public const uint WAVE_FORMAT_4S08 = 0x00000200;
        /// <summary>
        /// Used by dwFormats in WAVEINCAPS and WAVEOUTCAPS
        /// 44.1   kHz, Mono,   16-bit
        /// </summary>
        public const uint WAVE_FORMAT_4M16 = 0x00000400;
        /// <summary>
        /// Used by dwFormats in WAVEINCAPS and WAVEOUTCAPS
        /// 44.1   kHz, Stereo, 16-bit
        /// </summary>
        public const uint WAVE_FORMAT_4S16 = 0x00000800;
    }
}

