﻿/*
* This file is Part of Notey
* LGPLv3 Licence:
*       Copyright (c) 2011 
*          Hila Shmuel [notey.recorder@gmail.com]
*          Hananel Hazan [hhazan01@CS.haifa.ac.il]
*          University of Haifa
* This Project is part of our B.Sc. Project course that under supervision
* of Hananel Hazan [hhazan01@CS.haifa.ac.il]
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without 
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice, this list of conditions 
*    and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice, this list of 
*    conditions and the following disclaimer in the documentation and/or other materials provided
*    with the distribution.
* 3. Neither the name of the <ORGANIZATION> nor the names of its contributors may be used to endorse
*    or promote products derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
* OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
* DAMAGE.
*/
namespace Recorder
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.buttonStartRecord = new System.Windows.Forms.Button();
            this.buttonStopRecord = new System.Windows.Forms.Button();
            this.textBoxPitch = new System.Windows.Forms.TextBox();
            this.labelPitch = new System.Windows.Forms.Label();
            this.textBoxNote = new System.Windows.Forms.TextBox();
            this.labelNote = new System.Windows.Forms.Label();
            this.tabPagePdfMusicSheet = new System.Windows.Forms.TabPage();
            this.splitContainerMusicSheet = new System.Windows.Forms.SplitContainer();
            this.toolStripMusicSheet = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonRefresh = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabelTitle = new System.Windows.Forms.ToolStripLabel();
            this.toolStripTextBoxTitle = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabelComposer = new System.Windows.Forms.ToolStripLabel();
            this.toolStripTextBoxComposer = new System.Windows.Forms.ToolStripTextBox();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPageNotes = new System.Windows.Forms.TabPage();
            this.panelNotes = new System.Windows.Forms.Panel();
            this.tabPageWaveform = new System.Windows.Forms.TabPage();
            this.splitContainerWaveform = new System.Windows.Forms.SplitContainer();
            this.labelTimeDomain = new System.Windows.Forms.Label();
            this.pictureBoxTimeDomain = new System.Windows.Forms.PictureBox();
            this.labelFrequencyDomain = new System.Windows.Forms.Label();
            this.pictureBoxFrequencyDomain = new System.Windows.Forms.PictureBox();
            this.tabPageFingering = new System.Windows.Forms.TabPage();
            this.splitContainerFingering = new System.Windows.Forms.SplitContainer();
            this.labelFingeringChartSubTitle = new System.Windows.Forms.Label();
            this.labelFingeringChartTitle = new System.Windows.Forms.Label();
            this.tabPageRecorderHero = new System.Windows.Forms.TabPage();
            this.splitContainerRecorderHero = new System.Windows.Forms.SplitContainer();
            this.trackBarRecorderHero = new System.Windows.Forms.TrackBar();
            this.textBoxMIDI = new System.Windows.Forms.TextBox();
            this.labelMIDI = new System.Windows.Forms.Label();
            this.buttonStartPlayingRecord = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.buttonSaveRecord = new System.Windows.Forms.Button();
            this.buttonNewRecord = new System.Windows.Forms.Button();
            this.buttonOpenFile = new System.Windows.Forms.Button();
            this.buttonPausePlayingRecord = new System.Windows.Forms.Button();
            this.buttonStopPlayingRecord = new System.Windows.Forms.Button();
            this.comboBoxPlayingRecordFormats = new System.Windows.Forms.ComboBox();
            this.groupBoxRecord = new System.Windows.Forms.GroupBox();
            this.comboBoxInputDevices = new System.Windows.Forms.ComboBox();
            this.groupBoxPlayingRecord = new System.Windows.Forms.GroupBox();
            this.groupBoxFileRecord = new System.Windows.Forms.GroupBox();
            this.pictureBoxRecorder = new System.Windows.Forms.PictureBox();
            this.openFileDialogABC = new System.Windows.Forms.OpenFileDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ConfigurationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPagePdfMusicSheet.SuspendLayout();
            this.splitContainerMusicSheet.Panel1.SuspendLayout();
            this.splitContainerMusicSheet.Panel2.SuspendLayout();
            this.splitContainerMusicSheet.SuspendLayout();
            this.toolStripMusicSheet.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.tabPageNotes.SuspendLayout();
            this.tabPageWaveform.SuspendLayout();
            this.splitContainerWaveform.Panel1.SuspendLayout();
            this.splitContainerWaveform.Panel2.SuspendLayout();
            this.splitContainerWaveform.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTimeDomain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFrequencyDomain)).BeginInit();
            this.tabPageFingering.SuspendLayout();
            this.splitContainerFingering.Panel1.SuspendLayout();
            this.splitContainerFingering.SuspendLayout();
            this.tabPageRecorderHero.SuspendLayout();
            this.splitContainerRecorderHero.Panel2.SuspendLayout();
            this.splitContainerRecorderHero.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarRecorderHero)).BeginInit();
            this.groupBoxRecord.SuspendLayout();
            this.groupBoxPlayingRecord.SuspendLayout();
            this.groupBoxFileRecord.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRecorder)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonStartRecord
            // 
            this.buttonStartRecord.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.buttonStartRecord.FlatAppearance.BorderSize = 0;
            this.buttonStartRecord.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Control;
            this.buttonStartRecord.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control;
            this.buttonStartRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonStartRecord.Image = global::Recorder.Properties.Resources.Microphone_icon;
            this.buttonStartRecord.Location = new System.Drawing.Point(6, 18);
            this.buttonStartRecord.Name = "buttonStartRecord";
            this.buttonStartRecord.Size = new System.Drawing.Size(48, 48);
            this.buttonStartRecord.TabIndex = 2;
            this.toolTip1.SetToolTip(this.buttonStartRecord, "start recording the recorder");
            this.buttonStartRecord.UseVisualStyleBackColor = true;
            this.buttonStartRecord.Click += new System.EventHandler(this.buttonStartRecord_Click);
            // 
            // buttonStopRecord
            // 
            this.buttonStopRecord.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.buttonStopRecord.FlatAppearance.BorderSize = 0;
            this.buttonStopRecord.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Control;
            this.buttonStopRecord.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control;
            this.buttonStopRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonStopRecord.Image = global::Recorder.Properties.Resources.stop_red_icon;
            this.buttonStopRecord.Location = new System.Drawing.Point(60, 18);
            this.buttonStopRecord.Name = "buttonStopRecord";
            this.buttonStopRecord.Size = new System.Drawing.Size(48, 48);
            this.buttonStopRecord.TabIndex = 3;
            this.toolTip1.SetToolTip(this.buttonStopRecord, "stop the recording");
            this.buttonStopRecord.UseVisualStyleBackColor = true;
            this.buttonStopRecord.Click += new System.EventHandler(this.buttonStopRecord_Click);
            // 
            // textBoxPitch
            // 
            this.textBoxPitch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxPitch.Enabled = false;
            this.textBoxPitch.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPitch.Location = new System.Drawing.Point(843, 31);
            this.textBoxPitch.Name = "textBoxPitch";
            this.textBoxPitch.Size = new System.Drawing.Size(91, 32);
            this.textBoxPitch.TabIndex = 4;
            this.textBoxPitch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxPitch.TextChanged += new System.EventHandler(this.textBoxPitch_TextChanged);
            // 
            // labelPitch
            // 
            this.labelPitch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelPitch.AutoSize = true;
            this.labelPitch.Location = new System.Drawing.Point(809, 42);
            this.labelPitch.Name = "labelPitch";
            this.labelPitch.Size = new System.Drawing.Size(30, 13);
            this.labelPitch.TabIndex = 5;
            this.labelPitch.Text = "pitch";
            // 
            // textBoxNote
            // 
            this.textBoxNote.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxNote.Enabled = false;
            this.textBoxNote.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold);
            this.textBoxNote.Location = new System.Drawing.Point(843, 69);
            this.textBoxNote.Name = "textBoxNote";
            this.textBoxNote.Size = new System.Drawing.Size(91, 32);
            this.textBoxNote.TabIndex = 6;
            this.textBoxNote.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelNote
            // 
            this.labelNote.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelNote.AutoSize = true;
            this.labelNote.Location = new System.Drawing.Point(809, 80);
            this.labelNote.Name = "labelNote";
            this.labelNote.Size = new System.Drawing.Size(28, 13);
            this.labelNote.TabIndex = 7;
            this.labelNote.Text = "note";
            // 
            // tabPagePdfMusicSheet
            // 
            this.tabPagePdfMusicSheet.Controls.Add(this.splitContainerMusicSheet);
            this.tabPagePdfMusicSheet.Location = new System.Drawing.Point(4, 24);
            this.tabPagePdfMusicSheet.Name = "tabPagePdfMusicSheet";
            this.tabPagePdfMusicSheet.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePdfMusicSheet.Size = new System.Drawing.Size(805, 571);
            this.tabPagePdfMusicSheet.TabIndex = 1;
            this.tabPagePdfMusicSheet.Text = "Music Sheet";
            this.toolTip1.SetToolTip(this.tabPagePdfMusicSheet, "show the recorded music sheet in pdf format");
            this.tabPagePdfMusicSheet.ToolTipText = "show the recorded music sheet in pdf format";
            this.tabPagePdfMusicSheet.UseVisualStyleBackColor = true;
            // 
            // splitContainerMusicSheet
            // 
            this.splitContainerMusicSheet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerMusicSheet.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainerMusicSheet.Location = new System.Drawing.Point(3, 3);
            this.splitContainerMusicSheet.Name = "splitContainerMusicSheet";
            this.splitContainerMusicSheet.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainerMusicSheet.Panel1
            // 
            this.splitContainerMusicSheet.Panel1.Controls.Add(this.toolStripMusicSheet);
            // 
            // splitContainerMusicSheet.Panel2
            // 
            this.splitContainerMusicSheet.Panel2.Controls.Add(this.webBrowser1);
            this.splitContainerMusicSheet.Size = new System.Drawing.Size(799, 565);
            this.splitContainerMusicSheet.SplitterDistance = 25;
            this.splitContainerMusicSheet.TabIndex = 0;
            // 
            // toolStripMusicSheet
            // 
            this.toolStripMusicSheet.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonRefresh,
            this.toolStripSeparator3,
            this.toolStripLabelTitle,
            this.toolStripTextBoxTitle,
            this.toolStripSeparator4,
            this.toolStripLabelComposer,
            this.toolStripTextBoxComposer});
            this.toolStripMusicSheet.Location = new System.Drawing.Point(0, 0);
            this.toolStripMusicSheet.Name = "toolStripMusicSheet";
            this.toolStripMusicSheet.Size = new System.Drawing.Size(799, 25);
            this.toolStripMusicSheet.TabIndex = 0;
            this.toolStripMusicSheet.Text = "toolStripMusicSheet";
            // 
            // toolStripButtonRefresh
            // 
            this.toolStripButtonRefresh.Image = global::Recorder.Properties.Resources.refresh;
            this.toolStripButtonRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonRefresh.Name = "toolStripButtonRefresh";
            this.toolStripButtonRefresh.Size = new System.Drawing.Size(66, 22);
            this.toolStripButtonRefresh.Text = "Refresh";
            this.toolStripButtonRefresh.ToolTipText = "Load a PDF with the music sheet";
            this.toolStripButtonRefresh.Click += new System.EventHandler(this.toolStripButtonRefresh_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabelTitle
            // 
            this.toolStripLabelTitle.Name = "toolStripLabelTitle";
            this.toolStripLabelTitle.Size = new System.Drawing.Size(30, 22);
            this.toolStripLabelTitle.Text = "Title";
            // 
            // toolStripTextBoxTitle
            // 
            this.toolStripTextBoxTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toolStripTextBoxTitle.Name = "toolStripTextBoxTitle";
            this.toolStripTextBoxTitle.Size = new System.Drawing.Size(100, 25);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabelComposer
            // 
            this.toolStripLabelComposer.Name = "toolStripLabelComposer";
            this.toolStripLabelComposer.Size = new System.Drawing.Size(62, 22);
            this.toolStripLabelComposer.Text = "Composer";
            // 
            // toolStripTextBoxComposer
            // 
            this.toolStripTextBoxComposer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toolStripTextBoxComposer.Name = "toolStripTextBoxComposer";
            this.toolStripTextBoxComposer.Size = new System.Drawing.Size(100, 25);
            // 
            // webBrowser1
            // 
            this.webBrowser1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser1.Location = new System.Drawing.Point(0, 0);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(799, 536);
            this.webBrowser1.TabIndex = 0;
            this.toolTip1.SetToolTip(this.webBrowser1, "a pdf of the notes currently playing");
            this.webBrowser1.WebBrowserShortcutsEnabled = false;
            // 
            // tabControl
            // 
            this.tabControl.AccessibleName = "tabControl";
            this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl.Controls.Add(this.tabPageNotes);
            this.tabControl.Controls.Add(this.tabPageWaveform);
            this.tabControl.Controls.Add(this.tabPageFingering);
            this.tabControl.Controls.Add(this.tabPagePdfMusicSheet);
            this.tabControl.Controls.Add(this.tabPageRecorderHero);
            this.tabControl.HotTrack = true;
            this.tabControl.ItemSize = new System.Drawing.Size(100, 20);
            this.tabControl.Location = new System.Drawing.Point(12, 114);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.ShowToolTips = true;
            this.tabControl.Size = new System.Drawing.Size(813, 599);
            this.tabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl.TabIndex = 0;
            this.tabControl.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl_Selected);
            // 
            // tabPageNotes
            // 
            this.tabPageNotes.AccessibleName = "tabPageNotes";
            this.tabPageNotes.BackColor = System.Drawing.Color.White;
            this.tabPageNotes.Controls.Add(this.panelNotes);
            this.tabPageNotes.Location = new System.Drawing.Point(4, 24);
            this.tabPageNotes.Name = "tabPageNotes";
            this.tabPageNotes.Size = new System.Drawing.Size(805, 571);
            this.tabPageNotes.TabIndex = 2;
            this.tabPageNotes.Text = "Notes";
            this.toolTip1.SetToolTip(this.tabPageNotes, "an interactive music sheet, present the notes currently played by the recorder");
            this.tabPageNotes.ToolTipText = "an interactive music sheet, present the notes currently played by the recorder";
            // 
            // panelNotes
            // 
            this.panelNotes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelNotes.Location = new System.Drawing.Point(0, 0);
            this.panelNotes.Name = "panelNotes";
            this.panelNotes.Size = new System.Drawing.Size(805, 571);
            this.panelNotes.TabIndex = 0;
            this.panelNotes.Paint += new System.Windows.Forms.PaintEventHandler(this.panelMusicSheet_Paint);
            // 
            // tabPageWaveform
            // 
            this.tabPageWaveform.AccessibleName = "";
            this.tabPageWaveform.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(40)))), ((int)(((byte)(34)))));
            this.tabPageWaveform.Controls.Add(this.splitContainerWaveform);
            this.tabPageWaveform.Location = new System.Drawing.Point(4, 24);
            this.tabPageWaveform.Name = "tabPageWaveform";
            this.tabPageWaveform.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageWaveform.Size = new System.Drawing.Size(805, 571);
            this.tabPageWaveform.TabIndex = 0;
            this.tabPageWaveform.Text = "Waveform";
            this.toolTip1.SetToolTip(this.tabPageWaveform, "show the waveform and its frequency spectrum");
            this.tabPageWaveform.ToolTipText = "show the waveform and its frequency spectrum";
            // 
            // splitContainerWaveform
            // 
            this.splitContainerWaveform.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerWaveform.IsSplitterFixed = true;
            this.splitContainerWaveform.Location = new System.Drawing.Point(3, 3);
            this.splitContainerWaveform.Name = "splitContainerWaveform";
            this.splitContainerWaveform.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainerWaveform.Panel1
            // 
            this.splitContainerWaveform.Panel1.Controls.Add(this.labelTimeDomain);
            this.splitContainerWaveform.Panel1.Controls.Add(this.pictureBoxTimeDomain);
            // 
            // splitContainerWaveform.Panel2
            // 
            this.splitContainerWaveform.Panel2.Controls.Add(this.labelFrequencyDomain);
            this.splitContainerWaveform.Panel2.Controls.Add(this.pictureBoxFrequencyDomain);
            this.splitContainerWaveform.Size = new System.Drawing.Size(799, 565);
            this.splitContainerWaveform.SplitterDistance = 286;
            this.splitContainerWaveform.SplitterWidth = 1;
            this.splitContainerWaveform.TabIndex = 0;
            // 
            // labelTimeDomain
            // 
            this.labelTimeDomain.AutoSize = true;
            this.labelTimeDomain.BackColor = System.Drawing.Color.Transparent;
            this.labelTimeDomain.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTimeDomain.ForeColor = System.Drawing.Color.LemonChiffon;
            this.labelTimeDomain.Location = new System.Drawing.Point(0, 0);
            this.labelTimeDomain.Name = "labelTimeDomain";
            this.labelTimeDomain.Size = new System.Drawing.Size(84, 14);
            this.labelTimeDomain.TabIndex = 1;
            this.labelTimeDomain.Text = "Time Domain";
            // 
            // pictureBoxTimeDomain
            // 
            this.pictureBoxTimeDomain.AccessibleDescription = "pictureBoxTimeDomain";
            this.pictureBoxTimeDomain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxTimeDomain.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxTimeDomain.Name = "pictureBoxTimeDomain";
            this.pictureBoxTimeDomain.Size = new System.Drawing.Size(799, 286);
            this.pictureBoxTimeDomain.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxTimeDomain.TabIndex = 0;
            this.pictureBoxTimeDomain.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBoxTimeDomain, "displays the sound wave, on real-time");
            this.pictureBoxTimeDomain.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBoxTimeDomain_Paint);
            // 
            // labelFrequencyDomain
            // 
            this.labelFrequencyDomain.AutoSize = true;
            this.labelFrequencyDomain.BackColor = System.Drawing.Color.Transparent;
            this.labelFrequencyDomain.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFrequencyDomain.ForeColor = System.Drawing.Color.LemonChiffon;
            this.labelFrequencyDomain.Location = new System.Drawing.Point(-3, 2);
            this.labelFrequencyDomain.Name = "labelFrequencyDomain";
            this.labelFrequencyDomain.Size = new System.Drawing.Size(119, 14);
            this.labelFrequencyDomain.TabIndex = 1;
            this.labelFrequencyDomain.Text = "Frequency Domain";
            // 
            // pictureBoxFrequencyDomain
            // 
            this.pictureBoxFrequencyDomain.AccessibleDescription = "pictureBoxFrequencyDomain";
            this.pictureBoxFrequencyDomain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxFrequencyDomain.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxFrequencyDomain.Name = "pictureBoxFrequencyDomain";
            this.pictureBoxFrequencyDomain.Size = new System.Drawing.Size(799, 278);
            this.pictureBoxFrequencyDomain.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxFrequencyDomain.TabIndex = 0;
            this.pictureBoxFrequencyDomain.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBoxFrequencyDomain, "the sound wave frequency analysis");
            this.pictureBoxFrequencyDomain.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBoxFrequencyDomain_Paint);
            // 
            // tabPageFingering
            // 
            this.tabPageFingering.Controls.Add(this.splitContainerFingering);
            this.tabPageFingering.Location = new System.Drawing.Point(4, 24);
            this.tabPageFingering.Name = "tabPageFingering";
            this.tabPageFingering.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageFingering.Size = new System.Drawing.Size(805, 571);
            this.tabPageFingering.TabIndex = 3;
            this.tabPageFingering.Text = "Fingering";
            this.toolTip1.SetToolTip(this.tabPageFingering, "an interactive recorder fingering chart");
            this.tabPageFingering.ToolTipText = "an interactive recorder fingering chart";
            this.tabPageFingering.UseVisualStyleBackColor = true;
            // 
            // splitContainerFingering
            // 
            this.splitContainerFingering.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerFingering.Location = new System.Drawing.Point(3, 3);
            this.splitContainerFingering.Name = "splitContainerFingering";
            this.splitContainerFingering.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainerFingering.Panel1
            // 
            this.splitContainerFingering.Panel1.Controls.Add(this.labelFingeringChartSubTitle);
            this.splitContainerFingering.Panel1.Controls.Add(this.labelFingeringChartTitle);
            // 
            // splitContainerFingering.Panel2
            // 
            this.splitContainerFingering.Panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainerFingering_Panel2_Paint);
            this.splitContainerFingering.Panel2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.splitContainerFingering_Panel2_MouseMove);
            this.splitContainerFingering.Size = new System.Drawing.Size(799, 565);
            this.splitContainerFingering.SplitterDistance = 96;
            this.splitContainerFingering.TabIndex = 0;
            // 
            // labelFingeringChartSubTitle
            // 
            this.labelFingeringChartSubTitle.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelFingeringChartSubTitle.AutoSize = true;
            this.labelFingeringChartSubTitle.Font = new System.Drawing.Font("Gisha", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFingeringChartSubTitle.Location = new System.Drawing.Point(271, 53);
            this.labelFingeringChartSubTitle.Name = "labelFingeringChartSubTitle";
            this.labelFingeringChartSubTitle.Size = new System.Drawing.Size(281, 15);
            this.labelFingeringChartSubTitle.TabIndex = 1;
            this.labelFingeringChartSubTitle.Text = "Move your mouse to display the note fingering";
            // 
            // labelFingeringChartTitle
            // 
            this.labelFingeringChartTitle.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelFingeringChartTitle.AutoSize = true;
            this.labelFingeringChartTitle.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFingeringChartTitle.Location = new System.Drawing.Point(204, 16);
            this.labelFingeringChartTitle.Name = "labelFingeringChartTitle";
            this.labelFingeringChartTitle.Size = new System.Drawing.Size(410, 37);
            this.labelFingeringChartTitle.TabIndex = 0;
            this.labelFingeringChartTitle.Text = "Interactive Recorder Fingering Chart";
            this.labelFingeringChartTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPageRecorderHero
            // 
            this.tabPageRecorderHero.Controls.Add(this.splitContainerRecorderHero);
            this.tabPageRecorderHero.Location = new System.Drawing.Point(4, 24);
            this.tabPageRecorderHero.Name = "tabPageRecorderHero";
            this.tabPageRecorderHero.Size = new System.Drawing.Size(805, 571);
            this.tabPageRecorderHero.TabIndex = 4;
            this.tabPageRecorderHero.Text = "RecorderHero";
            this.toolTip1.SetToolTip(this.tabPageRecorderHero, "like guitarHero, but for recorder");
            this.tabPageRecorderHero.UseVisualStyleBackColor = true;
            // 
            // splitContainerRecorderHero
            // 
            this.splitContainerRecorderHero.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerRecorderHero.Location = new System.Drawing.Point(0, 0);
            this.splitContainerRecorderHero.Name = "splitContainerRecorderHero";
            this.splitContainerRecorderHero.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainerRecorderHero.Panel1
            // 
            this.splitContainerRecorderHero.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainerRecorderHero_Panel1_Paint);
            // 
            // splitContainerRecorderHero.Panel2
            // 
            this.splitContainerRecorderHero.Panel2.Controls.Add(this.trackBarRecorderHero);
            this.splitContainerRecorderHero.Size = new System.Drawing.Size(805, 571);
            this.splitContainerRecorderHero.SplitterDistance = 541;
            this.splitContainerRecorderHero.TabIndex = 0;
            // 
            // trackBarRecorderHero
            // 
            this.trackBarRecorderHero.Dock = System.Windows.Forms.DockStyle.Fill;
            this.trackBarRecorderHero.Location = new System.Drawing.Point(0, 0);
            this.trackBarRecorderHero.Maximum = 100;
            this.trackBarRecorderHero.Name = "trackBarRecorderHero";
            this.trackBarRecorderHero.Size = new System.Drawing.Size(805, 26);
            this.trackBarRecorderHero.TabIndex = 0;
            this.toolTip1.SetToolTip(this.trackBarRecorderHero, "Speed up or down the music notes iteration");
            this.trackBarRecorderHero.Value = 50;
            this.trackBarRecorderHero.ValueChanged += new System.EventHandler(this.trackBarRecorderHero_ValueChanged);
            // 
            // textBoxMIDI
            // 
            this.textBoxMIDI.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxMIDI.Enabled = false;
            this.textBoxMIDI.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold);
            this.textBoxMIDI.Location = new System.Drawing.Point(843, 107);
            this.textBoxMIDI.Name = "textBoxMIDI";
            this.textBoxMIDI.Size = new System.Drawing.Size(91, 32);
            this.textBoxMIDI.TabIndex = 11;
            this.textBoxMIDI.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelMIDI
            // 
            this.labelMIDI.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelMIDI.AutoSize = true;
            this.labelMIDI.Location = new System.Drawing.Point(809, 114);
            this.labelMIDI.Name = "labelMIDI";
            this.labelMIDI.Size = new System.Drawing.Size(30, 13);
            this.labelMIDI.TabIndex = 12;
            this.labelMIDI.Text = "MIDI";
            // 
            // buttonStartPlayingRecord
            // 
            this.buttonStartPlayingRecord.Enabled = false;
            this.buttonStartPlayingRecord.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.buttonStartPlayingRecord.FlatAppearance.BorderSize = 0;
            this.buttonStartPlayingRecord.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Control;
            this.buttonStartPlayingRecord.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control;
            this.buttonStartPlayingRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonStartPlayingRecord.Font = new System.Drawing.Font("Webdings", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.buttonStartPlayingRecord.Image = global::Recorder.Properties.Resources.Play_icon;
            this.buttonStartPlayingRecord.Location = new System.Drawing.Point(6, 18);
            this.buttonStartPlayingRecord.Name = "buttonStartPlayingRecord";
            this.buttonStartPlayingRecord.Size = new System.Drawing.Size(48, 48);
            this.buttonStartPlayingRecord.TabIndex = 13;
            this.toolTip1.SetToolTip(this.buttonStartPlayingRecord, "play the last record");
            this.buttonStartPlayingRecord.UseVisualStyleBackColor = false;
            this.buttonStartPlayingRecord.Click += new System.EventHandler(this.buttonPlayRecord_Click);
            // 
            // buttonSaveRecord
            // 
            this.buttonSaveRecord.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.buttonSaveRecord.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Control;
            this.buttonSaveRecord.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control;
            this.buttonSaveRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveRecord.ForeColor = System.Drawing.Color.Transparent;
            this.buttonSaveRecord.Image = global::Recorder.Properties.Resources.Devices_media_floppy_icon;
            this.buttonSaveRecord.Location = new System.Drawing.Point(6, 15);
            this.buttonSaveRecord.Name = "buttonSaveRecord";
            this.buttonSaveRecord.Size = new System.Drawing.Size(48, 48);
            this.buttonSaveRecord.TabIndex = 17;
            this.toolTip1.SetToolTip(this.buttonSaveRecord, "Save Recording As...");
            this.buttonSaveRecord.UseVisualStyleBackColor = true;
            this.buttonSaveRecord.EnabledChanged += new System.EventHandler(this.buttonSaveRecord_EnabledChanged);
            this.buttonSaveRecord.Click += new System.EventHandler(this.buttonSaveRecord_Click);
            // 
            // buttonNewRecord
            // 
            this.buttonNewRecord.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.buttonNewRecord.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Control;
            this.buttonNewRecord.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control;
            this.buttonNewRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonNewRecord.ForeColor = System.Drawing.Color.Transparent;
            this.buttonNewRecord.Image = global::Recorder.Properties.Resources.File_Types_MIDI_icon;
            this.buttonNewRecord.Location = new System.Drawing.Point(60, 15);
            this.buttonNewRecord.Name = "buttonNewRecord";
            this.buttonNewRecord.Size = new System.Drawing.Size(48, 48);
            this.buttonNewRecord.TabIndex = 17;
            this.toolTip1.SetToolTip(this.buttonNewRecord, "New Record");
            this.buttonNewRecord.UseVisualStyleBackColor = true;
            this.buttonNewRecord.Click += new System.EventHandler(this.buttonNewRecord_Click);
            // 
            // buttonOpenFile
            // 
            this.buttonOpenFile.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.buttonOpenFile.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Control;
            this.buttonOpenFile.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control;
            this.buttonOpenFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonOpenFile.ForeColor = System.Drawing.Color.Transparent;
            this.buttonOpenFile.Image = global::Recorder.Properties.Resources.lock__noteDrawer_;
            this.buttonOpenFile.Location = new System.Drawing.Point(114, 15);
            this.buttonOpenFile.Name = "buttonOpenFile";
            this.buttonOpenFile.Size = new System.Drawing.Size(48, 48);
            this.buttonOpenFile.TabIndex = 17;
            this.toolTip1.SetToolTip(this.buttonOpenFile, "Open ABC file");
            this.buttonOpenFile.UseVisualStyleBackColor = true;
            this.buttonOpenFile.Click += new System.EventHandler(this.buttonOpenFile_Click);
            // 
            // buttonPausePlayingRecord
            // 
            this.buttonPausePlayingRecord.Enabled = false;
            this.buttonPausePlayingRecord.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.buttonPausePlayingRecord.FlatAppearance.BorderSize = 0;
            this.buttonPausePlayingRecord.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Control;
            this.buttonPausePlayingRecord.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control;
            this.buttonPausePlayingRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPausePlayingRecord.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.buttonPausePlayingRecord.Image = global::Recorder.Properties.Resources.Pause_icon;
            this.buttonPausePlayingRecord.Location = new System.Drawing.Point(60, 18);
            this.buttonPausePlayingRecord.Name = "buttonPausePlayingRecord";
            this.buttonPausePlayingRecord.Size = new System.Drawing.Size(48, 48);
            this.buttonPausePlayingRecord.TabIndex = 13;
            this.buttonPausePlayingRecord.UseVisualStyleBackColor = false;
            this.buttonPausePlayingRecord.Click += new System.EventHandler(this.buttonPausePlayingRecord_Click);
            // 
            // buttonStopPlayingRecord
            // 
            this.buttonStopPlayingRecord.Enabled = false;
            this.buttonStopPlayingRecord.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.buttonStopPlayingRecord.FlatAppearance.BorderSize = 0;
            this.buttonStopPlayingRecord.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Control;
            this.buttonStopPlayingRecord.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control;
            this.buttonStopPlayingRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonStopPlayingRecord.Font = new System.Drawing.Font("Webdings", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.buttonStopPlayingRecord.Image = global::Recorder.Properties.Resources.Stop_icon;
            this.buttonStopPlayingRecord.Location = new System.Drawing.Point(114, 18);
            this.buttonStopPlayingRecord.Name = "buttonStopPlayingRecord";
            this.buttonStopPlayingRecord.Size = new System.Drawing.Size(48, 48);
            this.buttonStopPlayingRecord.TabIndex = 13;
            this.buttonStopPlayingRecord.UseVisualStyleBackColor = false;
            this.buttonStopPlayingRecord.Click += new System.EventHandler(this.buttonStopPlayingRecord_Click);
            // 
            // comboBoxPlayingRecordFormats
            // 
            this.comboBoxPlayingRecordFormats.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxPlayingRecordFormats.FormattingEnabled = true;
            this.comboBoxPlayingRecordFormats.Location = new System.Drawing.Point(178, 29);
            this.comboBoxPlayingRecordFormats.Name = "comboBoxPlayingRecordFormats";
            this.comboBoxPlayingRecordFormats.Size = new System.Drawing.Size(138, 21);
            this.comboBoxPlayingRecordFormats.TabIndex = 14;
            // 
            // groupBoxRecord
            // 
            this.groupBoxRecord.Controls.Add(this.buttonStartRecord);
            this.groupBoxRecord.Controls.Add(this.buttonStopRecord);
            this.groupBoxRecord.Controls.Add(this.comboBoxInputDevices);
            this.groupBoxRecord.Location = new System.Drawing.Point(12, 31);
            this.groupBoxRecord.Name = "groupBoxRecord";
            this.groupBoxRecord.Size = new System.Drawing.Size(271, 72);
            this.groupBoxRecord.TabIndex = 15;
            this.groupBoxRecord.TabStop = false;
            this.groupBoxRecord.Text = "Record";
            // 
            // comboBoxInputDevices
            // 
            this.comboBoxInputDevices.AccessibleName = "";
            this.comboBoxInputDevices.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxInputDevices.FormattingEnabled = true;
            this.comboBoxInputDevices.IntegralHeight = false;
            this.comboBoxInputDevices.ItemHeight = 13;
            this.comboBoxInputDevices.Location = new System.Drawing.Point(124, 29);
            this.comboBoxInputDevices.MaxDropDownItems = 10;
            this.comboBoxInputDevices.Name = "comboBoxInputDevices";
            this.comboBoxInputDevices.Size = new System.Drawing.Size(141, 21);
            this.comboBoxInputDevices.TabIndex = 8;
            this.comboBoxInputDevices.SelectedIndexChanged += new System.EventHandler(this.comboBoxInputDevices_SelectedIndexChanged);
            // 
            // groupBoxPlayingRecord
            // 
            this.groupBoxPlayingRecord.Controls.Add(this.buttonStartPlayingRecord);
            this.groupBoxPlayingRecord.Controls.Add(this.comboBoxPlayingRecordFormats);
            this.groupBoxPlayingRecord.Controls.Add(this.buttonPausePlayingRecord);
            this.groupBoxPlayingRecord.Controls.Add(this.buttonStopPlayingRecord);
            this.groupBoxPlayingRecord.Location = new System.Drawing.Point(289, 31);
            this.groupBoxPlayingRecord.Name = "groupBoxPlayingRecord";
            this.groupBoxPlayingRecord.Size = new System.Drawing.Size(322, 72);
            this.groupBoxPlayingRecord.TabIndex = 16;
            this.groupBoxPlayingRecord.TabStop = false;
            this.groupBoxPlayingRecord.Text = "Play";
            // 
            // groupBoxFileRecord
            // 
            this.groupBoxFileRecord.Controls.Add(this.buttonOpenFile);
            this.groupBoxFileRecord.Controls.Add(this.buttonNewRecord);
            this.groupBoxFileRecord.Controls.Add(this.buttonSaveRecord);
            this.groupBoxFileRecord.Location = new System.Drawing.Point(617, 31);
            this.groupBoxFileRecord.Name = "groupBoxFileRecord";
            this.groupBoxFileRecord.Size = new System.Drawing.Size(173, 72);
            this.groupBoxFileRecord.TabIndex = 2;
            this.groupBoxFileRecord.TabStop = false;
            this.groupBoxFileRecord.Text = "File";
            // 
            // pictureBoxRecorder
            // 
            this.pictureBoxRecorder.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.pictureBoxRecorder.BackgroundImage = global::Recorder.Properties.Resources.RecorderPicture;
            this.pictureBoxRecorder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxRecorder.Location = new System.Drawing.Point(841, 163);
            this.pictureBoxRecorder.Name = "pictureBoxRecorder";
            this.pictureBoxRecorder.Size = new System.Drawing.Size(93, 467);
            this.pictureBoxRecorder.TabIndex = 9;
            this.pictureBoxRecorder.TabStop = false;
            // 
            // openFileDialogABC
            // 
            this.openFileDialogABC.FileName = "song.abc";
            this.openFileDialogABC.Filter = "ABC files|*.abc";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(948, 24);
            this.menuStrip1.TabIndex = 17;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem,
            this.toolStripSeparator,
            this.saveToolStripMenuItem,
            this.toolStripSeparator1,
            this.printToolStripMenuItem,
            this.printPreviewToolStripMenuItem,
            this.toolStripSeparator2,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("newToolStripMenuItem.Image")));
            this.newToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.newToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.newToolStripMenuItem.Text = "&New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click_1);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("openToolStripMenuItem.Image")));
            this.openToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.openToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.openToolStripMenuItem.Text = "&Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click_1);
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(149, 6);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("saveToolStripMenuItem.Image")));
            this.saveToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.saveToolStripMenuItem.Text = "&Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click_1);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Enabled = false;
            this.printToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("printToolStripMenuItem.Image")));
            this.printToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.printToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.printToolStripMenuItem.Text = "&Print";
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Enabled = false;
            this.printPreviewToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("printPreviewToolStripMenuItem.Image")));
            this.printPreviewToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.printPreviewToolStripMenuItem.Text = "Print Pre&view";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(149, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click_1);
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ConfigurationToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.toolsToolStripMenuItem.Text = "&Tools";
            // 
            // ConfigurationToolStripMenuItem
            // 
            this.ConfigurationToolStripMenuItem.Name = "ConfigurationToolStripMenuItem";
            this.ConfigurationToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.ConfigurationToolStripMenuItem.Text = "&Configuration";
            this.ConfigurationToolStripMenuItem.Click += new System.EventHandler(this.ConfigurationToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contentsToolStripMenuItem,
            this.toolStripSeparator5,
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // contentsToolStripMenuItem
            // 
            this.contentsToolStripMenuItem.Name = "contentsToolStripMenuItem";
            this.contentsToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.contentsToolStripMenuItem.Text = "&Contents";
            this.contentsToolStripMenuItem.Click += new System.EventHandler(this.contentsToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(119, 6);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.aboutToolStripMenuItem.Text = "&About...";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click_1);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(948, 725);
            this.Controls.Add(this.groupBoxPlayingRecord);
            this.Controls.Add(this.groupBoxFileRecord);
            this.Controls.Add(this.labelMIDI);
            this.Controls.Add(this.groupBoxRecord);
            this.Controls.Add(this.textBoxMIDI);
            this.Controls.Add(this.pictureBoxRecorder);
            this.Controls.Add(this.labelNote);
            this.Controls.Add(this.labelPitch);
            this.Controls.Add(this.textBoxNote);
            this.Controls.Add(this.textBoxPitch);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MinimumSize = new System.Drawing.Size(930, 700);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Notey";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyUp);
            this.tabPagePdfMusicSheet.ResumeLayout(false);
            this.splitContainerMusicSheet.Panel1.ResumeLayout(false);
            this.splitContainerMusicSheet.Panel1.PerformLayout();
            this.splitContainerMusicSheet.Panel2.ResumeLayout(false);
            this.splitContainerMusicSheet.ResumeLayout(false);
            this.toolStripMusicSheet.ResumeLayout(false);
            this.toolStripMusicSheet.PerformLayout();
            this.tabControl.ResumeLayout(false);
            this.tabPageNotes.ResumeLayout(false);
            this.tabPageWaveform.ResumeLayout(false);
            this.splitContainerWaveform.Panel1.ResumeLayout(false);
            this.splitContainerWaveform.Panel1.PerformLayout();
            this.splitContainerWaveform.Panel2.ResumeLayout(false);
            this.splitContainerWaveform.Panel2.PerformLayout();
            this.splitContainerWaveform.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTimeDomain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFrequencyDomain)).EndInit();
            this.tabPageFingering.ResumeLayout(false);
            this.splitContainerFingering.Panel1.ResumeLayout(false);
            this.splitContainerFingering.Panel1.PerformLayout();
            this.splitContainerFingering.ResumeLayout(false);
            this.tabPageRecorderHero.ResumeLayout(false);
            this.splitContainerRecorderHero.Panel2.ResumeLayout(false);
            this.splitContainerRecorderHero.Panel2.PerformLayout();
            this.splitContainerRecorderHero.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.trackBarRecorderHero)).EndInit();
            this.groupBoxRecord.ResumeLayout(false);
            this.groupBoxPlayingRecord.ResumeLayout(false);
            this.groupBoxFileRecord.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRecorder)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonStartRecord;
        private System.Windows.Forms.Button buttonStopRecord;
        private System.Windows.Forms.TextBox textBoxPitch;
        private System.Windows.Forms.Label labelPitch;
        private System.Windows.Forms.TextBox textBoxNote;
        private System.Windows.Forms.Label labelNote;
        private System.Windows.Forms.PictureBox pictureBoxRecorder;
        private System.Windows.Forms.TabPage tabPagePdfMusicSheet;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPageWaveform;
        private System.Windows.Forms.SplitContainer splitContainerWaveform;
        private System.Windows.Forms.Label labelTimeDomain;
        private System.Windows.Forms.Label labelFrequencyDomain;
        private System.Windows.Forms.TabPage tabPageNotes;
        private System.Windows.Forms.Panel panelNotes;
        private System.Windows.Forms.PictureBox pictureBoxTimeDomain;
        private System.Windows.Forms.PictureBox pictureBoxFrequencyDomain;
        private System.Windows.Forms.TextBox textBoxMIDI;
        private System.Windows.Forms.Label labelMIDI;
        private System.Windows.Forms.Button buttonStartPlayingRecord;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button buttonPausePlayingRecord;
        private System.Windows.Forms.Button buttonStopPlayingRecord;
        private System.Windows.Forms.ComboBox comboBoxPlayingRecordFormats;
        private System.Windows.Forms.GroupBox groupBoxRecord;
        private System.Windows.Forms.GroupBox groupBoxPlayingRecord;
        private System.Windows.Forms.GroupBox groupBoxFileRecord;
        private System.Windows.Forms.Button buttonSaveRecord;
        private System.Windows.Forms.TabPage tabPageFingering;
        private System.Windows.Forms.ComboBox comboBoxInputDevices;
        private System.Windows.Forms.SplitContainer splitContainerFingering;
        private System.Windows.Forms.Label labelFingeringChartTitle;
        private System.Windows.Forms.Label labelFingeringChartSubTitle;
        private System.Windows.Forms.SplitContainer splitContainerMusicSheet;
        /*
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem undoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem selectAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem indexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButtonRefresh;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripLabel toolStripLabelTitle;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBoxTitle;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripLabel toolStripLabelComposer;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBoxComposer;*/
        private System.Windows.Forms.OpenFileDialog openFileDialogABC;
        private System.Windows.Forms.Button buttonNewRecord;
        private System.Windows.Forms.Button buttonOpenFile;
        private System.Windows.Forms.TabPage tabPageRecorderHero;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.SplitContainer splitContainerRecorderHero;
        private System.Windows.Forms.TrackBar trackBarRecorderHero;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ConfigurationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStripMusicSheet;
        private System.Windows.Forms.ToolStripButton toolStripButtonRefresh;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripLabel toolStripLabelTitle;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBoxTitle;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripLabel toolStripLabelComposer;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBoxComposer;
    }
}

