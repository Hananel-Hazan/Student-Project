﻿/*
* This file is Part of Notey
* LGPLv3 Licence:
*       Copyright (c) 2011 
*          Hila Shmuel [notey.recorder@gmail.com]
*          Hananel Hazan [hhazan01@CS.haifa.ac.il]
*          University of Haifa
* This Project is part of our B.Sc. Project course that under supervision
* of Hananel Hazan [hhazan01@CS.haifa.ac.il]
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without 
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice, this list of conditions 
*    and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice, this list of 
*    conditions and the following disclaimer in the documentation and/or other materials provided
*    with the distribution.
* 3. Neither the name of the <ORGANIZATION> nor the names of its contributors may be used to endorse
*    or promote products derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
* OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
* DAMAGE.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Notes
{
    /// <summary>
    /// represantation of a musical note
    /// </summary>
    public class Note
    {
        /// <summary>
        /// note scientific name (without ocatve): "A", "A#", "B",...
        /// </summary>
        public string NoteDescription;

        /// <summary>
        /// note's ocatves - from C-1 to G9 (-1,...9)
        /// </summary>
        public short Octave;

        /// <summary>
        /// note's pitch
        /// </summary>
        public float Frequency;

        /// <summary>
        /// note's MIDI number - from 0..127
        /// </summary>
        public byte MIDI;

        /// <summary>
        /// an internal index used for drawing the note on the correct line.
        /// with this numbering, a note "X" and "X#" would have the same value.
        /// example:
        ///     notes - "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"
        ///     index -  0,   0,    1,   1,    2,   3,   3,    4,   4,    5,   5,    6
        /// </summary>
        public byte LineIndex;

        /// <summary>
        /// does the note has sharp or flat
        /// </summary>
        public bool IsSharp;

        /// <summary>
        /// the note abc notation
        /// </summary>
        public string ABC;

        /// <summary>
        /// length of the note, in milliseconds
        /// </summary>
        public int Duration;

        /// <summary>
        /// length of the note: 1/2, 1/4, 1/8,...
        /// </summary>
        public float Length;


        /// <summary>
        /// Constructor of the note class
        /// </summary>
        /// <param name="noteDescription"></param>
        /// <param name="octave"></param>
        /// <param name="frequency"></param>
        /// <param name="midi"></param>
        /// <param name="lineIndex"></param>
        /// <param name="isSharp"></param>
        /// <param name="abc"></param>
        /// <param name="duration"></param>
        /// <param name="length"></param>
        public Note(string noteDescription,
            short octave,
            float frequency,
            byte midi,
            byte lineIndex,
            bool isSharp = false,
            string abc = "",
            int duration = 0,
            float length = 0.25F)
        {
            NoteDescription = noteDescription;
            Octave = octave;
            Frequency = frequency;
            MIDI = midi;
            LineIndex = lineIndex;
            IsSharp = isSharp;
            ABC = abc; // TODO: don't make ABC as deafult, create it in the NoteTable
            Duration = duration;
            Length = length;
        }    
    }

    /// <summary>
    /// a comparer for comparing between notes based on their frequencies
    /// </summary>
    public class NoteComparer : IComparer<Note>
    {
        /// <summary>
        /// a comparer for comparing between notes based on their frequencies
        /// </summary>
        /// <param name="x">first note to compare</param>
        /// <param name="y">second note to compare</param>
        /// <returns></returns>
        public int Compare(Note x, Note y)
        {
            return x.Frequency.CompareTo(y.Frequency);
        }
    }
    
    /// <summary>
    /// create a Table contains notes and their descriptions,
    /// and allow search note given frequency
    /// </summary>
    class NotesDB
    {
        /// <summary>
        /// Table of notes, With MIDI 0... 127
        /// </summary>
        List<Note> NotesTable;

        /// <summary>
        /// a note comparer
        /// </summary>
        NoteComparer NotesComparer;

        /// <summary>
        /// construct a new notes table
        /// </summary>
        public NotesDB()
        {
            NotesTable = CreateNotesTable();
            NotesComparer = new NoteComparer();
        }

        /// <summary>
        /// Get a note given its MIDI number
        /// </summary>
        /// <param name="MIDI">a MIDI number describing a note</param>
        /// <returns>a Note with that MIDI</returns>
        public Note GetNote(byte MIDI)
        {
            if (MIDI < 0 || MIDI > 127)
            {
                return null;
            }
            else
            {
                return NotesTable[MIDI];
            }
        }

        /// <summary>
        /// Get a note given its ABC representation 
        /// </summary>
        /// <param name="ABC">an ABC string</param>
        /// <returns>note</returns>
        public Note GetNoteByABC(string ABC)
        {
            foreach (Note note in NotesTable)
            {
                if (note.ABC == ABC)
                {
                    return note;
                }
            }
            return null;
        }

        /// <summary>
        /// create a list of notes, with MIDI index 0... 127
        /// </summary>
        /// <returns>list of notes and information</returns>
        private List<Note> CreateNotesTable()
        {
            List<Note> notesTable = new List<Note>();
            string[] notesDescription = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
            bool[] sharp = { false, true, false, true, false, false, true, false, true, false, true, false };

            // search for Helmholtz pitch notation
            int germanNotataionMarks = -8; // C,,, C,, C, C c c' c'' c''' c'''' c''''' c''''''
            string noteDescription = "";
            int octave = -1;
            double frequency = 0;
            byte midi = 0;
            byte lineIndex = 0;
            bool isSharp = false;
            string abc = "";
            int noteIndex = 0;

            for (midi = 0; midi < 128; midi++)
            {
                frequency = 440.0 * Math.Pow(2, (midi - 69.0) / 12.0);
                noteIndex = midi % notesDescription.Length;
                octave = midi / notesDescription.Length - 1;
                noteDescription = notesDescription[noteIndex];
                isSharp = sharp[noteIndex];
                
                //ABC
                if (isSharp)
                {
                    abc = "^" + noteDescription[0];
                }
                else
                {
                    abc = noteDescription;
                }

                if (noteIndex == 0)
                {
                    germanNotataionMarks++;
                }
                if (germanNotataionMarks < 0)
                {
                    abc = abc.ToUpper();
                    for (int i = 0; i < Math.Abs(germanNotataionMarks) - 1; i++)
                    {
                        abc += ",";
                    }
                }
                else
                {
                    abc = abc.ToLower();
                    for (int i = 0; i < Math.Abs(germanNotataionMarks); i++)
                    {
                        abc += "'";
                    }
                } 

                notesTable.Add(new Note(noteDescription,
                                        (short)octave,
                                        (float)frequency,
                                        (byte)midi,
                                        lineIndex,
                                        isSharp,
                                        abc));
                if (!isSharp)
                {
                    lineIndex++;
                }
            }

            return notesTable;
        }

        /// <summary>
        /// find note base on given frequency
        /// </summary>
        /// <param name="frequency">pitch, frequency in Hertz</param>
        /// <returns>the note that has the closest pitch to the given frequency</returns>
        public Note FindNote(float frequency)
        {
            Note note = new Note("", 0, frequency, 0, 0);
            int index = NotesTable.BinarySearch(note, NotesComparer);

            if (0 <= index)
            {
                return NotesTable[index];
            }

            index = ~index;

            if ((0 <= index) && (index < NotesTable.Count))
            {
                if (index == 0)
                {
                    return NotesTable[0];
                }
                else if (Math.Abs(NotesTable[index - 1].Frequency - frequency) >= Math.Abs(NotesTable[index].Frequency - frequency))
                {
                    return NotesTable[index];
                }
                else
                {
                    return NotesTable[index - 1];
                }
            }
            return new Note("", 0, 0, 0, 0);
        }
    }
}
