﻿/*
* This file is Part of a HOCR
* LGPLv3 Licence:
*       Copyright (c) 2011 
*          Niv Maman [nivmaman@yahoo.com]
*          Maxim Drabkin [mdrabkin@gmail.com]
*          Hananel Hazan [hhazan01@CS.haifa.ac.il]
*          University of Haifa
* This Project is part of our B.Sc. Project course that under supervision
* of Hananel Hazan [hhazan01@CS.haifa.ac.il]
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without 
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice, this list of conditions 
*    and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice, this list of 
*    conditions and the following disclaimer in the documentation and/or other materials provided
*    with the distribution.
* 3. Neither the name of the <ORGANIZATION> nor the names of its contributors may be used to endorse
*    or promote products derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
* OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
* DAMAGE.
*/

namespace HOCR
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TestLabel = new System.Windows.Forms.Label();
            this.SourcePicture = new System.Windows.Forms.PictureBox();
            this.ResultLetterPicture = new System.Windows.Forms.PictureBox();
            this.TextResult = new System.Windows.Forms.RichTextBox();
            this.ResultLetterText = new System.Windows.Forms.TextBox();
            this.RepairNetwork = new System.Windows.Forms.Button();
            this.FontsComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.MenuStrip = new System.Windows.Forms.MenuStrip();
            this.ToolStripRecognize = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectImage = new System.Windows.Forms.ToolStripMenuItem();
            this.GetText = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripFiltering = new System.Windows.Forms.ToolStripMenuItem();
            this.Rotate = new System.Windows.Forms.ToolStripMenuItem();
            this.Clean = new System.Windows.Forms.ToolStripMenuItem();
            this.Threshold = new System.Windows.Forms.ToolStripMenuItem();
            this.Centerize = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripTraining = new System.Windows.Forms.ToolStripMenuItem();
            this.CreateFont = new System.Windows.Forms.ToolStripMenuItem();
            this.CreateFontFrom = new System.Windows.Forms.ToolStripMenuItem();
            this.CreateFontEmpty = new System.Windows.Forms.ToolStripMenuItem();
            this.TrainNetwork = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripScript = new System.Windows.Forms.ToolStripMenuItem();
            this.CreateAllFontsScript = new System.Windows.Forms.ToolStripMenuItem();
            this.TrainAllFontsScript = new System.Windows.Forms.ToolStripMenuItem();
            this.StatusBar = new System.Windows.Forms.StatusStrip();
            this.Message = new System.Windows.Forms.ToolStripStatusLabel();
            this.StatusBarProgress = new System.Windows.Forms.ToolStripProgressBar();
            this.StopProcess = new System.Windows.Forms.ToolStripStatusLabel();
            this.PageNumber = new System.Windows.Forms.ToolStripStatusLabel();
            this.PagePrev = new System.Windows.Forms.Button();
            this.PageNext = new System.Windows.Forms.Button();
            this.NoteTrainYourNetwork = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.SourcePicture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResultLetterPicture)).BeginInit();
            this.MenuStrip.SuspendLayout();
            this.StatusBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // TestLabel
            // 
            this.TestLabel.AutoSize = true;
            this.TestLabel.Location = new System.Drawing.Point(0, 0);
            this.TestLabel.Name = "TestLabel";
            this.TestLabel.Size = new System.Drawing.Size(0, 14);
            this.TestLabel.TabIndex = 0;
            // 
            // SourcePicture
            // 
            this.SourcePicture.Location = new System.Drawing.Point(168, 27);
            this.SourcePicture.MaximumSize = new System.Drawing.Size(800, 600);
            this.SourcePicture.Name = "SourcePicture";
            this.SourcePicture.Size = new System.Drawing.Size(25, 25);
            this.SourcePicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.SourcePicture.TabIndex = 2;
            this.SourcePicture.TabStop = false;
            // 
            // ResultLetterPicture
            // 
            this.ResultLetterPicture.Location = new System.Drawing.Point(68, 125);
            this.ResultLetterPicture.Name = "ResultLetterPicture";
            this.ResultLetterPicture.Size = new System.Drawing.Size(50, 50);
            this.ResultLetterPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ResultLetterPicture.TabIndex = 3;
            this.ResultLetterPicture.TabStop = false;
            // 
            // TextResult
            // 
            this.TextResult.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.TextResult.Location = new System.Drawing.Point(168, 151);
            this.TextResult.Name = "TextResult";
            this.TextResult.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.TextResult.Size = new System.Drawing.Size(150, 27);
            this.TextResult.TabIndex = 15;
            this.TextResult.Text = "";
            this.TextResult.Visible = false;
            this.TextResult.SelectionChanged += new System.EventHandler(this.TextResultSelectionChanged);
            // 
            // ResultLetterText
            // 
            this.ResultLetterText.Font = new System.Drawing.Font("Arial", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.ResultLetterText.Location = new System.Drawing.Point(12, 125);
            this.ResultLetterText.Name = "ResultLetterText";
            this.ResultLetterText.Size = new System.Drawing.Size(50, 50);
            this.ResultLetterText.TabIndex = 18;
            // 
            // RepairNetwork
            // 
            this.RepairNetwork.Location = new System.Drawing.Point(10, 87);
            this.RepairNetwork.Name = "RepairNetwork";
            this.RepairNetwork.Size = new System.Drawing.Size(90, 32);
            this.RepairNetwork.TabIndex = 19;
            this.RepairNetwork.Text = "Repair Network";
            this.RepairNetwork.UseVisualStyleBackColor = true;
            this.RepairNetwork.Click += new System.EventHandler(this.RepairNetworkClick);
            // 
            // FontsComboBox
            // 
            this.FontsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FontsComboBox.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.FontsComboBox.FormattingEnabled = true;
            this.FontsComboBox.Items.AddRange(new object[] {
            "Auto"});
            this.FontsComboBox.Location = new System.Drawing.Point(10, 55);
            this.FontsComboBox.Name = "FontsComboBox";
            this.FontsComboBox.Size = new System.Drawing.Size(150, 26);
            this.FontsComboBox.Sorted = true;
            this.FontsComboBox.TabIndex = 20;
            this.FontsComboBox.SelectedIndexChanged += new System.EventHandler(this.FontsComboBoxSelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(5, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 25);
            this.label1.TabIndex = 21;
            this.label1.Text = "Font:";
            // 
            // MenuStrip
            // 
            this.MenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripRecognize,
            this.ToolStripFiltering,
            this.ToolStripTraining,
            this.ToolStripScript});
            this.MenuStrip.Location = new System.Drawing.Point(0, 0);
            this.MenuStrip.Name = "MenuStrip";
            this.MenuStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.MenuStrip.Size = new System.Drawing.Size(334, 24);
            this.MenuStrip.TabIndex = 44;
            this.MenuStrip.Text = "menuStrip1";
            // 
            // ToolStripRecognize
            // 
            this.ToolStripRecognize.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SelectImage,
            this.GetText});
            this.ToolStripRecognize.Name = "ToolStripRecognize";
            this.ToolStripRecognize.Size = new System.Drawing.Size(73, 20);
            this.ToolStripRecognize.Text = "Recognize";
            // 
            // SelectImage
            // 
            this.SelectImage.Name = "SelectImage";
            this.SelectImage.Size = new System.Drawing.Size(150, 22);
            this.SelectImage.Text = "Select Image...";
            this.SelectImage.Click += new System.EventHandler(this.SelectImageClick);
            // 
            // GetText
            // 
            this.GetText.Name = "GetText";
            this.GetText.Size = new System.Drawing.Size(150, 22);
            this.GetText.Text = "Get Text";
            this.GetText.Click += new System.EventHandler(this.GetTextClick);
            // 
            // ToolStripFiltering
            // 
            this.ToolStripFiltering.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Rotate,
            this.Clean,
            this.Threshold,
            this.Centerize});
            this.ToolStripFiltering.Name = "ToolStripFiltering";
            this.ToolStripFiltering.Size = new System.Drawing.Size(62, 20);
            this.ToolStripFiltering.Text = "Filtering";
            // 
            // Rotate
            // 
            this.Rotate.Name = "Rotate";
            this.Rotate.Size = new System.Drawing.Size(127, 22);
            this.Rotate.Text = "Rotate";
            this.Rotate.Click += new System.EventHandler(this.RotateClick);
            // 
            // Clean
            // 
            this.Clean.Name = "Clean";
            this.Clean.Size = new System.Drawing.Size(127, 22);
            this.Clean.Text = "Clean";
            this.Clean.Click += new System.EventHandler(this.CleanClick);
            // 
            // Threshold
            // 
            this.Threshold.Name = "Threshold";
            this.Threshold.Size = new System.Drawing.Size(127, 22);
            this.Threshold.Text = "Threshold";
            this.Threshold.Click += new System.EventHandler(this.ThresholdClick);
            // 
            // Centerize
            // 
            this.Centerize.Name = "Centerize";
            this.Centerize.Size = new System.Drawing.Size(127, 22);
            this.Centerize.Text = "Centerize";
            this.Centerize.Click += new System.EventHandler(this.CenterizeClick);
            // 
            // ToolStripTraining
            // 
            this.ToolStripTraining.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CreateFont,
            this.TrainNetwork});
            this.ToolStripTraining.Name = "ToolStripTraining";
            this.ToolStripTraining.Size = new System.Drawing.Size(63, 20);
            this.ToolStripTraining.Text = "Training";
            // 
            // CreateFont
            // 
            this.CreateFont.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CreateFontFrom,
            this.CreateFontEmpty});
            this.CreateFont.Name = "CreateFont";
            this.CreateFont.Size = new System.Drawing.Size(158, 22);
            this.CreateFont.Text = "Create Font";
            // 
            // CreateFontFrom
            // 
            this.CreateFontFrom.Name = "CreateFontFrom";
            this.CreateFontFrom.Size = new System.Drawing.Size(117, 22);
            this.CreateFontFrom.Text = "From...";
            this.CreateFontFrom.Click += new System.EventHandler(this.CreateFontClick);
            // 
            // CreateFontEmpty
            // 
            this.CreateFontEmpty.Name = "CreateFontEmpty";
            this.CreateFontEmpty.Size = new System.Drawing.Size(117, 22);
            this.CreateFontEmpty.Text = "Empty...";
            this.CreateFontEmpty.Click += new System.EventHandler(this.EmptyFontClick);
            // 
            // TrainNetwork
            // 
            this.TrainNetwork.Name = "TrainNetwork";
            this.TrainNetwork.Size = new System.Drawing.Size(158, 22);
            this.TrainNetwork.Text = "Train Network...";
            this.TrainNetwork.Click += new System.EventHandler(this.TrainNetworkClick);
            // 
            // ToolStripScript
            // 
            this.ToolStripScript.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CreateAllFontsScript,
            this.TrainAllFontsScript});
            this.ToolStripScript.Name = "ToolStripScript";
            this.ToolStripScript.Size = new System.Drawing.Size(49, 20);
            this.ToolStripScript.Text = "Script";
            // 
            // CreateAllFontsScript
            // 
            this.CreateAllFontsScript.Name = "CreateAllFontsScript";
            this.CreateAllFontsScript.Size = new System.Drawing.Size(157, 22);
            this.CreateAllFontsScript.Text = "Create All Fonts";
            this.CreateAllFontsScript.Click += new System.EventHandler(this.CreateAllFontsScriptClick);
            // 
            // TrainAllFontsScript
            // 
            this.TrainAllFontsScript.Name = "TrainAllFontsScript";
            this.TrainAllFontsScript.Size = new System.Drawing.Size(157, 22);
            this.TrainAllFontsScript.Text = "Train All Fonts";
            this.TrainAllFontsScript.Click += new System.EventHandler(this.TrainAllScriptClick);
            // 
            // StatusBar
            // 
            this.StatusBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Message,
            this.StatusBarProgress,
            this.StopProcess,
            this.PageNumber});
            this.StatusBar.Location = new System.Drawing.Point(0, 240);
            this.StatusBar.Name = "StatusBar";
            this.StatusBar.Size = new System.Drawing.Size(334, 22);
            this.StatusBar.TabIndex = 45;
            // 
            // Message
            // 
            this.Message.Name = "Message";
            this.Message.Size = new System.Drawing.Size(39, 17);
            this.Message.Text = "Ready";
            // 
            // StatusBarProgress
            // 
            this.StatusBarProgress.MarqueeAnimationSpeed = 20;
            this.StatusBarProgress.Name = "StatusBarProgress";
            this.StatusBarProgress.Size = new System.Drawing.Size(100, 16);
            this.StatusBarProgress.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.StatusBarProgress.Visible = false;
            // 
            // StopProcess
            // 
            this.StopProcess.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.StopProcess.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StopProcess.Name = "StopProcess";
            this.StopProcess.Size = new System.Drawing.Size(86, 17);
            this.StopProcess.Text = "Stop Process";
            this.StopProcess.Visible = false;
            this.StopProcess.Click += new System.EventHandler(this.StopProcessClick);
            // 
            // PageNumber
            // 
            this.PageNumber.Name = "PageNumber";
            this.PageNumber.Size = new System.Drawing.Size(0, 17);
            // 
            // PagePrev
            // 
            this.PagePrev.Location = new System.Drawing.Point(106, 91);
            this.PagePrev.Name = "PagePrev";
            this.PagePrev.Size = new System.Drawing.Size(25, 25);
            this.PagePrev.TabIndex = 46;
            this.PagePrev.Text = "<";
            this.PagePrev.UseVisualStyleBackColor = true;
            this.PagePrev.Visible = false;
            this.PagePrev.Click += new System.EventHandler(this.PagePrevClick);
            // 
            // PageNext
            // 
            this.PageNext.Location = new System.Drawing.Point(135, 91);
            this.PageNext.Name = "PageNext";
            this.PageNext.Size = new System.Drawing.Size(25, 25);
            this.PageNext.TabIndex = 47;
            this.PageNext.Text = ">";
            this.PageNext.UseVisualStyleBackColor = true;
            this.PageNext.Visible = false;
            this.PageNext.Click += new System.EventHandler(this.PageNextClick);
            // 
            // NoteTrainYourNetwork
            // 
            this.NoteTrainYourNetwork.AutoSize = true;
            this.NoteTrainYourNetwork.Location = new System.Drawing.Point(12, 182);
            this.NoteTrainYourNetwork.Name = "NoteTrainYourNetwork";
            this.NoteTrainYourNetwork.Size = new System.Drawing.Size(150, 42);
            this.NoteTrainYourNetwork.TabIndex = 48;
            this.NoteTrainYourNetwork.Text = "Note:\r\nYou have to train the network\r\nwhen you finish repairing it";
            this.NoteTrainYourNetwork.Visible = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 262);
            this.Controls.Add(this.NoteTrainYourNetwork);
            this.Controls.Add(this.PageNext);
            this.Controls.Add(this.PagePrev);
            this.Controls.Add(this.StatusBar);
            this.Controls.Add(this.MenuStrip);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.FontsComboBox);
            this.Controls.Add(this.RepairNetwork);
            this.Controls.Add(this.ResultLetterText);
            this.Controls.Add(this.TextResult);
            this.Controls.Add(this.ResultLetterPicture);
            this.Controls.Add(this.SourcePicture);
            this.Controls.Add(this.TestLabel);
            this.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.MainMenuStrip = this.MenuStrip;
            this.MinimumSize = new System.Drawing.Size(350, 250);
            this.Name = "MainForm";
            this.Text = "HOCR";
            ((System.ComponentModel.ISupportInitialize)(this.SourcePicture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResultLetterPicture)).EndInit();
            this.MenuStrip.ResumeLayout(false);
            this.MenuStrip.PerformLayout();
            this.StatusBar.ResumeLayout(false);
            this.StatusBar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label TestLabel;
        private System.Windows.Forms.PictureBox SourcePicture;
        private System.Windows.Forms.PictureBox ResultLetterPicture;
        private System.Windows.Forms.RichTextBox TextResult;
        private System.Windows.Forms.TextBox ResultLetterText;
        private System.Windows.Forms.Button RepairNetwork;
        private System.Windows.Forms.ComboBox FontsComboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip MenuStrip;
        private System.Windows.Forms.ToolStripMenuItem ToolStripRecognize;
        private System.Windows.Forms.ToolStripMenuItem ToolStripFiltering;
        private System.Windows.Forms.ToolStripMenuItem SelectImage;
        private System.Windows.Forms.ToolStripMenuItem GetText;
        private System.Windows.Forms.ToolStripMenuItem ToolStripTraining;
        private System.Windows.Forms.ToolStripMenuItem ToolStripScript;
        private System.Windows.Forms.ToolStripMenuItem Rotate;
        private System.Windows.Forms.ToolStripMenuItem Clean;
        private System.Windows.Forms.ToolStripMenuItem Threshold;
        private System.Windows.Forms.ToolStripMenuItem CreateFont;
        private System.Windows.Forms.ToolStripMenuItem CreateFontFrom;
        private System.Windows.Forms.ToolStripMenuItem CreateFontEmpty;
        private System.Windows.Forms.ToolStripMenuItem TrainNetwork;
        private System.Windows.Forms.ToolStripMenuItem CreateAllFontsScript;
        private System.Windows.Forms.ToolStripMenuItem TrainAllFontsScript;
        private System.Windows.Forms.StatusStrip StatusBar;
        private System.Windows.Forms.ToolStripStatusLabel Message;
        private System.Windows.Forms.ToolStripProgressBar StatusBarProgress;
        private System.Windows.Forms.ToolStripStatusLabel StopProcess;
        private System.Windows.Forms.Button PagePrev;
        private System.Windows.Forms.Button PageNext;
        private System.Windows.Forms.ToolStripStatusLabel PageNumber;
        private System.Windows.Forms.ToolStripMenuItem Centerize;
        private System.Windows.Forms.Label NoteTrainYourNetwork;
    }
}

