﻿/*
* This file is Part of a HOCR
* LGPLv3 Licence:
*       Copyright (c) 2011 
*          Niv Maman [nivmaman@yahoo.com]
*          Maxim Drabkin [mdrabkin@gmail.com]
*          Hananel Hazan [hhazan01@CS.haifa.ac.il]
*          University of Haifa
* This Project is part of our B.Sc. Project course that under supervision
* of Hananel Hazan [hhazan01@CS.haifa.ac.il]
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without 
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice, this list of conditions 
*    and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice, this list of 
*    conditions and the following disclaimer in the documentation and/or other materials provided
*    with the distribution.
* 3. Neither the name of the <ORGANIZATION> nor the names of its contributors may be used to endorse
*    or promote products derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
* OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
* DAMAGE.
*/

namespace HOCR
{
    partial class TrainingUc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ProgressBar = new System.Windows.Forms.ProgressBar();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Iterations = new System.Windows.Forms.Label();
            this.ErrorToStop = new System.Windows.Forms.Label();
            this.Start = new System.Windows.Forms.Button();
            this.Stop = new System.Windows.Forms.Button();
            this.Momentum = new System.Windows.Forms.TextBox();
            this.LearnRate = new System.Windows.Forms.TextBox();
            this.Error = new System.Windows.Forms.TextBox();
            this.Repeats = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.FontName = new System.Windows.Forms.Label();
            this.StopScript = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ProgressBar
            // 
            this.ProgressBar.Location = new System.Drawing.Point(13, 91);
            this.ProgressBar.Name = "ProgressBar";
            this.ProgressBar.Size = new System.Drawing.Size(334, 24);
            this.ProgressBar.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label1.Location = new System.Drawing.Point(13, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 22);
            this.label1.TabIndex = 1;
            this.label1.Text = "Iterations:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.Location = new System.Drawing.Point(185, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "Error:";
            // 
            // Iterations
            // 
            this.Iterations.AutoSize = true;
            this.Iterations.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Iterations.Location = new System.Drawing.Point(112, 66);
            this.Iterations.Name = "Iterations";
            this.Iterations.Size = new System.Drawing.Size(21, 22);
            this.Iterations.TabIndex = 3;
            this.Iterations.Text = "0";
            // 
            // ErrorToStop
            // 
            this.ErrorToStop.AutoSize = true;
            this.ErrorToStop.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.ErrorToStop.Location = new System.Drawing.Point(248, 66);
            this.ErrorToStop.Name = "ErrorToStop";
            this.ErrorToStop.Size = new System.Drawing.Size(21, 22);
            this.ErrorToStop.TabIndex = 4;
            this.ErrorToStop.Text = "0";
            // 
            // Start
            // 
            this.Start.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Start.Location = new System.Drawing.Point(17, 131);
            this.Start.Name = "Start";
            this.Start.Size = new System.Drawing.Size(72, 40);
            this.Start.TabIndex = 6;
            this.Start.Text = "Start";
            this.Start.UseVisualStyleBackColor = true;
            this.Start.Click += new System.EventHandler(this.StartClick);
            // 
            // Stop
            // 
            this.Stop.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Stop.Location = new System.Drawing.Point(17, 177);
            this.Stop.Name = "Stop";
            this.Stop.Size = new System.Drawing.Size(72, 40);
            this.Stop.TabIndex = 7;
            this.Stop.Text = "Stop";
            this.Stop.UseVisualStyleBackColor = true;
            this.Stop.Click += new System.EventHandler(this.StopClick);
            // 
            // Momentum
            // 
            this.Momentum.Location = new System.Drawing.Point(209, 204);
            this.Momentum.Name = "Momentum";
            this.Momentum.Size = new System.Drawing.Size(60, 20);
            this.Momentum.TabIndex = 37;
            this.Momentum.Text = "0.01";
            // 
            // LearnRate
            // 
            this.LearnRate.Location = new System.Drawing.Point(209, 178);
            this.LearnRate.Name = "LearnRate";
            this.LearnRate.Size = new System.Drawing.Size(60, 20);
            this.LearnRate.TabIndex = 36;
            this.LearnRate.Text = "0.005";
            // 
            // Error
            // 
            this.Error.Location = new System.Drawing.Point(209, 152);
            this.Error.Name = "Error";
            this.Error.Size = new System.Drawing.Size(60, 20);
            this.Error.TabIndex = 35;
            this.Error.Text = "0.01";
            // 
            // Repeats
            // 
            this.Repeats.Location = new System.Drawing.Point(209, 126);
            this.Repeats.Name = "Repeats";
            this.Repeats.Size = new System.Drawing.Size(60, 20);
            this.Repeats.TabIndex = 34;
            this.Repeats.Text = "5000";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label9.Location = new System.Drawing.Point(113, 151);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 18);
            this.label9.TabIndex = 33;
            this.label9.Text = "Error:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label5.Location = new System.Drawing.Point(113, 177);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 18);
            this.label5.TabIndex = 32;
            this.label5.Text = "Learn Rate:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label6.Location = new System.Drawing.Point(113, 203);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 18);
            this.label6.TabIndex = 31;
            this.label6.Text = "Momentum:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label10.Location = new System.Drawing.Point(113, 125);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 18);
            this.label10.TabIndex = 30;
            this.label10.Text = "Repeats:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label11.Location = new System.Drawing.Point(13, 11);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(59, 22);
            this.label11.TabIndex = 38;
            this.label11.Text = "Font:";
            // 
            // FontName
            // 
            this.FontName.AutoSize = true;
            this.FontName.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.FontName.Location = new System.Drawing.Point(78, 11);
            this.FontName.Name = "FontName";
            this.FontName.Size = new System.Drawing.Size(0, 22);
            this.FontName.TabIndex = 39;
            // 
            // StopScript
            // 
            this.StopScript.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.StopScript.Location = new System.Drawing.Point(275, 3);
            this.StopScript.Name = "StopScript";
            this.StopScript.Size = new System.Drawing.Size(72, 54);
            this.StopScript.TabIndex = 40;
            this.StopScript.Text = "Stop Script";
            this.StopScript.UseVisualStyleBackColor = true;
            this.StopScript.Visible = false;
            this.StopScript.Click += new System.EventHandler(this.StopScriptClick);
            // 
            // TrainingUc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.StopScript);
            this.Controls.Add(this.FontName);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.Momentum);
            this.Controls.Add(this.LearnRate);
            this.Controls.Add(this.Error);
            this.Controls.Add(this.Repeats);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.Stop);
            this.Controls.Add(this.Start);
            this.Controls.Add(this.ErrorToStop);
            this.Controls.Add(this.Iterations);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ProgressBar);
            this.Name = "TrainingUc";
            this.Size = new System.Drawing.Size(350, 250);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ProgressBar ProgressBar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Iterations;
        private System.Windows.Forms.Label ErrorToStop;
        private System.Windows.Forms.Button Start;
        private System.Windows.Forms.Button Stop;
        private System.Windows.Forms.TextBox Momentum;
        private System.Windows.Forms.TextBox LearnRate;
        private System.Windows.Forms.TextBox Error;
        private System.Windows.Forms.TextBox Repeats;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label FontName;
        private System.Windows.Forms.Button StopScript;
    }
}
