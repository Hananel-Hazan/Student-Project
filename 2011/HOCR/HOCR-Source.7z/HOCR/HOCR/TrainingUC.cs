﻿using System;
using System.Threading;
using System.Windows.Forms;

namespace HOCR
{
    /// <summary>
    /// Dialog form that use for training
    /// </summary>
    public partial class TrainingUc : UserControl
    {
        #region Global

        private int _repeats; //number of repeats
        private double _error, _learnRate, _momentum;// training parameters
        private NeuralNetwork _fontNetwork; //pixels neural network of current font

        private readonly Action<int, double, double, double> _trainActionP; //action used for train task P
        private Form _parentForm; //parent form, used for closing
        public event Action StopScriptClicked; //event of stoping script

        private bool _activeTrain; //indicates if train is active
        private bool _scriptMode; //indicates if we use script

        #endregion

        /// <summary>
        /// Training user control dialog C'tor
        /// </summary>
        public TrainingUc()
        {
            InitializeComponent();
            Start.Enabled = true;
            Stop.Enabled = false;
            _trainActionP = TrainTaskP;
        }

        /// <summary>
        /// Init font network of training dialog
        /// </summary>
        /// <param name="fontNetwork">neural network font</param>
        /// <param name="script">indicates if we use script</param>
        /// <param name="parantForm">parent form, used for closing</param>
        /// <param name="fontName">name of font we train</param>
        public void Init(NeuralNetwork fontNetwork, bool script, Form parantForm, string fontName)
        {
            _scriptMode = script;
            StopScript.Visible = script;
            _parentForm = parantForm;
            _parentForm.Closing += delegate { StopClick(null, null); Thread.Sleep(10); };
            _fontNetwork = fontNetwork;
            FontName.Text = fontName;
            _fontNetwork.IterationChanged += UpdateHandler;
            Thread.Sleep(10);
            if (script) StartClick(null, null);
        }

        /// <summary>
        /// Event of clicking on Start button that
        /// read and init variables of training and invoke it.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StartClick(object sender, EventArgs e)
        {
            //set network variables and check them
            try
            {
                _repeats = int.Parse(Repeats.Text);
                _error = double.Parse(Error.Text);
                _learnRate = double.Parse(LearnRate.Text);
                _momentum = double.Parse(Momentum.Text);
            }
            catch (Exception)
            {
                if (!_scriptMode) MessageBox.Show(@"Error reading training variables");
                return;
            }

            //init state of training and invoke
            Start.Enabled = false;
            Stop.Enabled = true;
            ProgressBar.Maximum = _repeats;
            _activeTrain = true;
            _trainActionP.BeginInvoke(_repeats, _error, _learnRate, _momentum, null, null);
        }

        /// <summary>
        /// Event of clicking on Stop button that
        /// stop the training process
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StopClick(object sender, EventArgs e)
        {
            _activeTrain = false;
            Start.Enabled = true;
            Stop.Enabled = false;
            _fontNetwork.StopTrain();
        }

        /// <summary>
        /// Get training parameters and start pixels training
        /// </summary>
        /// <param name="repeats"></param>
        /// <param name="error"></param>
        /// <param name="learnRate"></param>
        /// <param name="momentum"></param>
        private void TrainTaskP(int repeats, double error, double learnRate, double momentum)
        {
            try
            {
                _fontNetwork.Train(repeats, error, learnRate, momentum);
            }
            catch (Exception exception)
            {
                if (!_scriptMode) MessageBox.Show(exception.Message);
            }
        }

        /// <summary>
        /// Event handler of updating pixels training state
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UpdateHandler(object sender, TrainArgs e)
        {
            Thread.Sleep(10);
            Invoke((Action<int,double>)Update,new object[]{e.Iterations, e.Error});
        }

        /// <summary>
        /// Update pixels training user interface
        /// </summary>
        /// <param name="iterations">number of iterations</param>
        /// <param name="error">current error</param>
        private void Update(int iterations,double error)
        {
            Iterations.Text = iterations.ToString();
            ErrorToStop.Text = error.ToString("0.0000");
            ProgressBar.Value = iterations;
            if (iterations != _repeats && error >= _error) return;
            _activeTrain = false;
            CheckFinish();
        }

        /// <summary>
        /// Check if both trainig finished and update user interface if needed.
        /// </summary>
        private void CheckFinish()
        {
            if (_activeTrain) return;
            Start.Enabled = true;
            Stop.Enabled = false;
            if (_scriptMode) _parentForm.Close();
        }

        /// <summary>
        /// Unregister all events.
        /// you should call this method from outside class after closing dialog
        /// </summary>
        public void UnRegister()
        {
            _fontNetwork.IterationChanged -= UpdateHandler;
        }

        /// <summary>
        /// Event of clicking on Stop Script button that stops script
        /// by invoking event and close window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StopScriptClick(object sender, EventArgs e)
        {
            StopScriptClicked.Invoke();
            _parentForm.Close();
        }
    }
}