﻿using System;
using System.Windows.Forms;

namespace HOCR
{
    public partial class InputBox : Form
    {
        public String Result;

        public InputBox(string text)
        {
            InitializeComponent();
            Init(text);
        }

        private void Init(string text)
        {
            Message.Text = text;
        }

        private void CancelClick(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void OkClick(object sender, EventArgs e)
        {
            Result = Input.Text;
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
