﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace HOCR
{
    /// <summary>
    /// Main form of HOCR application
    /// </summary>
    public partial class MainForm : Form
    {
        #region Consts

        private const int MaxWidth = 500;
        private const int MaxHeight = 800;

        #endregion

        #region Global

        //GUI
        private Form _trainForm; //training dialog
        private int _currentPage; //saves the current page of image
        private int? _markedLine; //number of marked line
        private int? _markedLetter; //number of marked letter
        private int? _markedIndex; //index of marked letter

        //Image
        private Bitmap _bitmap; //bitmap of current image
        private Bitmap _picture; //bitmap of current shown image
        private Bitmap[][] _letters; //letters of current image
        private int[][][] _letterBounds; //letters bounds of current image
        private string _currentImagePath; //path of current image

        //Neural Network
        private NeuralNetwork _fontNetwork; //pixels neural network of current font
        private string _currentFontPath; //path of current font pixels
        private int _inputLayer; //size of input layer pixels
        private readonly int[] _middleLayers = new[] { 50, 50 }; //size of middle layer
        private readonly int _outputLayer = FontActions.LettersInNetwork.Length; //size of output layer

        //Script
        private bool _scriptMode; //indicates if we use script mode
        private readonly string[] _fontNames = new[]
        {
            "Arial", "David", "Times New Roman", "Miriam", "Narkisim",
            "Lucida Sans", "Tahoma", "Microsoft Sans Serif", "Verdana","Courier New"
        }; //names of 10 most common fonts that script use to initial fonts database

        #endregion

        /// <summary>
        /// InitializeComponent
        /// </summary>
        public MainForm()
        {
            InitializeComponent();
            InitializeFolders();
            UpdateFontsComboBox();
        }

        #region Functions

        /// <summary>
        /// Check existence of fonts and results folders and create them if needed
        /// </summary>
        private static void InitializeFolders()
        {
            var fontsFolder = new DirectoryInfo(FontActions.FontsFolderPath);
            var resultsFolder = new DirectoryInfo(FileActions.ResultsFolderPath);
            if (!fontsFolder.Exists) Directory.CreateDirectory(FontActions.FontsFolderPath);
            if (!resultsFolder.Exists) Directory.CreateDirectory(FileActions.ResultsFolderPath);
        }

        /// <summary>
        /// Enter fonts items into fonts combobox
        /// </summary>
        private void UpdateFontsComboBox()
        {
            var directoryInfo = new DirectoryInfo(FontActions.FontsFolderPath);
            var files = directoryInfo.GetFiles();
            FontsComboBox.Items.Clear();
            FontsComboBox.Items.Add("*Auto");
            foreach (var file in files.Where(file => file.Extension == ".net"))
                FontsComboBox.Items.Add(file.Name.Remove(file.Name.Length - 4));
            FontsComboBox.SelectedIndex = 0;
        }

        /// <summary>
        /// Open selection image dialog, set image
        /// and return boolean value indicates if it succeed
        /// </summary>
        /// <returns>boolean value indicates if it succeed</returns>
        private bool SelectImageDialog()
        {
            //save last bitmap in case of error
            var tempBitmap = _bitmap;

            //select file from dialog
            var fileDialog = new OpenFileDialog();
            fileDialog.ShowDialog();
            _currentImagePath = fileDialog.FileName;
            if (_currentImagePath == "") return false;
            PageNumber.Text = "";
            _bitmap = LoadImage(_currentImagePath);
            //if (_bitmap != null) _bitmap = new Bitmap(_bitmap);
            SourcePicture.Image = _bitmap;

            //check file
            if (_bitmap != null) return true;
            _bitmap = tempBitmap;
            MessageBox.Show(string.Format("Select image file"));
            return false;
        }

        /// <summary>
        /// Get letter bitmap, calculate which letter is it,
        /// and return it's index.
        /// </summary>
        /// <param name="letter">letter bitmap</param>
        /// <returns>index of letter</returns>
        private int CalculateLetter(Bitmap letter)
        {
            var sample = FontActions.LetterParameters(letter, FontActions.Pixels);
            var output = _fontNetwork.Compute(sample[0]);
            var max = 0.0;
            var letterId = 0;
            for (var i = 0; i < FontActions.LettersInNetwork.Length; i++)
            {
                var temp = output[i];
                if (temp <= max) continue;
                max = temp;
                letterId = i;
            }
            return letterId;
        }

        /// <summary>
        /// Create font action that take the current image
        /// and make font network from it.
        /// return message in case of error, otherwise returns null.
        /// </summary>
        /// <returns>message in case of error</returns>
        private string CreateFontTask(string name = null)
        {
            double[][][] data;
            if (name != null)
            {
                //create font network for empty font
                _currentImagePath = FontActions.FontsFolderPath + "\\" + name + ".png";
                var letters = new[] { new[] { TextImageActions.WhiteBitmap(FontActions.LetterSize, FontActions.LetterSize) } };
                data = FontActions.CreateFontData(letters, FontActions.Pixels);
                data[1][0][0] = 0;
                _inputLayer = data[0][0].Length;
            }
            else
            {
                //create font network for known font
                data = FontActions.CreateFontData(_letters, FontActions.Pixels);
                _inputLayer = data[0][0].Length;
            }
            _fontNetwork = new NeuralNetwork(_inputLayer, _middleLayers, _outputLayer, data[0], data[1]);

            //calculate network path
            var currentFontPath = _currentImagePath.Remove(_currentImagePath.Length - 3);
            _currentFontPath = currentFontPath.Insert(currentFontPath.Length, "net");

            //save network into file
            return FileActions.SaveNetwork(_currentFontPath, _fontNetwork);
        }

        /// <summary>
        /// Load the image to picturebox and return bitmap.
        /// returns null in case of failure loading image.
        /// </summary>
        /// <param name="path">path of image</param>
        /// <returns>image bitmap</returns>
        private Bitmap LoadImage(string path)
        {
            Bitmap image;
            try
            {
                if (path.EndsWith("pdf"))
                    path = FileActions.ConvertPdfToTiff(path);
                image = new Bitmap(path);
            }
            catch (Exception)
            {
                return null;
            }
            var numberOfPages = image.GetFrameCount(FrameDimension.Page);
            ShowSource(image);
            AdjustWindow();
            ShowPagesButtons(numberOfPages > 1, numberOfPages);
            TextResult.Visible = false;
            return image;
        }

        /// <summary>
        /// Get boolean indicates whether to show next\prev buttons.
        /// if true, set their location.
        /// </summary>
        /// <param name="visibility">visibility value</param>
        /// <param name="numberOfPages">number of pages in current image</param>
        private void ShowPagesButtons(bool visibility, int numberOfPages)
        {
            PageNext.Visible = visibility;
            PagePrev.Visible = visibility;
            if (!visibility) return;

            PageNumber.Text = @"Page " + (_currentPage + 1) + @" / " + numberOfPages;
            var prevX = SourcePicture.Location.X;
            var nextX = SourcePicture.Location.X + SourcePicture.Size.Width - PageNext.Size.Width;
            var buttonsY = SourcePicture.Location.Y + SourcePicture.Size.Height - PagePrev.Size.Height;
            PagePrev.Location = new Point(prevX, buttonsY);
            PageNext.Location = new Point(nextX, buttonsY);
        }

        /// <summary>
        /// Mark the current letter on source picturebox, using the letters bounds
        /// </summary>
        private void MarkCurrentLetter(int line, int letter, Color color)
        {
            _picture = _bitmap.Clone() as Bitmap;
            if (_picture == null) return;

            var realLetter = _letterBounds[line - 1].Length - letter;
            var bounds = _letterBounds[line - 1][realLetter];
            for (var i = bounds[0] - 1; i < bounds[1] + 1; i++)
            {
                var tempI = i;
                if (i < 0) tempI = 0;
                if (i >= _picture.Height) tempI = _picture.Height-1;
                try
                {
                    if (bounds[2] - 1 <= 0)
                        _picture.SetPixel(0, tempI, color);
                    else
                        _picture.SetPixel(bounds[2] - 1, tempI, color);

                    if (bounds[3] + 1 >= _picture.Width)
                        _picture.SetPixel(_picture.Width - 1, tempI, color);
                    else
                        _picture.SetPixel(bounds[3] + 1, tempI, color);
                }
                catch (Exception)
                {
                    continue;
                }
            }
            for (var i = bounds[2] - 1; i < bounds[3] + 1; i++)
            {
                var tempI = i;
                if (i < 0) tempI = 0;
                if (i >= _picture.Width) tempI = _picture.Width-1;
                try
                {
                    if (bounds[0] - 1 <= 0)
                        _picture.SetPixel(tempI, 0, color);
                    else
                        _picture.SetPixel(tempI, bounds[0] - 1, color);

                    if (bounds[1] + 1 > _picture.Height)
                        _picture.SetPixel(tempI, _picture.Height - 1, color);
                    else
                        _picture.SetPixel(tempI, bounds[1] + 1, color);
                }
                catch (Exception)
                {
                    continue;
                }
            }
            SourcePicture.Image = _picture;
        }

        /// <summary>
        /// Show Text Result
        /// </summary>
        private void ShowText(int numberOfLines, int maxLine)
        {
            //show and adjust text result
            var width = (20*maxLine);
            var height = (int) (2*numberOfLines*TextResult.Font.Size);
            if (height > MaxHeight) height = MaxHeight;
            if (width > MaxWidth) width = MaxWidth;
            TextResult.Size = new Size(width, height);
            TextResult.Location = new Point(SourcePicture.Location.X + SourcePicture.Size.Width + 5, SourcePicture.Location.Y);
            TextResult.Visible = true;
            AdjustWindow();
        }

        /// <summary>
        /// Adjust window to size of content
        /// </summary>
        private void AdjustWindow()
        {
            Width = SourcePicture.Width + 200;
            if (TextResult.Visible) Width += TextResult.Size.Width;
            Height = SourcePicture.Height + 100;
        }

        /// <summary>
        /// Get line and letter numbers and show that letter on screen
        /// at the repair section
        /// </summary>
        /// <param name="lineNumber"></param>
        /// <param name="letterNumber"></param>
        private void ShowResultLetterText(int lineNumber, int letterNumber)
        {
            //show choosen letter on repai section
            var letter = _letters[lineNumber - 1][letterNumber - 1];
            int letterId;
            try
            {
                if (FontActions.IsSpace(letter))
                {
                    ResultLetterText.Text = @" ";
                    ResultLetterPicture.Image = letter;
                    return;
                }
                letterId = CalculateLetter(letter);
            }
            catch (Exception)
            {
                return;
            }
            ResultLetterText.Text = FontActions.LettersInNetwork[letterId].ToString();
            ResultLetterPicture.Image = letter;
        }

        /// <summary>
        /// Get image bitmap and show it at the source picture box
        /// </summary>
        /// <param name="bitmap">path of image</param>
        private void ShowSource(Bitmap bitmap)
        {
            var newBitmap = (Bitmap) bitmap.Clone();
            newBitmap = TextImageActions.ResizeImageUntillMax(newBitmap, MaxWidth, MaxHeight);
            //newBitmap = TextImageActions.Centerize(newBitmap);
            SourcePicture.Image = newBitmap;
            SourcePicture.Width = newBitmap.Width;
            SourcePicture.Height = newBitmap.Height;
            AdjustWindow();
        }

        /// <summary>
        /// Restoring window to be enabled again after finishing loading text result
        /// </summary>
        private void RestoreWindowState()
        {
            StatusBar.BeginInvoke(new Action(() => InAction(false)));
        }

        /// <summary>
        /// Get boolean that indicates if application in action,
        /// and enabled or disable the buttons depending on state.
        /// </summary>
        /// <param name="inAction">application action state</param>
        private void InAction(bool inAction)
        {
            if (TextResult.Text != "" && TextResult.Visible && _letters != null)
                TextResult.BeginInvoke(new Action<int,int>(ShowText), _letters.Length, FileActions.LongestArray(_letters));
            AdjustWindow();
            StatusBarProgress.Visible = inAction;
            ToolStripRecognize.Enabled = !inAction;
            ToolStripTraining.Enabled = !inAction;
            ToolStripFiltering.Enabled = !inAction;
            ToolStripScript.Enabled = !inAction;
            RepairNetwork.Enabled = !inAction;
            FontsComboBox.Enabled = !inAction;
            ResultLetterText.Enabled = !inAction;
            PagePrev.Enabled = !inAction;
            PageNext.Enabled = !inAction;
            if (!inAction) Message.Text = @"Ready";
        }

        /// <summary>
        /// Task that been called when click on Get Text button
        /// </summary>
        private void GetTextTask()
        {
            //calculate and separate for letters
            if (_letters == null)
            {
                try
                {
                    _letterBounds = TextImageActions.GetAllLettersBounds(_bitmap);
                    _letters = TextImageActions.RetrieveText(_bitmap, _letterBounds, FontActions.LetterSize);
                }
                catch (Exception ex)
                {
                    RestoreWindowState();
                    MessageBox.Show(
                        string.Format("Retrieving text failed" + Environment.NewLine + Environment.NewLine +
                                      "Seems like the text you have just tried to recognized is too small" + ex.Message));
                    return;
                }
                
                if (_letters == null)
                {
                    RestoreWindowState();
                    MessageBox.Show(string.Format("Retrieving text failed"));
                    return;
                }
            }

            //calculate text
            var text = "";
            var size = FontActions.NumberOfElements(_letters);
            var letters = FontActions.DeployArray(_letters, size);
            foreach (var letter in letters)
            {
                //check case of space
                if (FontActions.IsSpace(letter))
                {
                    text += @" ";
                    continue;
                }
                var result = CalculateLetter(letter);
                text += FontActions.LettersInNetwork[result];
            }

            //add spaces between lines
            var currentLetter = 0;
            foreach (var line in _letters)
            {
                currentLetter += line.Length;
                text = text.Insert(currentLetter, "\n");
                currentLetter++;
            }
            text = text.Remove(text.Length - 1);
            TextResult.BeginInvoke(new Action(() => TextResult.Text = text));
            RestoreWindowState();
            TextResult.BeginInvoke(new Action<int, int>(ShowText), _letters.Length, FileActions.LongestArray(_letters));

            //save result into file
            var pageNumber = "";
            if (_bitmap.GetFrameCount(FrameDimension.Page) > 1)
            {
                PageNextClick(null, null);
                pageNumber = _currentPage.ToString();
            }

            var path = FileActions.ResultsFolderPath + Path.GetFileNameWithoutExtension(_currentImagePath) + pageNumber + ".txt";
            var answer = FileActions.SaveTextIntoFile(text, path);
            MessageBox.Show(answer ?? @"Text result was successfuly saved into" + Environment.NewLine + path);
        }

        /// <summary>
        /// read image, recognize which font using in it and load that font.
        /// (it reads only the first line to determine)
        /// </summary>
        private void AutoDetectFontTask()
        {
            StatusBar.Invoke(new Action(() => StopProcess.Visible = true));
            //calculate and separate for letters
            try
            {
                _letterBounds = TextImageActions.GetAllLettersBounds(_bitmap);
                _letters = TextImageActions.RetrieveText(_bitmap,_letterBounds, FontActions.LetterSize);
            }
            catch (Exception ex)
            {
                StatusBar.BeginInvoke(new Action(() => StopProcess.Visible = false));
                RestoreWindowState();
                MessageBox.Show(string.Format("Retrieving text failed\n" + ex.Message));
                return;
            }
            if (_letters == null)
            {
                StatusBar.BeginInvoke(new Action(() => StopProcess.Visible = false));
                RestoreWindowState();
                MessageBox.Show(string.Format("Retrieving text failed"));
                return;
            }

            //init variables
            var maxFontRank = 0.0;
            var maxFont = "";

            //check all fonts for best match
            foreach (var item in FontsComboBox.Items)
            {
                if (!StopProcess.Visible) return;
                //load font of current item
                if (item.ToString() == "*Auto") continue;
                var currentFontPath = FontActions.FontsFolderPath + @"\" + item + ".net";
                var fontNetwork = FileActions.LoadNetwork(currentFontPath);
                if (fontNetwork == null) continue;

                //check font and rank it
                var result = _letters.SelectMany(letter => letter).Sum(letter =>
                    fontNetwork.Compute(FontActions.LetterParameters(letter,FontActions.Pixels)[0]).Max());
                if (result < maxFontRank) continue;
                maxFontRank = result;
                maxFont = item.ToString();
            }

            //choose font with best rank
            _currentFontPath = FontActions.FontsFolderPath + @"\" + maxFont + ".net";
            _fontNetwork = FileActions.LoadNetwork(_currentFontPath);
            FontsComboBox.Invoke(new Action(() => { FontsComboBox.SelectedItem = maxFont; }));
        }

        /// <summary>
        /// Called back after auto detect font, and call for get text task
        /// </summary>
        /// <param name="ar">async result</param>
        private void GetTextCallBack(IAsyncResult ar)
        {
            if (!StopProcess.Visible)
            {
                RestoreWindowState();
                return;                
            }

            StatusBar.Invoke(new Action(() => Message.Text = @"Recognizing text..."));
            new Action(GetTextTask).BeginInvoke(null, null);
            StatusBar.Invoke(new Action(() => StopProcess.Visible = false));
        }

        /// <summary>
        /// Task that take the current image bitmap and rotate it till
        /// straight if needed
        /// </summary>
        private void RotateTask()
        {
            try
            {
                _bitmap = ImageFilter.PerformRotation(_bitmap);
            }
            catch(OutOfMemoryException e)
            {
                MessageBox.Show(e.Message + Environment.NewLine + @"Restarting application");
                Application.Restart();
            }
            catch (Exception e)
            {
                MessageBox.Show(@"Operation of rotating image failed" + Environment.NewLine + e.Message);
                StatusBar.Invoke(new Action(RestoreWindowState));
                return;
            }
            StatusBar.Invoke(new Action(() => ShowSource(_bitmap)));
            StatusBar.Invoke(new Action(RestoreWindowState));
        }

        /// <summary>
        /// Task that take the current image bitmap and clean it
        /// using the median filter
        /// </summary>
        private void CleanTask()
        {
            try
            {
                _bitmap = ImageFilter.PerformClean(_bitmap);
            }
            catch (Exception)
            {
                MessageBox.Show(@"Operation of cleaning image failed");
                StatusBar.Invoke(new Action(RestoreWindowState));
                return;
            }
            StatusBar.Invoke(new Action(() => ShowSource(_bitmap)));
            StatusBar.Invoke(new Action(RestoreWindowState));
        }

        /// <summary>
        /// Task that take the current image bitmap and fix it
        /// using the threshold filter
        /// </summary>
        private void ThresholdTask()
        {
            try
            {
                _bitmap = ImageFilter.PerformThreshold(_bitmap);
            }
            catch (Exception e)
            {
                MessageBox.Show(@"Operation of thresholing image failed\n" + e.Message);
                StatusBar.Invoke(new Action(RestoreWindowState));
                return;
            }
            StatusBar.Invoke(new Action(() => ShowSource(_bitmap)));
            StatusBar.Invoke(new Action(RestoreWindowState));
        }

        /// <summary>
        /// Center the image and save it into current bitmap.
        /// It also show the result on screen
        /// </summary>
        private void CenterizeTask()
        {
            try
            {
                _bitmap = TextImageActions.Centerize(_bitmap);
            }
            catch (Exception e)
            {
                MessageBox.Show(@"Operation of centerizing image failed\n" + e.Message);
                StatusBar.Invoke(new Action(RestoreWindowState));
                return;
            }
            StatusBar.Invoke(new Action(() => ShowSource(_bitmap)));
            StatusBar.Invoke(new Action(RestoreWindowState));
        }

        /// <summary>
        /// Task of recognizing text of a multi pages image or pdf
        /// </summary>
        private void GetMultiPageTextTask()
        {
            //initialize method
            StatusBar.Invoke(new Action(() =>
            {
                InAction(true);
                StopProcess.Visible = true;
            }));
            var numberOfPages = _bitmap.GetFrameCount(FrameDimension.Page);
            var successPages = new bool[numberOfPages];
            _currentPage = 0;
            _bitmap.SelectActiveFrame(FrameDimension.Page, _currentPage);
            StatusBar.Invoke(new Action(() => { SourcePicture.Image = _bitmap; }));
            PageNumber.Text = @"Page " + (_currentPage + 1) + @" / " + numberOfPages;
            
            //get and save all pages
            for (var i = 1; i <= numberOfPages; i++)
            {
                try
                {
                    if (StopProcess.Visible == false)
                    {
                        StatusBar.Invoke(new Action(() =>
                        {
                            InAction(false);
                            PageNext.Visible = true;
                            PagePrev.Visible = true;
                        }));
                        return;
                    }
                    StatusBar.Invoke(new Action(() => Message.Text = @"Retrieving Text..."));
                    _bitmap.SelectActiveFrame(FrameDimension.Page, i);
                    _letters = null;
                    successPages[i - 1] = GetPageTextTask();
                }
                catch (Exception)
                {
                    successPages[i - 1] = false;
                }
            }
            StopProcess.Visible = false;

            //check if all pages succeed, build and write message
            var isAllTrue = !successPages.Any(page => !page);
            string message;
            if (isAllTrue) message = "All pages has successfuly saved into " + FileActions.ResultsFolderPath;
            else
            {
                message = "Retrieving text has failed in pages: ";
                for (var i = 0; i < successPages.Length; i++)
                {
                    var page = successPages[i];
                    if (page == false) message += (i + 1) + ", ";
                }
            }

            StatusBar.Invoke(new Action(delegate
            {
                InAction(false);
                MessageBox.Show(message);
            }));
        }

        /// <summary>
        /// Task of recognizing text of one page out of multi pages image.
        /// It also returns parameter that indicates whether operation succeed
        /// </summary>
        /// <returns>is succeed</returns>
        private bool GetPageTextTask()
        {
            //calculate and separate for letters
            try
            {
                _letterBounds = TextImageActions.GetAllLettersBounds(_bitmap);
                _letters = TextImageActions.RetrieveText(_bitmap,_letterBounds, FontActions.LetterSize);
            }
            catch (Exception)
            {
                PageNextClick(null, null);
                return false;
            }
            if (_letters == null)
            {
                PageNextClick(null, null);
                return false;
            }

            //calculate text
            var text = "";
            var size = FontActions.NumberOfElements(_letters);
            var letters = FontActions.DeployArray(_letters, size);
            foreach (var letter in letters)
            {
                //check case of space
                if (FontActions.IsSpace(letter))
                {
                    text += @" ";
                    continue;
                }
                var result = CalculateLetter(letter);
                text += FontActions.LettersInNetwork[result];
            }

            //add spaces between lines
            var currentLetter = 0;
            foreach (var line in _letters)
            {
                currentLetter += line.Length;
                text = text.Insert(currentLetter, "\n");
                currentLetter++;
            }
            text = text.Remove(text.Length - 1);

            //save result into file
            var pageNumber = (_currentPage + 1).ToString();
            PageNextClick(null, null);
            var path = FileActions.ResultsFolderPath + Path.GetFileNameWithoutExtension(_currentImagePath) + pageNumber + ".txt";
            FileActions.SaveTextIntoFile(text, path);
            return true;
        }

        #endregion

        #region Events

        /// <summary>
        /// Event of Clicking Select Image Button,
        /// that open file dialog and asks you for image to use.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SelectImageClick(object sender, EventArgs e)
        {
            SourcePicture.BeginInvoke(new Action(() => SelectImageDialog()));
            FontsComboBox.SelectedIndex = 0;
        }

        /// <summary>
        /// Event of clicking Create Font button,
        /// that loads font image from using dialog and
        /// create font network from it.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CreateFontClick(object sender, EventArgs e)
        {
            //select font image and get letters
            if (!SelectImageDialog()) return;
            _letterBounds = TextImageActions.GetAllLettersBounds(_bitmap);
            _letters = TextImageActions.RetrieveText(_bitmap, _letterBounds);

            //check if image of text selected
            if (_bitmap == null || _letters == null)
            {
                MessageBox.Show(string.Format("Select font image"));
                return;
            }

            //check if image can be font image
            if (FontActions.NumberOfElements(_letters) % (FontActions.LettersOfInitial.Length) != 0)
            {
                MessageBox.Show(string.Format("Select font image with {0} letters or multiply of it", (FontActions.LettersOfInitial.Length)));
                return;
            }

            //create the font and show message if error
            var message = CreateFontTask();
            if (message != null) MessageBox.Show(message);

            //update fonts combobox
            _currentFontPath = Path.ChangeExtension(_currentImagePath, "net");
            UpdateFontsComboBox();
            var fontName = Path.GetFileNameWithoutExtension(_currentFontPath);
            if (FontsComboBox.Text == fontName) return;
            FontsComboBox.Text = fontName;
        }

        /// <summary>
        /// Event of clicking on Empty Font button,
        /// that create an empty font network
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EmptyFontClick(object sender, EventArgs e)
        {
            var inputbox = new InputBox("Enter font name");
            if (inputbox.ShowDialog() != DialogResult.OK) return;
            var fontName = inputbox.Result;
            if (!FileActions.IsFontNameAvailable(fontName)) return;
            var message = CreateFontTask(fontName);
            if (message != null) MessageBox.Show(message);

            //calculate network path
            var currentFontPath = _currentImagePath.Remove(_currentImagePath.Length - 3);
            _currentFontPath = currentFontPath.Insert(currentFontPath.Length, "net");

            //update fonts combobox
            UpdateFontsComboBox();
            if (FontsComboBox.Text == fontName) return;
            FontsComboBox.Text = fontName;
        }

        /// <summary>
        /// Event of clicking Train Network button,
        /// that train the network and show test results.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TrainNetworkClick(object sender, EventArgs e)
        {
            //check if font network loaded
            if (_fontNetwork == null || FontsComboBox.Text == @"*Auto")
            {
                MessageBox.Show(@"Choose font");
                return;
            }

            //create and call training dialog
            var trainingUc = new TrainingUc();
            _trainForm = new Form
                             {
                                 Text = @"Training",
                                 Size = new Size(trainingUc.Size.Width + 20, trainingUc.Size.Height + 40)
                             };
            var fontName = FontsComboBox.SelectedItem.ToString();
            trainingUc.Init(_fontNetwork, _scriptMode, _trainForm, fontName);
            _trainForm.Controls.Add(trainingUc);
            _trainForm.ShowDialog();
            trainingUc.UnRegister();
            NoteTrainYourNetwork.Visible = false;

            //save network into file
            var message = FileActions.SaveNetwork(_currentFontPath, _fontNetwork);
            if (message != null) MessageBox.Show(message);
        }

        /// <summary>
        /// Event of clicking Get Text button,
        /// that use the network to retrieve the text.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GetTextClick(object sender, EventArgs e)
        {
            _letters = null;

            //check if font selected
            if (FontsComboBox.SelectedItem == null)
            {
                MessageBox.Show(@"Select font");
                return;
            }

            //check if image selected
            if (_bitmap == null)
            {
                MessageBox.Show(@"Select image");
                return;
            }

            //check if there are fonts
            if (FontsComboBox.Items.Count <= 1)
            {
                MessageBox.Show(@"Create fonts");
                return;
            }

            //check if auto detection selected
            if (FontsComboBox.SelectedItem.ToString() == "*Auto")
            {
                Message.Text = @"Identifying font...";
                StatusBarProgress.Visible = true;
                InAction(true);
                new Action(AutoDetectFontTask).BeginInvoke(GetTextCallBack, null);
                return;
            }

            //check if font network selected
            if (_fontNetwork == null)
            {
                RestoreWindowState();
                MessageBox.Show(@"Select font network");
                return;
            }

            //check case of multipages
            if (_bitmap.GetFrameCount(FrameDimension.Page)>1)
            {
                Message.Text = @"Recognizing text...";
                InAction(true);
                new Action(GetMultiPageTextTask).BeginInvoke(null, null);
                return;
            }

            //get the text
            Message.Text = @"Recognizing text...";
            InAction(true);
            new Action(GetTextTask).BeginInvoke(null, null);
            NoteTrainYourNetwork.Visible = false;
        }

        /// <summary>
        /// Event of clicking Repair Network,
        /// that get letter bitmap and correct letter in text
        /// and repair the network for current letter.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RepairNetworkClick(object sender, EventArgs e)
        {
            if (_bitmap == null)
            {
                MessageBox.Show(@"Select Image");
                return;
            }
            if (_letters == null)
            {
                MessageBox.Show(@"Get Text");
                return;
            }
            if (ResultLetterPicture.Image == null)
            {
                MessageBox.Show(@"Select letter to repair");
                return;
            }
            if (ResultLetterText.Text.Length != 1)
            {
                MessageBox.Show(@"Enter one letter");
                return;
            }
            var letterChar = ResultLetterText.Text[0];
            var letterNumber = FontActions.LettersInNetwork.IndexOf(letterChar);
            if (letterNumber == -1)
            {
                MessageBox.Show(string.Format("Enter known letter. One of those:\n{0}", FontActions.LettersInNetwork));
                return;
            }
            if (_fontNetwork == null)
            {
                MessageBox.Show(@"Select font");
                return;
            }

            var letterBitmap = new Bitmap(ResultLetterPicture.Image);
            var data = FontActions.CreateLetterData(letterBitmap, letterNumber, FontActions.LettersInNetwork.Length, FontActions.Pixels);
            _fontNetwork.AddToDataSet(data);
                    UpdateTextInTextResult(_markedIndex, letterChar);
            NoteTrainYourNetwork.Visible = true;
        }

        /// <summary>
        /// Get index of letter in TextResult and letter,
        /// and update that index to value letter.
        /// </summary>
        /// <param name="index">index of letter</param>
        /// <param name="letter">letter char</param>
        private void UpdateTextInTextResult(int? index, char letter)
        {
            if (index == null || index < 0) return;
            TextResult.Text = TextResult.Text.Remove((int)index,1).Insert((int)index, letter.ToString());
        }

        /// <summary>
        /// Event of changing Font ComboBox selection,
        /// that loads the selected network.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FontsComboBoxSelectedIndexChanged(object sender, EventArgs e)
        {
            //choose font file
            if (FontsComboBox.SelectedItem.ToString() == "*Auto") return;
            _currentFontPath = FontActions.FontsFolderPath + @"\" + FontsComboBox.SelectedItem + ".net";
            _fontNetwork = FileActions.LoadNetwork(_currentFontPath);
            if (_fontNetwork == null)
                MessageBox.Show(@"Error reading font file");
        }

        /// <summary>
        /// Event of changing selection text in Text Result,
        /// that calc selected letter and show it on repair section
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TextResultSelectionChanged(object sender, EventArgs e)
        {
            //calc selected letter in result text box
            var index = TextResult.SelectionStart;
            var line = 1;
            var letter = 1;
            for (var i = 0; i < index; i++)
                if (TextResult.Text[i] == '\n')
                {
                    line++;
                    letter = 1;
                }
                else
                    letter++;

            //show on repair section
            try
            {
                ShowResultLetterText(line, letter);
                if (_markedLine != null && _markedLetter != null)
                    MarkCurrentLetter((int) _markedLine, (int) _markedLetter, Color.White);
                MarkCurrentLetter(line, letter,Color.Red);
                _markedLine = line;
                _markedLetter = letter;
                _markedIndex = TextResult.SelectionStart;
            }
            catch (Exception)
            {
                return;
            }
        }

        /// <summary>
        /// Event of clicking on Stop Process button that
        /// stop any process by setting his own button visibility to false.
        /// It is only posible if the process checkes the visiblity of the button
        /// every cycle.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StopProcessClick(object sender, EventArgs e)
        {
            StatusBar.Invoke(new Action(() => StopProcess.Visible = false));
        }

        /// <summary>
        /// Event of clicking on Rotate button,
        /// that call for Rotate task
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RotateClick(object sender, EventArgs e)
        {
            if (_bitmap == null)
            {
                MessageBox.Show(@"Select image first");
                return;
            }
            InAction(true);
            Action rotateAction = RotateTask;
            rotateAction.BeginInvoke(null, null);
            Message.Text = @"Rotating...";
        }

        /// <summary>
        /// Event of clicking on Clean button,
        /// that call for Clean task
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CleanClick(object sender, EventArgs e)
        {
            if (_bitmap == null)
            {
                MessageBox.Show(@"Select image first");
                return;
            }
            InAction(true);
            Action cleanAction = CleanTask;
            cleanAction.BeginInvoke(null, null);
            Message.Text = @"Cleaning image...";
        }

        /// <summary>
        /// Event of clicking on Threshold button,
        /// that call for Threshold task
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ThresholdClick(object sender, EventArgs e)
        {
            if (_bitmap == null)
            {
                MessageBox.Show(@"Select image first");
                return;
            }
            InAction(true);
            Action thresholdAction = ThresholdTask;
            thresholdAction.BeginInvoke(null, null);
            Message.Text = @"Thresholding...";
        }

        /// <summary>
        /// Event of clicking on Centerize button that
        /// call for centeize task and center the image
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CenterizeClick(object sender, EventArgs e)
        {
            if (_bitmap == null)
            {
                MessageBox.Show(@"Select image first");
                return;
            }
            InAction(true);
            Action centerizeAction = CenterizeTask;
            centerizeAction.BeginInvoke(null, null);
            Message.Text = @"Centerizing...";
        }

        /// <summary>
        /// Event of clicking on Next Page button that showing the next image
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PageNextClick(object sender, EventArgs e)
        {
            var pageCount = _bitmap.GetFrameCount(FrameDimension.Page);
            if (_currentPage + 1 >= pageCount) return;
            _bitmap.SelectActiveFrame(FrameDimension.Page, ++_currentPage);
            SourcePicture.Image = _bitmap;
            PageNumber.Text = @"Page " + (_currentPage + 1) + @" / " + pageCount;
        }

        /// <summary>
        /// Event of clicking on Prev Page button that showing the prev image
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PagePrevClick(object sender, EventArgs e)
        {
            var pageCount = _bitmap.GetFrameCount(FrameDimension.Page);
            if (_currentPage <= 0) return;
            _bitmap.SelectActiveFrame(FrameDimension.Page, --_currentPage);
            SourcePicture.Image = _bitmap;
            PageNumber.Text = @"Page " + (_currentPage + 1) + @" / " + pageCount;
        }

        #endregion

        #region Scripts

        /// <summary>
        /// Event of clicking on Train All Script button that
        /// opens the training user control and start training all fonts.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TrainAllScriptClick(object sender, EventArgs e)
        {
            //create training dialog
            var trainingUc = new TrainingUc();
            _trainForm = new Form
            {
                Text = @"Training",
                Size = new Size(trainingUc.Size.Width + 20, trainingUc.Size.Height + 40)
            };
            
            _scriptMode = true;
            var directoryInfo = new DirectoryInfo(FontActions.FontsFolderPath);
            var files = directoryInfo.GetFiles();
            foreach (var file in files.Where(file => file.Extension == ".net"))
            {
                //init font path and network
                var path = file.FullName;
                var fontName = file.Name.Remove(file.Name.Length - 4);
                _currentFontPath = path;
                _fontNetwork = FileActions.LoadNetwork(_currentFontPath);

                //open training dialog
                trainingUc.StopScriptClicked += delegate { _scriptMode = false; };
                trainingUc.Init(_fontNetwork, _scriptMode, _trainForm, fontName);
                _trainForm.Controls.Add(trainingUc);
                _trainForm.ShowDialog();
                trainingUc.UnRegister();

                //save network into file
                Thread.Sleep(10);
                FileActions.SaveNetwork(_currentFontPath, _fontNetwork);
                if (!_scriptMode) return;
            }
            _scriptMode = false;
        }

        /// <summary>
        /// Event of clicking on Create All Fonts Script that
        /// call for the appropriate task that create the font images
        /// and then create the networks from it
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CreateAllFontsScriptClick(object sender, EventArgs e)
        {
            new Action(CreateAllFontsScriptTask).BeginInvoke(null, null);
        }

        /// <summary>
        /// Task that create the font images
        /// and then create the networks from it
        /// </summary>
        private void CreateAllFontsScriptTask()
        {
            MainMenuStrip.Invoke(new Action(delegate
            {
                InAction(true);
                Message.Text = @"Create Fonts";
            }));
            CreateFontImages();
            MainMenuStrip.Invoke(new Action(() => Message.Text = @"Create Networks"));
            CreateNetworksFromImages();
            MainMenuStrip.Invoke(new Action(delegate
            {
                InAction(false);
                Message.Text = @"Ready";
            }));
        }

        /// <summary>
        /// Create font images of choosen windows fonts
        /// </summary>
        private void CreateFontImages()
        {
            var fonts = _fontNames.Select(font => new FontFamily(font));

            //initial progressbar
            StatusBar.Invoke(new Action(() =>
            {
                StatusBarProgress.Style = ProgressBarStyle.Blocks;
                StatusBarProgress.Value = 0;
                StatusBarProgress.Maximum = fonts.Count();
                StatusBarProgress.Minimum = 0;
                StatusBarProgress.Visible = true;
            }));

            //create fonts images
            foreach (var fontFamily in fonts)
            {
                try
                {
                    FontActions.MakeFont(fontFamily);
                    StatusBar.Invoke(new Action(() => StatusBarProgress.Value++));
                }
                catch (Exception)
                {
                    continue;
                }
            }
            //finalize progressbar
            StatusBar.Invoke(new Action(() =>
            {
                StatusBarProgress.Visible = false;
                StatusBarProgress.Style = ProgressBarStyle.Marquee;
                StatusBarProgress.Value = 0;
            }));
        }

        /// <summary>
        /// Create all networks from images of fonts that
        /// are now known to the application
        /// </summary>
        private void CreateNetworksFromImages()
        {
            var directoryInfo = new DirectoryInfo(FontActions.FontsFolderPath);
            var files = directoryInfo.GetFiles().Where(file => file.Extension == ".png");
            
            //initial progressbar
            StatusBar.BeginInvoke(new Action(delegate
            {
                StatusBarProgress.Value = 0;
                StatusBarProgress.Style = ProgressBarStyle.Blocks;
                StatusBarProgress.Maximum = files.Count();
                StatusBarProgress.Minimum = 0;
                StatusBarProgress.Visible = true;
            }));

            //create networks
            foreach (var path in files.Select(file => file.FullName))
            {
                StatusBar.BeginInvoke(new Action(() => StatusBarProgress.Value++));
                _currentImagePath = path;
                _bitmap = TextImageActions.PadImageFrame(new Bitmap(_currentImagePath));
                _letterBounds = TextImageActions.GetAllLettersBounds(_bitmap);
                _letters = TextImageActions.RetrieveText(_bitmap, _letterBounds);
                if (_letters != null) CreateFontTask();
            }

            //finalize progressbar and update fonts combobox
            StatusBar.BeginInvoke(new Action(delegate
            {
                UpdateFontsComboBox();
                StatusBarProgress.Visible = false;
                StatusBarProgress.Style = ProgressBarStyle.Marquee;
                StatusBarProgress.Value = 0;
            }));
        }

        #endregion
    }
}