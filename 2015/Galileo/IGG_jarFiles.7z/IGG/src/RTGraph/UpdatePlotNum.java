/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RTGraph;


import org.jfree.chart.plot.CombinedDomainXYPlot;
import org.jfree.chart.plot.XYPlot;


/**
 * This class handles the updating of the plots shown on the graphs in the main app (monitor, simulation and measurements).<p>
 * It is a class with static methods which change the plots display on the graph passed to them.
 * 
 * @author Gil Aizenshtadt
 */


public class UpdatePlotNum {
    
    /**
     * This method modifies the "visibility" of a single sub-plot.<br>
     * @param pl the plot from the graph, which contains the sub-plots.
     * @param subpl the sub-plot array containing all available sub-plots.
     * @param plotNum the index of the sub-plot the modify.
     * @param show a Boolean determining wether to show or hide the selected sub-plot.
     */
    public static void updatePlotNum(CombinedDomainXYPlot pl, XYPlot[] subpl, int plotNum, boolean show){
        if(show){
            pl.add(subpl[plotNum]);
        }
        else{
            pl.remove(subpl[plotNum]);
        }
    }
    
    /**
     * This method updates the number of sub-plots shown to the number passed to it.<p>
     * The final display will show sub-plots from the first sub-plot element in the sub-plot array, and up to 
     * the element whose number is the number passed to the method.
     * @param plot the plot from the graph which contains the sub-plots.
     * @param subp the sub-plot array containing all sub-plots available.
     * @param plotNum the number of sub-plots to display.
     * @param totalNum the total number of sub-plots available.
     */    
    public static void updateCont(CombinedDomainXYPlot plot, XYPlot[] subp, int plotNum, int totalNum){
        for(int i=0; i <= (plotNum-1); i++){
            plot.add(subp[i]);
        } 
        for(int j=(totalNum-1); j > (plotNum-1); j-- ) {
            plot.remove(subp[j]);
        }
    }
    
    /**
     * This method updates the sub-plots shown on the graph using the passed integer arrays describing which sub-plot should be displayed and
     * which shouldn't.
     * @param plot the plot from the graph, which contains the sub-plots.
     * @param subp the sub-plot array containing all available sub-plots.
     * @param plotsToRevive an Integer array containing the number of sub-plots to show.
     * @param plotsToKill an Integer array containing the number of sub-plots to hide.
     */
    public static void updateDis(CombinedDomainXYPlot plot, XYPlot[] subp, int[] plotsToRevive, int[] plotsToKill){
        for(int f:plotsToKill){
            plot.remove(subp[f]);
        }
        for(int k:plotsToRevive){
            plot.add(subp[k]);
        }
    }
}


