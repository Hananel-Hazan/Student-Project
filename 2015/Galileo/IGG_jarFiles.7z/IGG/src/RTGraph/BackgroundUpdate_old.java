/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RTGraph;

import org.jfree.data.time.Millisecond;
import org.jfree.data.time.TimeSeriesCollection;

/**
 *
 * @author GXA
 */
public class BackgroundUpdate_old extends Thread{
    
    ////    USE SERVER_USER_INTERFACE TO READ LINES ////
    ////    PERHAPS EVEN ADD SEPARATE METHODS TO READ FROM MONITOR/MODEL/SIMULATION.... ////
    
    int plotNum = 0;
    double[] updateVal;
    TimeSeriesCollection[] setsToUpdate ;
    String tempLine;
    boolean isRunning = true;
    
    public BackgroundUpdate_old(int plNum,TimeSeriesCollection[] dataSets){
        plotNum = plNum;
        setsToUpdate = dataSets;
        updateVal = new double[plotNum];
    }
    
    
    
    public void reset(){
        isRunning = true;
    }
    
    @Override
    public void run(){
        while(((tempLine = FetchData.read()) != null)&& isRunning){
            for (int i = 0; i < plotNum; i++) {
                updateVal[i] = Double.parseDouble(tempLine);
                setsToUpdate[i].getSeries(0).addOrUpdate(new Millisecond(), updateVal[i]);
                
            }
        }
    }
    
    public void tryToStop(){
        isRunning = false;
    }
    
}
