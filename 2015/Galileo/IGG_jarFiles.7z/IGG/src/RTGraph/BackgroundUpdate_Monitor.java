/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RTGraph;

import java.util.LinkedList;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

/**
 * This class handles the background process of the monitor graph updating.<p>
 * When it is running repeatedly in the background, it reads data from the server connected to the controller,
 * parses it into an array of Double[], and adds the recieved points to the graph. <br>
 * When the number of points reaches a certain limit, in order to avoid a big delay
 * in the update, some old points are deleted from the graph.<p>
 * Each point that is read from the server is stored in a LinkedList to allow saving the data to a file when the session is over.
 * 
 *
 * @author Gil Aizenshtadt
 */
public class BackgroundUpdate_Monitor extends Thread{
    ///// Variables for limiting number of points in graph. //////
    /** the limit of number of points stored in the graph's database (the series in the datasets). */
    public final int UPRATE = 1300*4;
    /** the number of points to delete when the UPRATE limit is reached. */
    final int DELNUM = 100;
    /** used for converting micro-seconds to seconds in the Model session. */
    final double DIVISOR = 1000000.0;
    /** used to count the number of skipped points for each channel in the Model session. the graph skips every second point.  */
    int[] j = {0,0,0,0,0,0};
    ////////////////////////////////////////////////////////////////
    /** converts the anaolg input's data from ADC values to volts. Assumes the resolution is 12 bit and the max voltage is 5 volts */
    private final double partOfFive = 5.0/4096.0;
    ////////////////////////////////////////////////////////////////
    ///// Variable declaration for the parseLine method. ///////////
    /** The index of a data value in the array the data is parsed to. */
    private int parseLineDataInd = 0;
    /** The index of a space char in the line recieved from the board. */
    private int parseLineSpaceInd = 0;
    /** The starting index of a data value in the line recieved from the board. */
    private int parseLine_K_Ind = 0;
    /** The array to which the line recievd from the board is parsed to. */
    private double parseLineData[];
    ////////////////////////////////////////////////////////////////
    ///// ServerUserInterface declaration //////////////////////////
    /** handles the server communications between the PC and the board */    
    public ServerUserInterface SUI;
    //////////////////////////////////////////////////////////////////
    ///// Variables for the actual updating of the graph. ////////////
    /** The overall number of subplot available. */
    final int plotNumFixed = 6;
    /** stores a parsed line data sent from the board */
    double[] updateVal;
    /** describes which channel is shown (1) and which is not (0). */
    public int[] channels;
    /** stores the datasets recieved from the RTGraph class. */
    XYSeriesCollection[] setsToUpdate ;
    /** stores the data series which shown on the plot. */
    XYSeries[] setsTS;
    ////////////////////////////////////////////////////////////////
    //// Boolean for stopping/runnning the background process /////
    /** used for trying to stop the background process. */
    boolean isRunning = true;
    ////////////////////////////////////////////////////////////////////////
    //// LinkedList for storing all the data collected in the session //////
    /** stores all the data collected in the session. */
    public LinkedList<double[]> fifo;
    //////////////////////////////////////////////////////////////////////
    
    /**
     * This constructor initiates a new instance of the class with an existing instance of the ServerUserInterface class.
     * @param plNum the number of sub-plots currently shown on the graph.
     * @param dataSets the datasets holding the points which are drawn on the graph.
     * @param sui the ServerUserInterface instance.
     * @param stck the FIFO stack passed from the graph which will store all the data collected in the session.
     * @param chan the Integer array describing which channel is shown on the graph and which isn't.
     */
    public BackgroundUpdate_Monitor(int plNum,XYSeriesCollection[] dataSets, ServerUserInterface sui, LinkedList<double[]> stck, int[] chan){
        this.fifo = stck;
        SUI = sui;
        
        setsToUpdate = dataSets;
        updateVal = new double[plotNumFixed];
        setsTS = new XYSeries[dataSets.length];

        
        for(int i=0; i < setsTS.length; i++){
            setsTS[i] = setsToUpdate[i].getSeries(0);
        }

        channels = chan;
    }
    
    /**
     * This constructor initiates a new instance of the class without an existing instance of the ServerUserInterface class.<br>
     * The SUI class instance will be add when a new session starts.
     * @param plNum the number of sub-plots currently shown on the graph.
     * @param dataSets the datasets holding the points which are drawn on the graph.
     * @param stck the FIFO stack passed from the graph which will store all the data collected in the session.
     * @param chan the Integer array describing which channel is shown on the graph and which isn't.
     */    
    public BackgroundUpdate_Monitor(int plNum,XYSeriesCollection[] dataSets, LinkedList<double[]> stck, int[] chan){
        this.fifo = stck;
        setsToUpdate = dataSets;
        updateVal = new double[plotNumFixed];
        setsTS = new XYSeries[dataSets.length];

        for(int i=0; i < plotNumFixed; i++){
                setsTS[i] = setsToUpdate[i].getSeries(0);
        }
        channels = chan;
    }
    
    /**
     * This method passes to the BackgroundUpdate class the ServerUserinterface instance from the RealTimeGraph class, when a new session starts up.
     * @param sui the ServerUserInstance passed to this class.
     */
    public void startSUI(ServerUserInterface sui){
        SUI = sui;
    }
    
    /**
     * This method starts the monitor session.<p>
     * It calls methods which open the server sockets and sends the data regarding which analog inputs should be monitored in the controller.
     * @param inputs the Integer array describing which channel is "on" and which one is "off".
     * @return True if the socket connection and the data sending was successful, False otherwise.
     */
    public boolean startMonitor(int inputs[]){
        return SUI.openMonitorSocket()&&SUI.sendMonitorData(inputs);
    }
    
    /**
     * This method updates the session by sending data to the controller, describing which channels(analog inputs) should be monitored, and which shouldn't.
     * @param inputs the Integer array describing which channel is "on" and which one is "off".
     * @return True if the data was sent successfully, False otherwise.
     */
    public boolean updateChannels( int inputs[]){
        return SUI.sendMonitorData(inputs);
    }
    
    /**
     * This method resets the background process.
     */
    public void reset(){
        isRunning = true;
    }
    
    /**
     * This is the main method of the class which handles the background updating of the graph. <p>
     * It performs constantly a reading from the server, parsing the data and adding the points to the graph.
     * Also, when a the number of points in the graph reaches a limit, a constant number old points is deleted, to keep the
     * delay to update the graph low.
     */
    @Override
    public void run(){
        System.out.println("BackgroundUpdate class: entering run...");
        while(isRunning){
            updateVal = parseLine(SUI.receiveMonitorData());
            fifo.addFirst(updateVal);
            for (int i = 0; i < plotNumFixed; i++) {
                try{
                    if(channels[i]==1){
                        if(++j[i]>=2){
                            j[i]=0;
                            setsTS[i].addOrUpdate(updateVal[0]/DIVISOR, updateVal[i+1]*partOfFive);
                        }
                    }
                    if(setsTS[i].getItemCount() > UPRATE){
                        setsTS[i].delete(0, DELNUM);
                    }
                }
                catch(NullPointerException npe){
                    System.err.println("bu run: problem:" + npe + " updateVal: " + updateVal[i]);
                }
            }
        }
        System.out.println("BackgroundUpdate class: finishing run...");
    }

    /**
     * This method is called from the main thread to try and finish this thread by causing the while loop to stop and ending the run() method.
     */
    public void tryToStop(){
        isRunning = false;
    }
    
    /**
     * This method recieves the data sent from the controller and parses it to a double array.<br>
     * Each element in the array is a point which will be added to the graph to its fitting sub-plot.
     * @param line the String line recieved from the controller.
     * @return Double array containing the points to be added to the graph.
     */
    private double[] parseLine(String line){
        parseLine_K_Ind = 0;
        parseLineDataInd = 0;
        parseLineSpaceInd = 0;
        parseLineData = new double[plotNumFixed+1];
        try{
            while(parseLine_K_Ind < line.length()){
                parseLineSpaceInd = line.indexOf(" ",parseLine_K_Ind);
                parseLineData[parseLineDataInd] = Double.parseDouble(line.substring(parseLine_K_Ind, parseLineSpaceInd));
                parseLine_K_Ind = (parseLineSpaceInd+1);
                parseLineDataInd ++;
            }
        }
        catch(NullPointerException npe){
            System.err.println("BackgroundUpdate class: Problem: " + npe);
            /*JOptionPane.showMessageDialog(null, "Connection problem!\nCheck the ethernet connection, and press \"Stop\"\n"
                    + "and then \"Connect\" to restart monitor.");*/
            return null;
        }
        catch(ArrayIndexOutOfBoundsException aioobe){
            System.err.println("parseLine: Problem: " + aioobe);
            System.out.println("line: " + line + " pLDI: " + parseLineDataInd + " plotNum: " + plotNumFixed);
        }
        return parseLineData;
    }
}