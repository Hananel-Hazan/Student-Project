package RTGraph;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.LinkedList;
import javax.swing.JPanel;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.DateTickUnitType;
import org.jfree.chart.axis.DateTickUnit;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CombinedDomainXYPlot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

    /****************************************************************************
     * JFREECHART DEVELOPER GUIDE                                               *
     * The JFreeChart Developer Guide, written by David Gilbert, is available   *
     * to purchase from Object Refinery Limited:                                *
     *                                                                          *
     * http://www.object-refinery.com/jfreechart/guide.html                     *
     *                                                                          *
     * Sales are used to provide funding for the JFreeChart project - please    * 
     * support us so that we can continue developing free software.             *
     ****************************************************************************/

/**
 * This class creates the graph interface for the monitor tab in the main app.
 * Based on a JFreeChart demo example:
 * "A demonstration application showing a time series chart where you can dynamically add
 * (random) data by clicking on a button."
 * @author Gil Aizenshtadt
 */
public class RealTimeGraph_Monitor extends JPanel {

     /** Number of subplots. */
    public static final int SUBPLOT_COUNT = 6;
    ////////////////////////////////
    /** Array describing which channel is shown (=1) and which is not (=0). */
    public int channels[] = {1,0,0,0,0,0};
    /////////////////////////////////////
    /** The Collection of series containing the points shown in the graph. */
    public XYSeriesCollection[] datasets = new XYSeriesCollection[SUBPLOT_COUNT];
    //////////////////////////////////////////////////////////////////////////////////
    /** The series array for storing the points for each subplot in the graph. */
    XYSeries xys[] = new XYSeries[SUBPLOT_COUNT];
    ////////////////////////////////////////
    //// The elements for building the graph ///////
    /** Handles the subplots. */    
    final public XYPlot[] subp = new XYPlot[SUBPLOT_COUNT];
    /** The main plot which holds all the subplots. */    
    final public CombinedDomainXYPlot plot;
    /** The chart window. */
    final JFreeChart chart;
    /////////////////////////////////////////////////
    //// The graph's title ///////
    /** The chart's title. */
    String chartName;
    /** The base title of the chart: "Intel Galileo Analog Inputs". */
    public String baseTitle = "Intel Galileo Analog Inputs";
    ////////////////////////////
    /** The number of subplots currently shown in the graph. */
    static int plotNum = 1;
    /////////////////////////////////////////////////////
    //// The background interface for updating the graph////
    /** Handles the background update of the subplots in the chart. */    
    public BackgroundUpdate_Monitor bUM;
    /** Handles the communication and data exchange with the server. */    
    public ServerUserInterface SUI;
    //////////////////////////////////////////
    /** LinkedList for storing the simu/model data. */
    public LinkedList<double[]> fifo;
    /////////////////////////////////////////
    /** Font for the X and Y axes. */
    Font fnt = new Font("Dialog", Font.PLAIN, 16);
    /////////////////////////////////////////
    /////////////////////////////////////////
    
    
    /**
     * Constructs the graph.
     *
     * @param title  the frame chartName.
     */
    public RealTimeGraph_Monitor(final String title) {

        chartName = title;
        
        DateAxis timeAxis = new DateAxis("Time [sec]");
        DateFormat formatter = new SimpleDateFormat("ss");
        timeAxis.setTickUnit(new DateTickUnit(DateTickUnitType.SECOND,1,formatter));
        
        plot = new CombinedDomainXYPlot(new NumberAxis("Time"));
        
        for(int i=0; i<SUBPLOT_COUNT; i++){
            xys[i] = new XYSeries("input A"+Integer.toString(i));
            datasets[i] = new XYSeriesCollection(xys[i]);
            subp[i] = new XYPlot(datasets[i],null,new NumberAxis("[Volts]"), new StandardXYItemRenderer());
            subp[i].getRangeAxis().setTickLabelFont(fnt);
            subp[i].getRangeAxis().setLabelFont(fnt);
        }
        
        
        UpdatePlotNum.updateCont(plot,subp,plotNum,SUBPLOT_COUNT);
        chart = new JFreeChart(chartName, plot);
        
        chart.setBorderPaint(Color.black);
        chart.setBorderVisible(true);
        chart.setBackgroundPaint(Color.white);
        
        plot.setBackgroundPaint(Color.lightGray);
        plot.setDomainGridlinePaint(Color.white);
        plot.setRangeGridlinePaint(Color.white);
        plot.getDomainAxis().setTickLabelFont(fnt);
        plot.getDomainAxis().setLabelFont(fnt);
        
        final ValueAxis axis = plot.getDomainAxis();
        axis.setAutoRange(true);
        
        axis.setFixedAutoRange(10.0); // 20 seconds
        axis.setLabel("Time [sec]");
        
        final JPanel content = new JPanel(new BorderLayout());

        final ChartPanel chartPanel = new ChartPanel(chart);
        content.add(chartPanel);
        add(content);
        content.setVisible(true);

        fifo = new LinkedList<>();
        bUM = new BackgroundUpdate_Monitor(plotNum,datasets,fifo, channels);
        bUM.setDaemon(true);
    }

    /**
     * This method starts up the server UI class and resets the currently stored data on the graph.
     * The SUI class is responsible for the server connection (sending/recieving data) to the controller.
     * @param host the IP of the controller to connect to.
     */
    public void startServerUI(String host){
        SUI = new ServerUserInterface(host);
        bUM.startSUI(SUI);
        clearSetsAndFIFO();
    }
    
    /**
     * This method is used to set the title of the graph.
     * If the connection to the controller was successful and the session is running, then the title will
     * be  "Monitoring", otherwise "Not Connected".
     * @param workOrNot the Sring containing the title of the graph.
     */
    public void setTitle(String workOrNot){
        chart.setTitle(workOrNot);
        
    }
    
    /**
     * This method updates the number of channels monitored in the controller.
     * It also updates the number of plots shown in the graph.
     * @param channels the Integer array showing which channel should be monitored, and which sholudn't.
     * @return True if the update proccess was successful, False otherwise.
     */
    public boolean updateChannels_RTG(int[] channels){
        boolean res;
        int newNum = 0;
        this.channels = channels;
        
        for(int i = 0; i<channels.length; i++){
            newNum += channels[i];
        }
        
        plotNum = newNum;

        stopBackgroundUpdate();
        res = bUM.updateChannels(channels);
        startBackgroundUpdate();

        return res;
    }
    
    /**
     * This method restarts the background update of the graph.<p>
     * This is done by calling 2 methods - <br>
     * 1. to stop the background update.<br>
     * 2. to start it up.
     */
    public void restartBackgroundUpdate(){
        stopBackgroundUpdate();
        startBackgroundUpdate();
    }
    
    /**
     * This method starts up the background proccess of updating the graph.
     */
    public void startBackgroundUpdate(){
        if(bUM.isAlive()) {return;}
        bUM.reset();
        bUM.start();
        System.out.println("RealTimeGraph class: finishing startBackgroundUpdate");
    }
    
    /**
     * This method clears the datasets in the graph (clears the points shown in the graph).<p>
     * It also clears the queue that stored the data from the previous session.
     */
    public void clearSetsAndFIFO(){
        for(XYSeriesCollection dataset : datasets){
            dataset.getSeries(0).clear();
        }
        fifo.clear();
    }
    
    /**
     * This method closes the monitor session.
     * It closes the background update of the graph, as well as the server connection to the controller.
     */
    public void closeMonitor(){
        stopBackgroundUpdate();
        bUM.SUI.closeMonitorSocket();
    }
    
    /**
     * This method stops the background update of the graph.<p>
     * It simply stops the proccess and overwrites the existing class responsible for the background update with a new intance.
     * This way, it ready to restart the background update.
     */
    public void stopBackgroundUpdate(){
        bUM.tryToStop();
        try{
            bUM.join();
        }
        catch(InterruptedException iE){
            System.err.println("stopBackgroundUpdate: Problem: " + iE);
        }
        bUM = new BackgroundUpdate_Monitor(plotNum ,datasets ,SUI ,fifo ,channels);
    }
}