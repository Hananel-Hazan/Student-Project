/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RTGraph;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

/**
 *
 * @author GXA
 */
public class FetchData {
    
    static String path = "data.txt";
    static String line = null;
    static String tempLine = null;
    static Boolean isWorking = false;
    static String hostName = "169.254.1.1";
    static int portNum = 50000;
    static String userInput = null;
    static Socket echoSocket;
    
    public static BufferedReader setupEth(){
        BufferedReader in = null;
        try{
            echoSocket = new Socket(hostName, portNum);
            
            in = new BufferedReader(new InputStreamReader(echoSocket.getInputStream()));
        }
        catch(IOException ioex){
            System.err.println("-E- connection error: "+ioex);
        }

        return in;
    }
    public static String readEth(BufferedReader in){
        String line = null;
        try{
            line = in.readLine();
        }
        catch(IOException io){
        }
        return line;
    }
    
    public static Boolean stopEth(){
        try{
            echoSocket.close();
        }
        catch(IOException ioe){
            return false;
        }
        return true;
    }
    
    public static String read(){
        try{
            File in = new File(path);
            File inTemp = new File("tempFile.txt");
            BufferedReader bIn = new BufferedReader(new FileReader(in));
            BufferedWriter bInTemp = new BufferedWriter(new FileWriter(inTemp));
            
            /*
            reading one line and returning it eventually
            if EOF is reached then close the basta
            */
            if((line = bIn.readLine())==null){
                System.out.println("finished reading");
                bIn.close();
                bInTemp.close();
                inTemp.delete();
                return null;
            }
            
            /*
            reading all the lines in the data file except the first ,
            which has already been read, and writng them to a temp file,
            that will replace the current original
            */
            while((tempLine=bIn.readLine())!=null){
                bInTemp.write(tempLine+System.lineSeparator());
                //System.out.println("Wrote one line");
            }
            /*
            closing the basta after completing copying from in the inTemp
            */
            bIn.close();
            bInTemp.close();
            
            /*
            deleting the in file
            */
            
            in.setWritable(true);
           
            if (!in.delete()){
                System.out.println("Error when deleting original");
            }
            /*
            rename inTemp to the original name so it replaces the
            original data file
            */
            if (!(isWorking = inTemp.renameTo(in))){
               System.out.println("Error when renaming");
               return null; 
            }
            /*
            in the end we essentially read the first line in
            the in file (data file) and then deleted it so other
            lines can be read in the next call            
            */
            Thread.sleep(10); // trying to delay the process so it won't get stuck
            
                
        }
        catch(IOException iOE){
            iOE.printStackTrace();
        }
        catch(InterruptedException inE){
            inE.printStackTrace();
        }
        return line;
    }
}
