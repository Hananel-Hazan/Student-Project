package RTGraph;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.LinkedList;

import javax.swing.JPanel;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.DateTickUnitType;
import org.jfree.chart.axis.DateTickUnit;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CombinedDomainXYPlot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

    /****************************************************************************
     * JFREECHART DEVELOPER GUIDE                                               *
     * The JFreeChart Developer Guide, written by David Gilbert, is available   *
     * to purchase from Object Refinery Limited:                                *
     *                                                                          *
     * http://www.object-refinery.com/jfreechart/guide.html                     *
     *                                                                          *
     * Sales are used to provide funding for the JFreeChart project - please    * 
     * support us so that we can continue developing free software.             *
     ****************************************************************************/

/**
 * This class creates the graph interface for the simulation and measurements tab in the main app.<p>
 * Based on a JFreeChart demo example:<br>
 * "A demonstration application showing a time series chart where you can dynamically add<br>
 * (random) data by clicking on a button."<br>
 * @author Gil Aizenshtadt
 */
//public class RealTimeGraph_Monitor extends JPanel implements ActionListener {
public class RealTimeGraph_SimuModel extends JPanel {

    
    /** Number of subplots. */
    public static final int SUBPLOT_COUNT = 6;
    ////////////////////////////////////////////////
    /** Array describing which channel is shown (=1) and which is not (=0). */
    public int channels[] = {1,0,0,0,0,0};
    ////////////////////////////////////////////////
    /** The Collection of series containing the points shown in the graph. */
    public XYSeriesCollection[] datasets = new XYSeriesCollection[SUBPLOT_COUNT]; 
    //////////////////////////////////////////////////////////////////////////////////
    /** The series array for storing the points for each subplot in the graph. */
    XYSeries xys[] = new XYSeries[SUBPLOT_COUNT];
    //////////////////////////////////////////////////
    /** LinkedList for storing the simu/model data. */
    public LinkedList<double[]> fifo;
    ////////////////////////////////////////////
    //// The elements for building the graph ////////////////////
    /** Handles the subplots. */
    final public XYPlot[] subp = new XYPlot[SUBPLOT_COUNT];
    /** The main plot which holds all the subplots. */
    final public CombinedDomainXYPlot plot;
    /** The chart window. */
    final JFreeChart chart;
    /////////////////////////////////////////////////////////////
    /** The chart's title. */
    String chartName;
    ////////////////////////////////////////////////////////
    /** The number of subplots currently shown in the graph. */
    static int plotNum = 1;
    //////////////////////////////////////////
    //// The background interface for updating the graph ///////
    /** Handles the background update of the subplots in the chart. */
    public BackgroundUpdate_SimuModel bUSM;
    /** Handles the communication and data exchange with the server. */
    public ServerUserInterface SUI;
    ////////////////////////////////////////////////////////
    //// Boolean determining wether it is simulation or measurements ////
    /** A flag which determines whether the chart is a simulation (true) or model (false) chart. */
    boolean isSimu = true;        
    ///////////////////////////////////////////////////////////
    /** Font for the X and Y axes. */
    Font fnt = new Font("Dialog", Font.PLAIN, 16);
    /////////////////////////////////////////    
    ///////////////////////////////////////////////////////////

    
    /**
     * Constructs a the graph.
     *
     * @param title  the frame chartName.
     * @param simuOrModel the Boolean pointing wether the graph is for simulation or measurements.
     */
    public RealTimeGraph_SimuModel(final String title, boolean simuOrModel) {

        chartName = title;
        this.isSimu = simuOrModel;
        
        
        
        DateAxis timeAxis = new DateAxis("Time");
        DateFormat formatter = new SimpleDateFormat("ss");
        timeAxis.setTickUnit(new DateTickUnit(DateTickUnitType.SECOND,1,formatter));
        

        plot = new CombinedDomainXYPlot(new NumberAxis("Time"));
        
        for(int i=0; i<SUBPLOT_COUNT; i++){
            xys[i] = new XYSeries("input A"+Integer.toString(i));
            datasets[i] = new XYSeriesCollection(xys[i]);
            subp[i] = new XYPlot(datasets[i],null,new NumberAxis("y"+i), new StandardXYItemRenderer());
            subp[i].getRangeAxis().setTickLabelFont(fnt);
            subp[i].getRangeAxis().setLabelFont(fnt);
        }
        
        UpdatePlotNum.updateCont(plot, subp, plotNum, SUBPLOT_COUNT);
        chart = new JFreeChart(chartName, plot);
        
        chart.setBorderPaint(Color.black);
        chart.setBorderVisible(true);
        chart.setBackgroundPaint(Color.white);
        
        plot.setBackgroundPaint(Color.lightGray);
        plot.setDomainGridlinePaint(Color.white);
        plot.setRangeGridlinePaint(Color.white);
        plot.getDomainAxis().setTickLabelFont(fnt);
        plot.getDomainAxis().setLabelFont(fnt);
        final ValueAxis axis = plot.getDomainAxis();
        axis.setAutoRange(true);
        
        if(isSimu){
            axis.setFixedAutoRange(1000.0); // 1 millisecond = 1000 micro-seconds
            axis.setLabel("Time [us]");
        }
        else{
            axis.setFixedAutoRange(10.0); // 10 seconds
            axis.setLabel("Time [sec]");
        }
        
        final JPanel content = new JPanel(new BorderLayout());
        final ChartPanel chartPanel = new ChartPanel(chart);
        content.add(chartPanel);
        
        add(content);
        content.setVisible(true);

        fifo = new LinkedList<>();
        startBackgroundClass();
        bUSM.setDaemon(true);
    }
    
    /**
     * This method instantiates the backgroundUpdate based on wether the graph <br>
     * is in the simulation tab (and then an instance of BackgroundUpdate_Simu is created),<br>
     * or in the measurements tab (and then an instance of Backgroundpdate_Model is created).<br>
     */
    private void startBackgroundClass(){
        if(isSimu){
            bUSM = new BackgroundUpdate_Simu(plotNum,datasets,channels, fifo);
        }
        else{
            bUSM = new BackgroundUpdate_Model(plotNum,datasets,channels, fifo);
        }
    }
    

        
    /**
     * This method update the range of the x-axis in the simulation, when the time resultion has changed.
     * @param timeRes the time resolution set in the simulation.
     */
    public void updateXAxis(double timeRes){
        ValueAxis axis = plot.getDomainAxis();
        axis.setFixedAutoRange(timeRes*1000.0);
    }

    /**
     * This method is used to set the title of the graph.<br>
     * The title set is the passed string.<br>
     * @param workOrNot the Sring containing the title of the graph.
     */    
    public void setTitle(String workOrNot){
        chart.setTitle(workOrNot);
    }
    
    /**
     * This method starts up the server UI class and resets the currently stored data on the graph.<br>
     * The SUI class is responsible for the server connection (sending/recieving data) to the controller.<br>
     * @param host the IP of the controller to connect to.
     */    
    public void startServerUI(String host){
        SUI = new ServerUserInterface(host);
        bUSM.startSUIandUpdateChannels(SUI,channels);
        clearSetsAndFIFO();
    }
    
    /**
     * This method restarts the background update of the graph.<br>
     * This is done by calling 2 methods - <p>
     * 1. to stop the background update.<br>
     * 2. to start it up.<br>
     */  
    public void restartBackgroundUpdate(){
        stopBackgroundUpdate();
        startBackgroundUpdate();
    }
          
    /**
     * This method starts up the background proccess of updating the graph.
     */  
    public void startBackgroundUpdate(){
        if(bUSM.isAlive()) {return;}
        bUSM.reset();
        bUSM.start();
        System.out.println("RealTimeGraph class: finishing startBackgroundUpdate");
    }
    
    /**
     * This method clears the datasets in the graph (clears the points shown in the graph).<br>
     * It also clears the queue that stored the data from the previous session.
     */    
    public void clearSetsAndFIFO(){
        for(XYSeriesCollection dataset : datasets ){
            dataset.getSeries(0).clear();
        }
        fifo.clear();
    }

    /**
     * This method closes the simulation/measurements session.<br>
     * It closes the background update of the graph, as well as the server connection to the controller.
     */
    public void closeSM(){
        stopBackgroundUpdate();
        bUSM.SUI.closeSMSocket();
    }
    
    /**
     * This method stops the background update of the graph.<p>
     * It simply stops the proccess and overwrites the existing class responsible for the background update with a new intance.<br>
     * This way, it is ready to restart the background update.
     */    
    public void stopBackgroundUpdate(){
        bUSM.tryToStop();
        try{
            bUSM.join();
        }
        catch(InterruptedException iE){
            System.err.println("stopBackgroundUpdate" + iE);
        }
        restartBackgroundClass();
    }

    /**
     * This method re-instantiates the backgroundUpdate based on wether the graph 
     * is in the simulation tab (and then an instance of BackgroundUpdate_Simu is created),
     * or in the measurements tab (and then an instance of Backgroundpdate_Model is created).<p>
     * This method is similar to the startBackgroundClass method however, the constructors of
     * the BackgroundUpdate_Simu/Model are different then those in the latter.
     */    
    private void restartBackgroundClass(){
        if(isSimu){
            bUSM = new BackgroundUpdate_Simu(plotNum,datasets,SUI,channels, fifo);
        }
        else{
            bUSM = new BackgroundUpdate_Model(plotNum,datasets,SUI,channels, fifo);
        }
            
    }
}