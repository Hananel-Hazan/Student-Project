/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RTGraph;

import java.util.LinkedList;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

/**
 * This class handles the background process of the simulation and measurements graphs updating.<p>
 * When it is running repeatedly in the background, it reads data from the server connected to the controller,
 * parses it into an array of Double[], and adds the recieved points to the graph. <br>
 * When the number of points reaches a certain limit, in order to avoid a big delay
 * in the update, some old points are deleted from the graph.<p>
 * Each point that is read from the server is stored in a LinkedList to allow saving the data to a file when the session is over.
 * 
 *
 * @author Gil Aizenshtadt
 */
public class BackgroundUpdate_SimuModel extends Thread{
    ///// Variables for limiting number of points in graph. //////
    /** the limit of number of points stored in the graph's database (the series in the datasets). */
    final int UPRATE = 1300;
    /** the number of points to delete when the UPRATE limit is reached. */
    final int DELNUM = 100;
    /** used for converting micro-seconds to seconds in the Model session. */
    final double DIVISOR = 1000000.0;
    /** used to count the number of skipped points for each channel in the Model session. the graph skips every second point.  */
    int[] j = {0,0,0,0,0,0};
    //////////////////////////////
    ///// Variable declaration for the parseLine method //////
    /** The index of a data value in the array the data is parsed to. */
    private int parseLineDataInd = 0;
    /** The index of a space char in the line recieved from the board. */
    private int parseLineSpaceInd = 0;
    /** The starting index of a data value in the line recieved from the board. */
    private int parseLine_K_Ind = 0;
    /** The array to which the line recievd from the board is parsed to. */
    private double parseLineData[];
    //////////////////////////////////////////
    ///// ServerUserInterface declaration //////////////////
    /** handles the server communications between the PC and the board */
    public ServerUserInterface SUI;
    ///////////////////////////////////////////
    ///// Variables for the actual updating of the graph //////
    /** The overall number of subplot available. */
    final int plotNumFixed = 6;
    /** stores a parsed line data sent from the board */
    double[] updateVal;
    /** describes which channel is shown (1) and which is not (0). */
    public int[] channels;
    /** stores the datasets recieved from the RTGraph class. */
    XYSeriesCollection[] setsToUpdate ;
    /** stores the data series which shown on the plot. */
    XYSeries[] setsTS;
    //////////////////////////////////////////
    //// Boolean for stopping/runnning the background process /////
    /** used for trying to stop the background process. */
    boolean isRunning = true;
    ////////////////////////////
    //// LinkedList for storing all the data collected in the session //////
    /** stores all the data collected in the session. */
    public LinkedList<double[]> fifo;
    /////////////////////////////////////////


    
    /**
     * This constructor initiates a new instance of the class without an existing instance of the ServerUserInterface class.<br>
     * The SUI class instance will be add when a new session starts.
     * @param plNum the number of sub-plots currently shown on the graph.
     * @param dataSets the datasets holding the points which are drawn on the graph.
     * @param stck the FIFO stack passed from the graph which will store all the data collected in the session.
     * @param chans the Integer array describing which channel is shown on the graph and which isn't.
     */       
    public BackgroundUpdate_SimuModel(int plNum,XYSeriesCollection[] dataSets, int chans[], LinkedList<double[]> stck){
        
        fifo = stck;
        setsToUpdate = dataSets;
        updateVal = new double[plotNumFixed];
        setsTS = new XYSeries[dataSets.length];

        for(int i=0; i < plotNumFixed; i++){
            setsTS[i] = setsToUpdate[i].getSeries(0);
        }
        
        channels = chans;
        
    }
 
    /**
     * This constructor initiates a new instance of the class with an existing instance of the ServerUserInterface class.
     * @param plNum the number of sub-plots currently shown on the graph.
     * @param dataSets the datasets holding the points which are drawn on the graph.
     * @param sui the ServerUserInterface instance.
     * @param stck the FIFO stack passed from the graph which will store all the data collected in the session.
     * @param chans the Integer array describing which channel is shown on the graph and which isn't.
     */    
    public BackgroundUpdate_SimuModel(int plNum,XYSeriesCollection[] dataSets,ServerUserInterface sui, int chans[], LinkedList<double[]> stck){
        fifo = stck;
        setsToUpdate = dataSets;
        updateVal = new double[plotNumFixed];
        setsTS = new XYSeries[plotNumFixed];

        for(int i=0; i < plotNumFixed; i++){
            setsTS[i] = setsToUpdate[i].getSeries(0);
        }
        
        SUI = sui;
        channels = chans;
    }
   
    /**
     * This method passes to the BackgroundUpdate class the ServerUserinterface instance from the RealTimeGraph class, when a new session starts up.<br>
     * It also updates the Integer array describing which channels should be displayed and which shouldn't.
     * @param sui the ServerUserInterface instance passed to this class.
     * @param chans the Integer array describing which channels should be displayed and which shouldn't.
     */
    public void startSUIandUpdateChannels(ServerUserInterface sui, int chans[]){
        SUI = sui;
        channels = chans;
    }
    
    /**
     * This method updates the session by sending data to the controller, and thus updating the parameters/trigger values.
     * @param data the String array containing the lines to be sent to the controller.
     * @return True if the data was sent successfully, False otherwise.
     */    
    public boolean update(String[] data){
        return SUI.sendSMData(data);
    }
    
    /**
     * This method starts the simulation/measurements session.<p>
     * It calls methods which opens the server sockets and sends the data regarding the parameters/trigger values.
     * @param data the String array containing the lines to be sent to the controller.
     * @return True if the socket connection and the data sending was successful, False otherwise.
     */
    public boolean startSM(String[] data){
        boolean firstStep = SUI.openSMSocket();
        boolean secondStep = SUI.sendSMData(data);
        System.out.println("BUSM: startSM(): OpenSMS: " + firstStep + " sendSMD: " + secondStep);
        return firstStep && secondStep;
    }
    
    /**
     * This method resets the background process.
     */    
    public void reset(){
        isRunning = true;
    }
    
    /**
     * This is the main method of the class which handles the background updating of the graph. <p>
     * It performs constantly a reading from the server, parsing the data and adding the points to the graph.
     * Also, when a the number of points in the graph reaches a limit, a constant number old points is deleted, to keep the
     * delay to update the graph low.
     */    
    @Override
    public void run(){
        System.out.println("BackgroundUpdate class: entering run...");
        while(isRunning){
            updateVal = parseLine(SUI.receiveSMData());
            fifo.addFirst(updateVal);
            try{
                for (int i = 0; i < plotNumFixed; i++) {
                    if(channels[i]==1){
                        setsTS[i].add(updateVal[0], updateVal[i+1]);

                        if(setsTS[i].getItemCount() > UPRATE){
                            setsTS[i].delete(0, DELNUM);
                        }
                    }
                }
            }
            catch(NullPointerException npe){
                System.err.println("background simuModel: problem: " + npe);
            }
        }
        System.out.println("BackgroundUpdate class: finishing run...");
    }

    /**
     * This method is called from the main thread to try and finish this thread by causing the while loop to stop and ending the run() method.
     */    
    public void tryToStop(){
        isRunning = false;
    }
    
    /**
     * This method recieves the data sent from the controller and parses it to a double array.<br>
     * Each element in the array is a point which will be added to the graph to its fitting sub-plot.
     * @param line the String line recieved from the controller.
     * @return Double array containing the points to be added to the graph.
     */    
    double[] parseLine(String line){
        parseLine_K_Ind = 0;
        parseLineDataInd = 0;
        parseLineSpaceInd = 0;
        parseLineData = new double[plotNumFixed+1];
        try{
            while(parseLine_K_Ind < line.length()){
                parseLineSpaceInd = line.indexOf(" ",parseLine_K_Ind);
                parseLineData[parseLineDataInd] = Double.parseDouble(line.substring(parseLine_K_Ind, parseLineSpaceInd));
                parseLine_K_Ind = (parseLineSpaceInd+1);
                parseLineDataInd ++;
            }
        }
        catch(StringIndexOutOfBoundsException sioobe){
            System.err.println("parseLine: Problem: " + sioobe);
            System.out.println("line is: " + line + " pLSI: " + parseLineSpaceInd + " pLDI: " + parseLineDataInd + " pLKI: " + parseLine_K_Ind);
        }
        catch(NullPointerException npe){
            System.err.println("BackgroundUpdate class: Problem: " + npe);
            /*JOptionPane.showMessageDialog(null, "Connection problem!\nCheck the ethernet connection, and press \"Stop\"\n"
                                                + ",\"Return to code\" and then \"Start\" to restart.");*/
        }
        catch(NumberFormatException nfe){
            System.err.println("BackgroundUpdate class: parseLine: Problem: " + nfe);
            System.out.println("line is: " + line);
        }
        
        return parseLineData;
    }
    
}

/**
 * This class extends the BackgroundUpdate_SimuModel and simply overrides the run() method with a different one.<p>
 * The reason for separating the simulation instance from the measurements instance is the timing difference.<br>
 * The measurement is required to be as fast as the analog input measure rates, while the simulation can be slower.<br>
 * Thus, in the measurements, there can be several points in 1 millisecond which will cause an overwriting in the graph points,
 * but in the simulation, in each millisecond there is only one point, so no overwriting is done.<br>
 * This allows for using different updating methods in the graph.
 * @author Gil Aizenshtadt
 */
class BackgroundUpdate_Simu extends BackgroundUpdate_SimuModel{

    /**
     * This constructor is the same as the {@link BackgroundUpdate_SimuModel#BackgroundUpdate_SimuModel(int, org.jfree.data.xy.XYSeriesCollection[], int[], java.util.LinkedList) super} class constructor.
     */
    public BackgroundUpdate_Simu(int plNum, XYSeriesCollection[] dataSets, int[] chans, LinkedList<double[]> stck) {
        super(plNum, dataSets, chans, stck);
    }
    
    /**
     * This constructor is the same as the {@link BackgroundUpdate_SimuModel#BackgroundUpdate_SimuModel(int, org.jfree.data.xy.XYSeriesCollection[], RTGraph.ServerUserInterface, int[], java.util.LinkedList) super} class constructor.
     */
    public BackgroundUpdate_Simu(int plNum,XYSeriesCollection[] dataSets,ServerUserInterface sui, int chans[], LinkedList<double[]> stck){
        super(plNum, dataSets, sui, chans, stck);
    }
    
    /**
     * This method is the similar to the {@link BackgroundUpdate_SimuModel#run() run()} method in the super class, apart from the changes made to the timing updates.<br>
     * In this method, each millisecond only one point is added to the graph.
     */
    @Override
    public void run(){
        System.out.println("BackgroundUpdate class: entering run...");
        while(isRunning){
            updateVal = parseLine(SUI.receiveSMData());
            fifo.addFirst(updateVal);
            for (int i = 0; i < plotNumFixed; i++) {
                if(channels[i]==1){
                    try{
                        setsTS[i].add(updateVal[0], updateVal[i+1]);
                    }
                    catch(NullPointerException npe){
                        System.err.println("buS run: problem: " + npe);
                    }
                    if(setsTS[i].getItemCount() > UPRATE){
                        setsTS[i].delete(0, DELNUM);
                    }
                }
            }
        }
        System.out.println("BackgroundUpdate class: finishing run...");
    }
}

/**
 * This class extends the BackgroundUpdate_SimuModel and simply overrides the run() method with a different one.<p>
 * The reason for separating the simulation instance from the measurements instance is the timing difference.<br>
 * The measurement is required to be as fast as the analog input measure rates, while the simulation can be slower.<br>
 * Thus, in the measurements, there can be several points in 1 millisecond which will cause an overwriting in the graph points,
 * but in the simulation, in each millisecond there is only one point, so no overwriting is done.<br>
 * This allows for using different updating methods in the graph.
 * @author Gil Aizenshtadt
 */
class BackgroundUpdate_Model extends BackgroundUpdate_SimuModel{
    
    /** 
     * This constructor is the same as the {@link BackgroundUpdate_SimuModel#BackgroundUpdate_SimuModel(int, org.jfree.data.xy.XYSeriesCollection[], int[], java.util.LinkedList) super} class constructor.
     */    
    public BackgroundUpdate_Model(int plNum, XYSeriesCollection[] dataSets, int[] chans, LinkedList<double[]> stck) {
        super(plNum, dataSets, chans, stck);
    }

    /**
     * This constructor is the same as the {@link BackgroundUpdate_SimuModel#BackgroundUpdate_SimuModel(int, org.jfree.data.xy.XYSeriesCollection[], RTGraph.ServerUserInterface, int[], java.util.LinkedList)  super} class constructor.
     */
    public BackgroundUpdate_Model(int plNum,XYSeriesCollection[] dataSets,ServerUserInterface sui, int chans[], LinkedList<double[]> stck){
        super(plNum, dataSets, sui, chans, stck);
    }
    
    
    /**
     * This method is the same as the {@link BackgroundUpdate_SimuModel#run() run()} method in the super class.<br>
     * As oppsed to the Simu instance, in this method, each millisecond can have several points added to the graph.
     */    
    @Override
    public void run(){
        System.out.println("BackgroundUpdate class: entering run...");
        while(isRunning){
            updateVal = parseLine(SUI.receiveSMData());
            fifo.addFirst(updateVal);

            for (int i = 0; i < plotNumFixed; i++) {
                try{
                    if(channels[i]==1){
                        if(++j[i]>=2){
                            j[i]=0;
                            setsTS[i].addOrUpdate(updateVal[0]/DIVISOR, updateVal[i+1]);
                        }
                        if(setsTS[i].getItemCount() > (UPRATE*4)){
                            setsTS[i].delete(0, DELNUM);
                        }
                    }
                }
                catch(NullPointerException npe){
                    System.err.println("bu run: problem:" + npe + " updateVal: " + updateVal[i]);
                }    
            }
        }
        System.out.println("BackgroundUpdate class: finishing run...");
    }
}