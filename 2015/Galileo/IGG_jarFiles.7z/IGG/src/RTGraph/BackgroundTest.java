/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RTGraph;

/**
 *
 * @author GXA
 */
public class BackgroundTest extends Thread {
    int j=1;
    boolean isRunning = true;
    
    
    public void reset(){
        isRunning = true;
        
    }
    
    @Override
    public void run(){
        while (isRunning){
                System.out.println(j+" mississipi" );
                j++;
                try{
                Thread.sleep(1000);
                }
                catch(InterruptedException iE){
                    iE.printStackTrace();
                }
            }
    }
    
    
    public void tryToStop(){
        isRunning = false;
        
    }
}
