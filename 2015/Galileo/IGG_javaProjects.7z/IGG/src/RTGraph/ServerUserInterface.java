/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RTGraph;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.io.InputStreamReader;
import java.io.IOException;



/**
 * This class handles the server connection and data comunication between the main app(computer-end) and the controller(board-end). <p>
 * This class is responsible for:<br>
 * - Opening/closing sockets to the server.<br>
 * - Initializeng reading and writing streams to/from the server.<br>
 * - Sending and recieving data to/from the controller through the server.
 * 
 * 
 * @author Gil Aizenshtadt
 */
public class ServerUserInterface {
    //// Limit for the data reading from the server ///////
    /** The set limit of time taken to read data from the server. Useful if the board is not connected or a problem occured, so the app doesn't freeze.*/
    private final int TIMEOUT = 1500;
    ///////////////////////////////////
    //// The host IP //////////////////
    /** The IP address of the board. */
    private final String hostName;
    ///////////////////////////////////
    //// Boolean flags pointing to wether the Simu/Measure/Monitor connection is running ////
    /** A flag pointing to whether the Simu/Model connection is running. */
    public boolean isSMopen = false;
    /** A flag pointing to whether the Monitor connection is running. */
    public boolean isMOopen = false;
    //////////////////////////////////
    //// Sockets for the simulation/measurements and monitor sessions ///////
    /** Used for recieving the output data of the code on the board in the Simu/Model sessions. */
    private Socket dataSMSocket;
    /** Used for sending data to the board in the Simu/Model sessions. */
    private Socket outSMSocket;
    /** Used for recieving the output data of the code on the board in the Monitor session. */
    private Socket dataMonitorSocket;
    /** Used for sending data to the board in the Monitor session. */
    private Socket outMonitorSocket;
    ///////////////////////////////////////////////////////////////////////
    //// Stream readers and writers for the server comunication ///////////
    /** Used to read data from the server in the Simu/Model (SM) and Monitor sessions. */
    private BufferedReader dataSMReader,dataMonitorReader;
    /** Used to write data to the server in the Simu/Model (SM) and Monitor sessions. */
    private PrintWriter outSMWriter, outMonitorWriter;
    //////////////////////////////////////////////////////////////////////
    //// Ports to connect to in the server ///////////////////////////////
    /** Port used for simulation and model data receiving. */
    private final int dataSMPort      = 50001; 
    /** Port used for simulation and model outing to the I.G. */
    private final int outSMPort       = 50011; 
    /** Port used for monitor data receiving. */
    private final int dataMonitorPort = 50021; 
    /** Port used for monitor outing to the I.G. */
    private final int outMonitorPort  = 50031; 
    ///////////////////////////////////////////////////////////////////////
    
    /**
     * This constructor simply passes the IP address from the main app class to this class.
     * @param host the IP address of the controller.
     */
    public ServerUserInterface(String host){
        hostName = host;
    }
    
    /**
     * This method opens the simulation/measurements socket for recieving data from the controller.<br>
     * Also, a timeout is set in the case where the data hasn't been sent yet from the controller.<p>
     * Note: a different method is used for opening a socket for sending data to the controller.
     * @return True if the connection was successful, False otherwise.
     */
    public boolean openSMSocket(){
        if(!isSMopen){
            try{
                System.out.println("serverUserInterface class: entering openSMSocket. hostName is: " + hostName);
                dataSMSocket        =   new Socket(hostName,dataSMPort);
                dataSMSocket.setSoTimeout(TIMEOUT);

                isSMopen = true;
                setDataSM_R();
                
                return true;
            }
            catch(IOException ioex){
                System.err.println("openSMSocket Problem: " + ioex);
                return false;
            }
        }
        return true;
    }
    
    /**
     * This method opens the monitor socket for recieving data from the controller when monitoring.<br>
     * Also, a timeout is set in the case where the data hasn't been sent yet from the controller.<p>
     * Note: a different method is used for opening a socket for sending data to the controller.
     * @return True if the connection was successful, False otherwise.
     */
    public boolean openMonitorSocket() {
        if(!isMOopen){    
            try{
                System.out.println("serverUserInterface class: entering openMonitorSocket. hostName is: " + hostName);
                dataMonitorSocket   =   new Socket(hostName,dataMonitorPort);
                dataMonitorSocket.setSoTimeout(TIMEOUT);

                isMOopen = true;
                setDataMonitorR();

                return true;
            }
            catch(IOException ioex){
                System.err.println("openMonitorSocket Problem: " + ioex);
                return false;
            }
        }
        return true;
    }
    
    /**
     * This mathod sets the reader-stream for recieiving data from the controller through the input monitor socket.
     */
    private void setDataMonitorR(){
        try{
            dataMonitorReader   = new BufferedReader(new InputStreamReader(dataMonitorSocket.getInputStream()));
            System.out.println("serverUserInterface class: Monitor R set");
        }
        catch(IOException ioex){
            System.err.println(ioex);
        }
    }
    
    /**
     * This method sets the writer-stream for sending data to the controller through the output monitor socket.
     */
    private void setOutMonitorW(){
        try{
            outMonitorWriter    = new PrintWriter(outMonitorSocket.getOutputStream());
            System.out.println("serverUserInterface class: Monitor W set");
        }
        catch(IOException ioex){
            System.err.println(ioex);
        }
    }
    
    /**
     * This method sets both streams(writing/reading) for sending/recieving data to/from the controller in the monitor stage. <p>
     * It essentialy calls 2 methods:<br>
     * 1. setDataMonitorR - to set the data reader from the server.<br>
     * 2. setOutMonitorW - to set the data writer to the server.
     */
    private void setMonitorRW(){
        setDataMonitorR();
        setOutMonitorW();
        System.out.println("serverUserInterface class: Monitor RW set");
    }
    
    /**
     * This method sets up the socket connection for sending data to the controller in the monitoring stage.<br>
     * If the connection already exists, nothing is done.
     * @return True if the socket is open, False otherwise.
     */
    private boolean startAndSetOutMonitorSocket(){
        if(!isMOopen){    
            try{
                outMonitorSocket =   new Socket(hostName,outMonitorPort);
                setOutMonitorW();
                isMOopen = true;
                return true;
            }
            catch(IOException ioex){
                System.err.println("startAndSetOutMonitorSocket Problem: " + ioex);
                return false;
            }
        }
        return true;
    }
    
    /**
     * This method sets up the socket connection for sending data to the controller in the simulation/measurements stage.<br>
     * If the connection already exists, nothing is done.
     */
    private void startAndSetOutSMSocket(){
        if(!isSMopen){
            try{
                outSMSocket = new Socket(hostName, outSMPort);
                setOutSM_W();
                isSMopen = true;
            }
            catch(IOException ioex){
                System.err.println("startAndSetOutSMSocket Problem: " + ioex);
            }
        }
    }
    
    /**
     * This method sets the writer-stream for sending data to the controller through the output simulation/measurements socket.
     */
    private void setOutSM_W(){
        try{
            outSMWriter = new PrintWriter(outSMSocket.getOutputStream());
        }
        catch(IOException ioex){
            System.err.println("setOutSM_W Problem: " + ioex);
        }
              
    }
    
    /**
     * This mathod sets the reader-stream for recieiving data from the controller through the input simulation/measurements socket.
     */
    private void setDataSM_R(){
        try{
            dataSMReader        = new BufferedReader(new InputStreamReader(dataSMSocket.getInputStream()));
            System.out.println("ServerUserInterface class: SM R set");
        }
        catch(IOException ioex){
            System.err.println("setDataSM_R Problem: " + ioex);
        }
    }
    
    /**
     * This method sets both streams(writing/reading) for sending/recieving data to/from the controller in the simulation/measurements stage. <p>
     * It essentialy calls 2 methods:<br>
     * 1. setDataSM_R - to set the data reader from the server.<br>
     * 2. setOutSM_W - to set the data writer to the server.
     */
    private void setSM_RW(){
        setDataSM_R();
        setOutSM_W();
        System.out.println("ServerUserInterface class SM - RW set");
    }
    
    /**
     * This method returns a line read from the monitor output socket.
     * @return the String read from the server.
     */
    public String receiveMonitorData(){
        try{      
            return dataMonitorReader.readLine();
        }
        catch(IOException ioex){
            System.err.println("receiveMonitorData Problem: " + ioex);
            System.out.println("Connected? " + dataMonitorSocket.isConnected());
            return null;
        }
        
    }
    
    /**
     * This method returns a line read from the simulation/measurements output socket.
     * @return the String read from the server.
     */
    public String receiveSMData(){
        try{        
            return dataSMReader.readLine();
        }
        catch(IOException ioex){
            System.err.println("receiveSMData Problem: " + ioex);
            System.out.println("Connected? " + dataSMSocket.isConnected());
            return null;
        }
    }
    
    /**
     * This method sends data to the monitor input socket.<br>
     * In the monitor stage, the data sent sets which channels(analog inputs) the controller should monitor.<p>
     * This method first opens the input socket, then sends the data, and then closes the socket.<br>
     * Only when the socekt is closed, is the controller able the read the data from the server.
     * @param inputsToMonitor  the Integer array describing which channels should be monitored and which shouldn't.
     * @return True if the socket connection was successful, False otherwise.
     */
    public boolean sendMonitorData(int inputsToMonitor[]){
        
        boolean done = false;
        
        if(isMOopen){
            String line = "";

            for(int i = 0; i < inputsToMonitor.length; i++){
                line += Integer.toString(inputsToMonitor[i]);
                line += " ";
            }
            
            try{
                outMonitorSocket = new Socket(hostName, outMonitorPort);
                outMonitorWriter = new PrintWriter(outMonitorSocket.getOutputStream());
                
                outMonitorWriter.flush();
                outMonitorWriter.println(line);
                
                outMonitorWriter.close();
                outMonitorSocket.close();
                
                done = true;
            }
            catch(IOException ioex){
                System.err.println("sendMonitorData Problem: " + ioex);
            }
            

            System.out.println("ServerUserInterface class: monitor sent line: " + line);

            
            
            try{Thread.sleep(TIMEOUT+2000);} catch(InterruptedException iE){System.err.println("sendMonitorData: problem: " + iE);}

            return done;
        }
        return done;
    }

    /**
     * This method sends data to the simulation/measurements input socket.<br>
     * In these stages, the data sent sets the trigger fields (in the simulation only) and the parameters' values (in both).<p>
     * This method first opens the input socket, then sends the data, and then closes the socket.<br>
     * Only when the socekt is closed, is the controller able the read the data from the server.
     * @param data  the String array containing the lines to be sent to the controller.
     * @return True if the socket connection was successful, False otherwise.
     */
    public boolean sendSMData(String data[]){
        boolean done = false;
        
        if(isSMopen){
            try{
                
                outSMSocket = new Socket(hostName, outSMPort);
                outSMWriter = new PrintWriter(outSMSocket.getOutputStream());
                
                outSMWriter.flush();
                for (String ds : data) {
                    outSMWriter.println(ds);
                }
                
                outSMWriter.close();
                outSMSocket.close();
                
                done = true;
            }
            catch(IOException ioex){
                System.err.println("sendSMData: Problem: " + ioex);
            }            
            
            System.out.println("ServerUserInterface class: monitor data sent!");

            try{Thread.sleep(TIMEOUT);} catch(InterruptedException iE){System.err.println("sendMonitorData: problem: " + iE);}

            return done;
        }
        return done;
    }

    /**
     * This method closes the input connection to the controller in the monitor stage.
     */
    public void closeDataMonitorSocket(){
        if(isMOopen){
            try{
                dataMonitorReader.close();
                dataMonitorSocket.close();
                
                isMOopen = false;

            }
            catch(IOException ioex){
                System.err.println("Problem: " + ioex);
            }
        }
    }

    /**
     * This method closes the output connection to the controller in the monitor stage.
     */    
    public void closeOutMonitorSocket(){
        
        if(isMOopen){
            try{
                outMonitorWriter.close();
                outMonitorSocket.close();
                
                isMOopen = false;
            }
            catch(IOException ioex){
                System.err.println("closeOutMonitorSocket Problem: " + ioex);
            }
        }
    }
    
    /**
     * This method closes both input and output connections to the controller in the monitor stage.
     */
    public void closeMonitorSocket(){
        if(isMOopen){
            try{
                outMonitorWriter.close();
                dataMonitorReader.close();
                dataMonitorSocket.close();
                outMonitorSocket.close();
                
                isMOopen = false;
            }
            catch(IOException ioex){
                System.err.println("Problem: " + ioex);
            }
        }
    }
    
    /**
     * This method closes the output connection to the controller in the simulation/measurements stage.
     */  
    public void closeOutSMSocket(){
        if(isSMopen){
            try{
                outSMWriter.close();
                outSMSocket.close();
                
                isSMopen = false;
            }
            catch(IOException ioex){
                System.err.println("closeOutSMSocket Problem: " + ioex);
            }
        }
    }
    
    /**
     * This method closes both input and output connections to the controller in the simulation/measurements stage.
     */
    public void closeSMSocket(){
        if(isSMopen){
            try{
                outSMWriter.close();
                dataSMReader.close();
                dataSMSocket.close();
                outSMSocket.close();
                
                isSMopen = false;
            }
            catch(IOException ioex){
                System.err.println("Problem: " + ioex);
            }
        }
    }
}