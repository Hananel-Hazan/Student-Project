/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PrjGui;

import RTGraph.*;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;
import java.io.File;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ExecutionException;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

/**
 * This class is the main app class.
 * The app offers connecting to a Intel® Galileo controller and either monitor its analog inputs, 
 * or upload c++ code and running simulations on it.
 * @author Gil Aizenshtadt
 */
public class IGG extends javax.swing.JFrame {

    /**
     * Creates a new form of the IGG JFrame.
     */
    public IGG() {
        isFirstTimeTab = true;
        initComponents();
        isFirstTimeTab = false;
        
        setDutyCycVisible(true);
        initIDEuploadUI();
        initComponentsManual();
        
        createCTtextAreasS();
        createCTtextAreasM();
        createPopupWindow("Starting Up - please wait...");
        
        addTemplatesToTextAreas();
        
        JFC = new JFileChooser();
        initStoredListInterface();
        initWindowCloseListener();
        /// For future options can unhide
        hideSimuDuration();
    }
    
    /**
     * This method initiates the window listener in case it is closed, to verify with user
     * if an unsaved session/code need to be saved. 
     */
    private void initWindowCloseListener(){
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        this.addWindowListener(new WindowAdapter(){
            @Override
            public void windowClosing(WindowEvent we){
                offerToSaveChangesBeforeExit();
            }
        });
    }
    
    /**
     * This method offers to save any unsaved session/code.<br>
     * The method checks if unsaved changes were made to any code, or if any session was not saved,
     * and after verifying with the user and saving the required files, the method exits the program.
     */
    private void offerToSaveChangesBeforeExit(){
        if(isModelCodeChanged){
            if(!offerToSaveSimuModelCode(mSketchPath, mCodeArea, "meaurements")){return;}
        }
        if((mStartOrStop.getText().equals("Return to code"))&&(mUpdateOrSave.getText().equals("Save data"))){
            if(!offerToSaveSimuModelSession(modelRTG, "measurements")){return;}
        }
        if(isSimuCodeChanged){
            if(!offerToSaveSimuModelCode(sSketchPath, sCodeArea, "simulation")){return;}
        }
        if((sStartOrStop.getText().equals("Return to code"))&&(sUpdateOrSave.getText().equals("Save data"))){
            if(!offerToSaveSimuModelSession(simuRTG, "simulation")){return;}
        }
        if((monitorSaveBut.isVisible())&&(monitorSaveBut.getText().equals("Save"))){
            int save = JOptionPane.showConfirmDialog(null, "Would you like to save\nthe monitor session?");
            if(save == JOptionPane.YES_OPTION){
                saveMonitorSession(monitorRTG);
            }
            else if(save == JOptionPane.CANCEL_OPTION){
                return;
            }
        }
        System.exit(0);
    }
    
    /**
     * This method initiates the stored list interface.<br>
     * It reads the list files (or creates them if non exist) and loads the data to the stored code Maps(string,string).
     * It then loads the available options to the "Select Code" options in the simulation and measurements tabs.
     */
    private void initStoredListInterface(){
        storedSimuCodes = new TreeMap<>();
        storedModelCodes = new TreeMap<>();
        
        createOrReadListFiles(miscPath + simuStoredList, storedSimuCodes);
        createOrReadListFiles(miscPath + modelStoredList, storedModelCodes);
        
        loadListToCodeTypeChoose(sCodeTypeChoose, storedSimuCodes);
        loadListToCodeTypeChoose(mCodeTypeChoose, storedModelCodes);
    }
    
    /**
     * This method loads the stored code labels to the passed codeTypeChoose.
     * @param codeTypeChoose the JComboBox to load the labels to.
     * @param list the Map(string, string) to load from.
     */
    private void loadListToCodeTypeChoose(JComboBox codeTypeChoose, Map<String,String> list){
        codeTypeChoose.setModel(new DefaultComboBoxModel(new String[]{"select","choose from file..."}));
        list.entrySet().stream().forEach((entry) -> {
            codeTypeChoose.addItem(entry.getKey());
        });
    }
    
    /**
     * This method is responsible for reading the list files and loading their contents to the stored code Maps(string,string).<p>
     * If non of the files exist, it creates them.
     * 
     * @param filePath the path of the list file.
     * @param list the list to store the contents from the file.
     */
    private void createOrReadListFiles(String filePath, Map<String,String> list){
        File listFile = new File(filePath);
        if(!listFile.exists()){
            System.out.println("createOrReadListFile: file doesn't exist");
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(listFile))) {
                bw.write("Label\tPath" + System.lineSeparator());
            }
            catch(IOException ioex){
                System.err.println("initStoredListInterface: writing Problem: " + ioex);
            }
        }
        else{
            System.out.println("createOrReadListFile: file exists");
            try (BufferedReader br = new BufferedReader(new FileReader(listFile))) {
                String code = br.readLine();
                while((code = br.readLine()) != null){
                    String key = code.substring(0, code.indexOf("\t"));
                    String val = code.substring(code.indexOf("\t")+1);
                    System.out.println("key is: " + key + " and val is: " + val);
                    list.put(key, val);
                }
            }
            catch(IOException ioex){
                System.err.println("initStoredListInterface: reading Problem: " + ioex);
            }
        }
    }
    
    /**
     * This method hides the simulation duration option.
     * For future modifications, limited duration is supported
     * but needed the permanent from the begining of the simulation
     * and not "update-able" during the simulation
     */
    private void hideSimuDuration(){
        dur = "0";
        duration.setVisible(false);
        durationVal.setVisible(false);
        durationUnit.setVisible(false);
        infMessageDuration.setVisible(false);
    }    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tabPanel = new javax.swing.JTabbedPane();
        simulation = new javax.swing.JPanel();
        triggerPanel = new javax.swing.JPanel();
        timeRes = new javax.swing.JLabel();
        dutyCyclePercent = new javax.swing.JLabel();
        durationVal = new javax.swing.JTextField();
        ampVal = new javax.swing.JTextField();
        ampUnits = new javax.swing.JLabel();
        timeResUnit = new javax.swing.JLabel();
        durationUnit = new javax.swing.JLabel();
        dcOffset = new javax.swing.JLabel();
        dcOffsetVal = new javax.swing.JTextField();
        duration = new javax.swing.JLabel();
        timeResVal = new javax.swing.JTextField();
        period = new javax.swing.JLabel();
        dcOffsetUnit = new javax.swing.JLabel();
        amplitude = new javax.swing.JLabel();
        dutyCycle = new javax.swing.JLabel();
        dutyCycleVal = new javax.swing.JTextField();
        periodUnit = new javax.swing.JLabel();
        periodVal = new javax.swing.JTextField();
        infMessageDuration = new javax.swing.JLabel();
        triggerShape = new javax.swing.JLabel();
        triggerShapeChoose = new javax.swing.JComboBox();
        sSketchChoosePanel = new javax.swing.JPanel();
        sSketchPath = new javax.swing.JTextField();
        selectSimuLabel = new javax.swing.JLabel();
        sCodeTypeChoose = new javax.swing.JComboBox();
        simuParamCount = new javax.swing.JPanel();
        simuParCountLabel = new javax.swing.JLabel();
        simuParamNum = new javax.swing.JSpinner();
        simuParCountMaxLabel = new javax.swing.JLabel();
        paramPanelSimu = new javax.swing.JPanel();
        sButtonsPanel = new javax.swing.JPanel();
        sUpdateOrSave = new javax.swing.JButton();
        sStartOrStop = new javax.swing.JButton();
        simu_TACT_RTG_panel = new javax.swing.JPanel();
        measurments = new javax.swing.JPanel();
        modelParamCount = new javax.swing.JPanel();
        modelParCountLabel = new javax.swing.JLabel();
        modelParamNum = new javax.swing.JSpinner();
        modelParCountMaxLabel = new javax.swing.JLabel();
        paramPanelModel = new javax.swing.JPanel();
        mSketchChoosePanel = new javax.swing.JPanel();
        selectModelLabel = new javax.swing.JLabel();
        mCodeTypeChoose = new javax.swing.JComboBox();
        mSketchPath = new javax.swing.JTextField();
        mButtonsPanel = new javax.swing.JPanel();
        mUpdateOrSave = new javax.swing.JButton();
        mStartOrStop = new javax.swing.JButton();
        model_TACT_RTG_panel = new javax.swing.JPanel();
        monitor = new javax.swing.JPanel();
        numOfChannels = new javax.swing.JLabel();
        monitorRTGpanel = new javax.swing.JPanel();
        monChannel1 = new javax.swing.JCheckBox();
        monChannel2 = new javax.swing.JCheckBox();
        monChannel3 = new javax.swing.JCheckBox();
        monChannel4 = new javax.swing.JCheckBox();
        monChannel5 = new javax.swing.JCheckBox();
        monChannel6 = new javax.swing.JCheckBox();
        monitorConnect = new javax.swing.JButton();
        monitorSaveBut = new javax.swing.JButton();
        mainMenu = new javax.swing.JMenuBar();
        file = new javax.swing.JMenu();
        exitMenuItem = new javax.swing.JMenuItem();
        options = new javax.swing.JMenu();
        addCodeToListOption = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("IGG - Intel® Galileo Graphical user interface");
        setBackground(new java.awt.Color(102, 255, 51));
        setForeground(java.awt.Color.red);

        tabPanel.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                tabPanelStateChanged(evt);
            }
        });

        timeRes.setText("Time Resolution:");

        dutyCyclePercent.setText("%");

        durationVal.setText("0");

        ampVal.setText("0");

        ampUnits.setText("mV");
        ampUnits.setToolTipText("need to determine what are the units");

        timeResUnit.setText("us");

        durationUnit.setText("sec");

        dcOffset.setText("DC offset:");

        dcOffsetVal.setText("0");

        duration.setText("Duration*:");

        timeResVal.setText("0");

        period.setText("Period:");

        dcOffsetUnit.setText("mV");

        amplitude.setText("Amplitude:");

        dutyCycle.setText("Duty Cycle:");

        dutyCycleVal.setText("0");

        periodUnit.setText("us");

        periodVal.setText("0");

        infMessageDuration.setText("*Type: 'inf' or 0 for non-stop simulation");

        triggerShape.setText("Trigger Shape:");

        triggerShapeChoose.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Pulse Train", "Sine Wave", "Triangular Wave", "Ramp Wave" }));
        triggerShapeChoose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                triggerShapeChooseActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout triggerPanelLayout = new javax.swing.GroupLayout(triggerPanel);
        triggerPanel.setLayout(triggerPanelLayout);
        triggerPanelLayout.setHorizontalGroup(
            triggerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(triggerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(triggerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(triggerPanelLayout.createSequentialGroup()
                        .addComponent(triggerShape)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(triggerShapeChoose, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(triggerPanelLayout.createSequentialGroup()
                        .addGroup(triggerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(triggerPanelLayout.createSequentialGroup()
                                .addComponent(dutyCycle)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dutyCycleVal, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(triggerPanelLayout.createSequentialGroup()
                                .addComponent(amplitude)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ampVal, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(triggerPanelLayout.createSequentialGroup()
                                .addComponent(timeRes)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(timeResVal, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(triggerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(timeResUnit)
                            .addComponent(ampUnits)
                            .addComponent(dutyCyclePercent))
                        .addGap(15, 15, 15)
                        .addGroup(triggerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dcOffset, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(period, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(duration, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(triggerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(durationVal)
                            .addComponent(periodVal)
                            .addComponent(dcOffsetVal, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(triggerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dcOffsetUnit)
                            .addComponent(durationUnit)
                            .addComponent(periodUnit)))
                    .addGroup(triggerPanelLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(infMessageDuration)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        triggerPanelLayout.setVerticalGroup(
            triggerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(triggerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(triggerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(triggerShapeChoose, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(triggerShape))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(triggerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(amplitude)
                    .addComponent(ampVal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(period)
                    .addComponent(periodVal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ampUnits)
                    .addComponent(periodUnit))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(triggerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dcOffsetVal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dcOffset)
                    .addComponent(dcOffsetUnit)
                    .addComponent(timeResVal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(timeRes)
                    .addComponent(timeResUnit))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(triggerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(durationVal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(duration)
                    .addComponent(durationUnit)
                    .addComponent(dutyCycle)
                    .addComponent(dutyCycleVal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dutyCyclePercent))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(infMessageDuration, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        sSketchPath.setEditable(false);
        sSketchPath.setText("File Path...");

        selectSimuLabel.setText("Select Code: ");

        sCodeTypeChoose.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "select", "Choose from file...", "Membrane Model" }));
        sCodeTypeChoose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sCodeTypeChooseActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout sSketchChoosePanelLayout = new javax.swing.GroupLayout(sSketchChoosePanel);
        sSketchChoosePanel.setLayout(sSketchChoosePanelLayout);
        sSketchChoosePanelLayout.setHorizontalGroup(
            sSketchChoosePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sSketchChoosePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(sSketchChoosePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(sSketchChoosePanelLayout.createSequentialGroup()
                        .addComponent(selectSimuLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(sCodeTypeChoose, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(sSketchPath, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        sSketchChoosePanelLayout.setVerticalGroup(
            sSketchChoosePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sSketchChoosePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(sSketchChoosePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(selectSimuLabel)
                    .addComponent(sCodeTypeChoose, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sSketchPath, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        simuParCountLabel.setText("Number of parameters:");

        simuParamNum.setModel(new javax.swing.SpinnerNumberModel(1, 0, 10, 1));
        simuParamNum.setMaximumSize(new java.awt.Dimension(10, 10));
        simuParamNum.setMinimumSize(new java.awt.Dimension(0, 0));
        simuParamNum.setName(""); // NOI18N
        simuParamNum.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                simuParamNumStateChanged(evt);
            }
        });

        simuParCountMaxLabel.setText("Max. 10");

        javax.swing.GroupLayout paramPanelSimuLayout = new javax.swing.GroupLayout(paramPanelSimu);
        paramPanelSimu.setLayout(paramPanelSimuLayout);
        paramPanelSimuLayout.setHorizontalGroup(
            paramPanelSimuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 226, Short.MAX_VALUE)
        );
        paramPanelSimuLayout.setVerticalGroup(
            paramPanelSimuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 42, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout simuParamCountLayout = new javax.swing.GroupLayout(simuParamCount);
        simuParamCount.setLayout(simuParamCountLayout);
        simuParamCountLayout.setHorizontalGroup(
            simuParamCountLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(simuParamCountLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(simuParCountLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(simuParamNum, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(simuParCountMaxLabel)
                .addContainerGap())
            .addComponent(paramPanelSimu, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        simuParamCountLayout.setVerticalGroup(
            simuParamCountLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(simuParamCountLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(simuParamCountLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(simuParCountLabel)
                    .addComponent(simuParamNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(simuParCountMaxLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(paramPanelSimu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        sUpdateOrSave.setText("Update");
        sUpdateOrSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sUpdateOrSaveActionPerformed(evt);
            }
        });

        sStartOrStop.setText("Start");
        sStartOrStop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sStartOrStopActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout sButtonsPanelLayout = new javax.swing.GroupLayout(sButtonsPanel);
        sButtonsPanel.setLayout(sButtonsPanelLayout);
        sButtonsPanelLayout.setHorizontalGroup(
            sButtonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sButtonsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(sStartOrStop)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sUpdateOrSave)
                .addContainerGap(116, Short.MAX_VALUE))
        );
        sButtonsPanelLayout.setVerticalGroup(
            sButtonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sButtonsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(sButtonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sUpdateOrSave)
                    .addComponent(sStartOrStop))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout simu_TACT_RTG_panelLayout = new javax.swing.GroupLayout(simu_TACT_RTG_panel);
        simu_TACT_RTG_panel.setLayout(simu_TACT_RTG_panelLayout);
        simu_TACT_RTG_panelLayout.setHorizontalGroup(
            simu_TACT_RTG_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 673, Short.MAX_VALUE)
        );
        simu_TACT_RTG_panelLayout.setVerticalGroup(
            simu_TACT_RTG_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout simulationLayout = new javax.swing.GroupLayout(simulation);
        simulation.setLayout(simulationLayout);
        simulationLayout.setHorizontalGroup(
            simulationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(simulationLayout.createSequentialGroup()
                .addGroup(simulationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(sSketchChoosePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sButtonsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(simuParamCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(simulationLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(triggerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(simu_TACT_RTG_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        simulationLayout.setVerticalGroup(
            simulationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(simulationLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(triggerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sSketchChoosePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(simuParamCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 135, Short.MAX_VALUE)
                .addComponent(sButtonsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(simu_TACT_RTG_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        tabPanel.addTab("Simulation", simulation);

        measurments.setMaximumSize(new java.awt.Dimension(10, 10));

        modelParCountLabel.setText("Number of parameters:");

        modelParamNum.setModel(new javax.swing.SpinnerNumberModel(1, 0, 10, 1));
        modelParamNum.setMaximumSize(new java.awt.Dimension(10, 10));
        modelParamNum.setMinimumSize(new java.awt.Dimension(0, 0));
        modelParamNum.setName(""); // NOI18N
        modelParamNum.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                modelParamNumStateChanged(evt);
            }
        });

        modelParCountMaxLabel.setText("Max. 10");

        javax.swing.GroupLayout paramPanelModelLayout = new javax.swing.GroupLayout(paramPanelModel);
        paramPanelModel.setLayout(paramPanelModelLayout);
        paramPanelModelLayout.setHorizontalGroup(
            paramPanelModelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 278, Short.MAX_VALUE)
        );
        paramPanelModelLayout.setVerticalGroup(
            paramPanelModelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 306, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout modelParamCountLayout = new javax.swing.GroupLayout(modelParamCount);
        modelParamCount.setLayout(modelParamCountLayout);
        modelParamCountLayout.setHorizontalGroup(
            modelParamCountLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modelParamCountLayout.createSequentialGroup()
                .addGroup(modelParamCountLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(modelParamCountLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(modelParCountLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(modelParamNum, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(modelParCountMaxLabel))
                    .addComponent(paramPanelModel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        modelParamCountLayout.setVerticalGroup(
            modelParamCountLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modelParamCountLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(modelParamCountLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(modelParCountLabel)
                    .addComponent(modelParamNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(modelParCountMaxLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(paramPanelModel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        selectModelLabel.setText("Select Code: ");

        mCodeTypeChoose.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "select", "Choose from file ...", "Membrane Model" }));
        mCodeTypeChoose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mCodeTypeChooseActionPerformed(evt);
            }
        });

        mSketchPath.setEditable(false);
        mSketchPath.setText("File Path...");

        javax.swing.GroupLayout mSketchChoosePanelLayout = new javax.swing.GroupLayout(mSketchChoosePanel);
        mSketchChoosePanel.setLayout(mSketchChoosePanelLayout);
        mSketchChoosePanelLayout.setHorizontalGroup(
            mSketchChoosePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mSketchChoosePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(mSketchChoosePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(mSketchChoosePanelLayout.createSequentialGroup()
                        .addComponent(selectModelLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(mCodeTypeChoose, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(mSketchPath, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(53, Short.MAX_VALUE))
        );
        mSketchChoosePanelLayout.setVerticalGroup(
            mSketchChoosePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mSketchChoosePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(mSketchChoosePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(selectModelLabel)
                    .addComponent(mCodeTypeChoose, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(mSketchPath, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        mUpdateOrSave.setText("Update Parameters");
        mUpdateOrSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mUpdateOrSaveActionPerformed(evt);
            }
        });

        mStartOrStop.setText("Start");
        mStartOrStop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mStartOrStopActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout mButtonsPanelLayout = new javax.swing.GroupLayout(mButtonsPanel);
        mButtonsPanel.setLayout(mButtonsPanelLayout);
        mButtonsPanelLayout.setHorizontalGroup(
            mButtonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mButtonsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(mStartOrStop)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(mUpdateOrSave)
                .addContainerGap(38, Short.MAX_VALUE))
        );
        mButtonsPanelLayout.setVerticalGroup(
            mButtonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mButtonsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(mButtonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(mUpdateOrSave)
                    .addComponent(mStartOrStop))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout model_TACT_RTG_panelLayout = new javax.swing.GroupLayout(model_TACT_RTG_panel);
        model_TACT_RTG_panel.setLayout(model_TACT_RTG_panelLayout);
        model_TACT_RTG_panelLayout.setHorizontalGroup(
            model_TACT_RTG_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 711, Short.MAX_VALUE)
        );
        model_TACT_RTG_panelLayout.setVerticalGroup(
            model_TACT_RTG_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout measurmentsLayout = new javax.swing.GroupLayout(measurments);
        measurments.setLayout(measurmentsLayout);
        measurmentsLayout.setHorizontalGroup(
            measurmentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(measurmentsLayout.createSequentialGroup()
                .addGroup(measurmentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(measurmentsLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(mButtonsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(modelParamCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mSketchChoosePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(model_TACT_RTG_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        measurmentsLayout.setVerticalGroup(
            measurmentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(measurmentsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(mSketchChoosePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(modelParamCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(mButtonsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addComponent(model_TACT_RTG_panel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        tabPanel.addTab("Measurements", measurments);

        numOfChannels.setText("Channels to display:");

        javax.swing.GroupLayout monitorRTGpanelLayout = new javax.swing.GroupLayout(monitorRTGpanel);
        monitorRTGpanel.setLayout(monitorRTGpanelLayout);
        monitorRTGpanelLayout.setHorizontalGroup(
            monitorRTGpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        monitorRTGpanelLayout.setVerticalGroup(
            monitorRTGpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 461, Short.MAX_VALUE)
        );

        monChannel1.setText("1");
        monChannel1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monChannel1ActionPerformed(evt);
            }
        });

        monChannel2.setText("2");
        monChannel2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monChannel2ActionPerformed(evt);
            }
        });

        monChannel3.setText("3");
        monChannel3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monChannel3ActionPerformed(evt);
            }
        });

        monChannel4.setText("4");
        monChannel4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monChannel4ActionPerformed(evt);
            }
        });

        monChannel5.setText("5");
        monChannel5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monChannel5ActionPerformed(evt);
            }
        });

        monChannel6.setText("6");
        monChannel6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monChannel6ActionPerformed(evt);
            }
        });

        monitorConnect.setText("Connect");
        monitorConnect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monitorConnectActionPerformed(evt);
            }
        });

        monitorSaveBut.setText("Save");
        monitorSaveBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monitorSaveButActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout monitorLayout = new javax.swing.GroupLayout(monitor);
        monitor.setLayout(monitorLayout);
        monitorLayout.setHorizontalGroup(
            monitorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(monitorLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(monitorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(monitorRTGpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(monitorLayout.createSequentialGroup()
                        .addComponent(numOfChannels)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(monChannel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(monChannel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(monChannel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(monChannel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(monChannel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(monChannel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 560, Short.MAX_VALUE)
                        .addComponent(monitorSaveBut)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(monitorConnect)))
                .addContainerGap())
        );
        monitorLayout.setVerticalGroup(
            monitorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(monitorLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(monitorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(numOfChannels)
                    .addComponent(monChannel1)
                    .addComponent(monChannel2)
                    .addComponent(monChannel3)
                    .addComponent(monChannel4)
                    .addComponent(monChannel5)
                    .addComponent(monChannel6)
                    .addComponent(monitorConnect)
                    .addComponent(monitorSaveBut))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(monitorRTGpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabPanel.addTab("Monitor", monitor);

        file.setText("File");

        exitMenuItem.setText("Exit");
        exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitMenuItemActionPerformed(evt);
            }
        });
        file.add(exitMenuItem);

        mainMenu.add(file);

        options.setText("Options");

        addCodeToListOption.setText("Add new code to stored codes... ");
        addCodeToListOption.setToolTipText("adds a new code file to the options in the \"Select Code\" ");
        addCodeToListOption.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addCodeToListOptionActionPerformed(evt);
            }
        });
        options.add(addCodeToListOption);

        mainMenu.add(options);

        setJMenuBar(mainMenu);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabPanel)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabPanel, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    /**
     * This method initializes the code and template text areas for the simulation tab.
     * It also adds a document listener for the code text area to allow making changes to the code
     * and offer saving them. The template text area is uneditable.
     * A JTextPane and a JTextArea are created (one for template and another for code), inside a JScrollPane.
     * Both text panes are add to a JSplitPane, which allows modifing the showing area for each text.
     */
    private void createCTtextAreasS(){
        
        sSelCodeLabel = new JLabel("Selected Code: ");
        simuTempLabel = new JLabel("Template code for simulation:");
        
        sTempTextPane = new JTextPane();
        sTempTextPane.setAutoscrolls(true);
        sCodeNameLabel = new JLabel("\"\"");
        sCodeNameLabel.setFont(new Font("Tahoma",Font.BOLD,12));

        sCodeArea = new JTextArea();
        sCodeArea.setText(codeTextRec);
        sCodeArea.getDocument().addDocumentListener(new DocumentListener(){
            @Override
            public void changedUpdate(DocumentEvent e){
               
            }

            @Override
            public void insertUpdate(DocumentEvent e) {
                if(!isSimuCodeChanged) {isSimuCodeChanged = true;}
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                if(!isSimuCodeChanged) {isSimuCodeChanged = true;}
            }
        });
        sCodeArea.setTabSize(2);
        
        sCodeAreaScrollPane = new JScrollPane(sCodeArea);
        sTempTextAreaScrollPane = new JScrollPane(sTempTextPane);
        sTempTextPane.setFont(new Font("Tahoma", 0, 10));
        sTempTextPane.setEditable(false);
        

        
        sCodeLabelPanel = new JPanel();
        sCodeLabelPanel.setLayout(new BoxLayout(sCodeLabelPanel, BoxLayout.X_AXIS));
        sCodeLabelPanel.add(sSelCodeLabel);
        sCodeLabelPanel.add(sCodeNameLabel);
        
        sCodePanel = new JPanel();
        sCodePanel.setLayout(new BoxLayout(sCodePanel, BoxLayout.Y_AXIS));
        sCodePanel.add(sCodeLabelPanel);
        sCodePanel.add(sCodeAreaScrollPane);
        
        
        sTemplatePanel = new JPanel();
        sTemplatePanel.setLayout(new BoxLayout(sTemplatePanel, BoxLayout.Y_AXIS));
        sTemplatePanel.add(simuTempLabel);
        sTemplatePanel.add(sTempTextAreaScrollPane);
        
        simuSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,sCodePanel,sTemplatePanel);
        
        sTextAreaCT_panel.setLayout(new BoxLayout(sTextAreaCT_panel, BoxLayout.X_AXIS));
        sTextAreaCT_panel.add(simuSplitPane);
        simuSplitPane.setDividerLocation(450);
        
        sTextAreaCT_panel.validate();
        
    }
    
    /**
     * This method initializes the code and template text areas for the measurements tab.
     * It also adds a document listener for the code text area to allow making changes to the code
     * and offer saving them. The template text area is uneditable.
     * A JTextPane and a JTextArea are created (one for template and another for code), inside a JScrollPane.
     * Both text panes are add to a JSplitPane, which allows modifing the showing area for each text.
     */
    private void createCTtextAreasM(){
        mSelCodeLabel = new JLabel("Selected Code: ");
        modelTempLabel = new JLabel("Template code for measurements:");
        
        mTempTextPane = new JTextPane();
        mTempTextPane.setAutoscrolls(true);
        mCodeNameLabel = new JLabel("\"\"");
        mCodeNameLabel.setFont(new Font("Tahoma",Font.BOLD,12));

        mCodeArea = new JTextArea();
        mCodeArea.setText(codeTextRec);
        
        mCodeArea.getDocument().addDocumentListener(new DocumentListener(){
            @Override
            public void changedUpdate(DocumentEvent e){

            }

            @Override
            public void insertUpdate(DocumentEvent e) {
                if(!isModelCodeChanged){ isModelCodeChanged = true;}
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                if(!isModelCodeChanged){ isModelCodeChanged = true;}
            }
        });
        mCodeArea.setTabSize(2);
        
        mTempTextAreaScrollPane = new JScrollPane(mTempTextPane);
        mTempTextPane.setFont(new Font("Tahoma", 0, 10));
        mTempTextPane.setEditable(false);
        
        mCodeAreaScrollPane = new JScrollPane(mCodeArea);
        
        mCodeLabelPanel = new JPanel();
        mCodeLabelPanel.setLayout(new BoxLayout(mCodeLabelPanel, BoxLayout.X_AXIS));
        mCodeLabelPanel.add(mSelCodeLabel);
        mCodeLabelPanel.add(mCodeNameLabel);
        
        mCodePanel = new JPanel();
        mCodePanel.setLayout(new BoxLayout(mCodePanel, BoxLayout.Y_AXIS));
        mCodePanel.add(mCodeLabelPanel);
        mCodePanel.add(mCodeAreaScrollPane);
        
        mTemplatePanel = new JPanel();
        mTemplatePanel.setLayout(new BoxLayout(mTemplatePanel, BoxLayout.Y_AXIS));
        mTemplatePanel.add(modelTempLabel);
        mTemplatePanel.add(mTempTextAreaScrollPane);
        
        modelSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,mCodePanel,mTemplatePanel);
        
        mTextAreaCT_panel.setLayout(new BoxLayout(mTextAreaCT_panel, BoxLayout.X_AXIS));
        mTextAreaCT_panel.add(modelSplitPane);
        
        modelSplitPane.setDividerLocation(450);
        
        mTextAreaCT_panel.validate();
    }
    
    /**
     * This method creates the pop-up window which is used when the app uploades a sketch, or connects to monitor the analog inputs of
     * the controller.
     * @param popupTitle the string which appear in the window. for example: "Uploading sketch - please wait..."
     */
    private void createPopupWindow(String popupTitle){
        loading = new JDialog();
        loadingPanel = new JPanel(new BorderLayout());
        pwLabel = new JLabel(popupTitle);
        
        loadingPanel.add(pwLabel, BorderLayout.CENTER);
        loading.setUndecorated(true);
        loading.getContentPane().add(loadingPanel);
        loading.pack();
        loading.setSize(loading.getWidth(),loading.getHeight()+20);
        loading.setLocationRelativeTo(this);
        loading.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        loading.setModal(true);
        
    }
    
    
    /**
     * This method adds the template codes to the simulation and measurements tabs, in the text panes created for them.
     * It creates a file reader and then reads each of the template files to the proper text pane.
     * In addition, the method paints the areas marked with /*******...*******./ with colors for convenience.
     */
    private void addTemplatesToTextAreas(){
        
        try{
            
            simuTempReader  = new FileReader(new File(miscPath + simuTemplatePath));
            modelTempReader = new FileReader(new File(miscPath + modelTemplatePath));
            
            sTempTextPane.read(simuTempReader, "Template for simulation");
            mTempTextPane.read(modelTempReader, "Template for model");
            
            simuTempReader.close();
            modelTempReader.close();
            
            paintSections(sTempTextPane);
            paintSections(mTempTextPane);
        }
        catch(IOException ioex){
            System.err.println("AddTemplatesToTextAreas Problem: " + ioex);
        }
            
    }
    
    /**
     * This method recieves a text pane and paints the sections boredered with /***** for convenience.
     * These sections are where the add code should be written.
     * The #include section and Var. declaration section are painted blue, while the setup code section (which is performed only once)
     * and the loop/main section (which is performed in an infinite for-loop) are painted red.
     * @param tPane the text pane to color (maybe a code trext area or template text area.
     */
    private void paintSections(JTextPane tPane){
        tPane.setForeground(Color.black);
        StyledDocument doc;
        SimpleAttributeSet attr;
        String text = tPane.getText().replace("\r\n", "\n");
        tPane.setText(text);
        String sections[] = {"/************** #includes Section *******************/", 
                             "/************** Variable Declaration Section *******************/",
                             "/************** Setup Code Section *******************/",
                             "/************** Main Code Section *******************/"};
        
        int sectPos[] = {0,0};
        Color sectionColors[] = {Color.BLUE, Color.BLUE, Color.RED, Color.RED};
        
        Color black = Color.BLACK;
        attr = new SimpleAttributeSet();
        StyleConstants.setForeground(attr, black);
        tPane.getStyledDocument().setCharacterAttributes(0,tPane.getStyledDocument().getLength(),attr, true);
        
        for(int j=0; j < sections.length; j++){
            sectPos[0] = text.indexOf(sections[j]);
            sectPos[1] = text.lastIndexOf(sections[j]);
            
            attr = new SimpleAttributeSet();
            StyleConstants.setForeground(attr, sectionColors[j]);
            doc = tPane.getStyledDocument();
            doc.setCharacterAttributes(sectPos[0], sectPos[1] + sections[j].length() - sectPos[0], attr, true);
        }
        tPane.setCaretPosition(0);
    }

    /**
     * This method sets a panel to contain, in the same space, the graph and the text areas (code and template) in the simulation and measurements tabs.
     * The layout of the panel is a CardLayout which allows the graph and the text area to be placed in the same space in the app window.
     * In the begining the graph is hidden and the text areas are visible for add/editing code.
     * When the user has finished add/editing the code, and it has been successfully compiled and uploaded to the controller,
     * The text areas are switched with the graph, and graph becomes visible, and the simulation/measurements begin.
     * @param parent the main panel which will contain the graph and the text areas in the same space.
     * @param tactP the sub-panel which will contain the text areas.
     * @param rtgP the sub-panel which will contain the graph.
     * @param rtg the graph itself.
     * @param chanP the panel which contains the cannel check boxes.
     * @param chanDispL the label with the text "channels to display: ".
     * @param channel the check boxes which represent the channels shown.
     */
    private void create_RTG_TACT_layout(JPanel parent, JPanel tactP, JPanel rtgP, RealTimeGraph_SimuModel rtg, JPanel chanP, JLabel chanDispL, JCheckBox channel[]){
        parent.setLayout(new CardLayout());
        parent.add(tactP, TACT);
        parent.add(rtgP, RTG);
        rtgP.setLayout(new BoxLayout(rtgP, BoxLayout.Y_AXIS));
        rtgP.add(chanP);
        rtgP.add(rtg);
        rtg.setVisible(true);
        chanP.setLayout(new BoxLayout(chanP, BoxLayout.X_AXIS));
        chanDispL = new JLabel(chanDisp);
        chanP.add(chanDispL);
        
        for(int i=0; i < channel.length; i++){
            channel[i] = new JCheckBox(Integer.toString(i+1));
            chanP.add(new JLabel("  "));
            chanP.add(channel[i]);
            
            channel[i].addActionListener(new checkBoxListener(i,rtg,channel));
            
            if(i != 0) {channel[i].setSelected(false);}
        }
        channel[0].setSelected(true);
        parent.validate();
        
    }
    
    /**
     * This method initializes components which are manually added to the main app (as oposed to the initComponents() method which automatically
     * initializes components added using the NetBeans swing builder environment.<br>
     * The compnonents initialized in this method are:<p>
     * - The graphe panels of the monitor, simulation and measurement tabs<br>
     * - The parameters' panels of the simulation and measurement tabs<br>
     * - The tip text shown in the code text areas in the Simu. and Meas. tabs.<br>
     */
    private void initComponentsManual(){
        
        /// Setting defined minimum size ///
        this.setMinimumSize(this.getSize());
        
        /// Creating graph interface for monitor tab ///
        monitorSaveBut.setVisible(false);
        monitorRTG = new RealTimeGraph_Monitor("Monitor");
        monitorRTGpanel.setLayout(new BoxLayout(monitorRTGpanel, BoxLayout.X_AXIS));
        monitorRTGpanel.add(monitorRTG);
        monitorRTG.setVisible(true);
        //graphMonitorPanel.setSize();
        monitorRTGpanel.setVisible(true);
        monChannel1.setSelected(true);
        monitorConnect.setSelected(true);
        monitorRTGpanel.validate();
        
        /// Creating text areas and graph interface for simulation and measurement tabs ///
        codeTextRec = "This text editor is provided to show the selected code\n   and allow making small modifications to it.\n\n"
                + "It is recommended that you use an external editor to create the code\n   and either paste it to this text editor, "
                + "or choose it's file \n   in the \"Choose file\" option from the \"select code\" options.\n\n"
                + "In Order to make your code work properly with the controller, you should copy\n   the template code shown to the left and add it your code\n   in the spicified areas.";
        
        
        isSimuCodeChanged = false;
        isModelCodeChanged = false;
        
        mUpdateOrSave.setVisible(false);
        sUpdateOrSave.setVisible(false);
        
        final boolean simu = true;
        final boolean model = !simu;
        
        simuRTG = new RealTimeGraph_SimuModel("Simulation",simu);
        simuRTGpanel = new JPanel();
        sTextAreaCT_panel = new JPanel();
        sChanPanel = new JPanel();
        sChannel = new JCheckBox[6];

        create_RTG_TACT_layout(simu_TACT_RTG_panel, sTextAreaCT_panel, simuRTGpanel, simuRTG, sChanPanel, sChanDispLabel, sChannel);
        
        modelRTG = new RealTimeGraph_SimuModel("Model Measurements",model);
        modelRTGpanel = new JPanel();
        mTextAreaCT_panel = new JPanel();
        mChanPanel = new JPanel();
        mChannel = new JCheckBox[6];
        
        create_RTG_TACT_layout(model_TACT_RTG_panel, mTextAreaCT_panel, modelRTGpanel, modelRTG, mChanPanel, mChanDispLabel, mChannel);
        
        paramPanelModel.setLayout(new BoxLayout(paramPanelModel, BoxLayout.Y_AXIS));
        modelParam = new JTextField[10];
        modelParamN = new JTextField[10];
        modelParamL = new JLabel[10];
        modelParPanel = new JPanel[10];
        
        paramPanelSimu.setLayout(new BoxLayout(paramPanelSimu, BoxLayout.Y_AXIS));
        simuParam = new JTextField[10];
        simuParamN = new JTextField[10];
        simuParamL = new JLabel[10];
        simuParPanel = new JPanel[10];
        
        for (int i = 0; i<10; i++){
           /// Model parameters instantiation /// 
           modelParam[i] = new JTextField("0");
           modelParam[i].setColumns(7);
           modelParamL[i] = new JLabel("Param " + (i+1) + ":");
           modelParamN[i] = new JTextField("");
           modelParamN[i].setColumns(6);
           modelParPanel[i] = new JPanel();
           modelParPanel[i].setLayout(new BoxLayout(modelParPanel[i], BoxLayout.X_AXIS));
           
           modelParPanel[i].add(modelParamL[i]);
           modelParPanel[i].add(modelParam[i]);
           modelParPanel[i].add(modelParamN[i]);
           
           paramPanelModel.add(modelParPanel[i]);
           modelParPanel[i].setVisible(false);
           /// Model parameters instantiation ///
           
           /// Simu. parameters instantiation /// 
           simuParam[i] = new JTextField("0");
           simuParam[i].setColumns(7);
           simuParamL[i] = new JLabel("Param " + (i+1) + ":");
           simuParamN[i] = new JTextField("");
           simuParamN[i].setColumns(6);
           simuParPanel[i] = new JPanel();
           simuParPanel[i].setLayout(new BoxLayout(simuParPanel[i], BoxLayout.X_AXIS));
           
           simuParPanel[i].add(simuParamL[i]);
           simuParPanel[i].add(simuParam[i]);
           simuParPanel[i].add(simuParamN[i]);
           
           paramPanelSimu.add(simuParPanel[i]);
           simuParPanel[i].setVisible(false);
           /// Simu. parameters instantiation ///
       }
       
       paramPanelSimu.validate();
       paramPanelModel.validate();
       
       modelParamN[0].setText("//\\\\name//\\\\");
       modelParPanel[0].setVisible(true);
       
       simuParamN[0].setText("//\\\\name//\\\\");
       simuParPanel[0].setVisible(true);
    }
    
    /**
     * This method initializes the interface of the the code(a.k.a sketches) uploading.
     * It reads the prefSettings.txt file for the information needed to set the preferences of the arduino IDE, 
     * through which it uploads the sketches. The pref. are then set using a command sent to the cmd prompt.
     * 
     */
    private void initIDEuploadUI(){
        
        String line;
        /**
         * This section reads the prefSettings.txt file and extracts the following fields.
         * - The IDE path on the user's computer.
         * - The com port number where the controller is connected.
         * - The board type - can be Intel® Galileo or Intel® Galileo Gen2.
         * - The host ip address of the controller.
         */
        try{
            File setFile = new File(settingsPath);
            try (BufferedReader sFBR = new BufferedReader(new FileReader(setFile))) {
                while((line = sFBR.readLine()) != null){
                    String option = line.substring(0, line.indexOf("="));
                    String value = line.substring(line.indexOf("=")+1);
                    switch (option.trim()) {
                        case "ARDUINO_PATH":
                            idePath = value.trim();
                            break;
                        case "COM_PORT":
                            comPort = value.trim();
                            break;
                        case "BOARD":
                            board = value.trim();
                            break;
                        case "HOST":
                            hostName = value.trim();
                            break;
                        default: break;
                    }
                }
            }
        }
        catch(IOException ioe){
            System.out.println("Problem finding or opening settings file:");
            System.err.println(ioe);
        }
        
        /**
         * This section sets the preferences of the arduino IDE in order to properly compule and upload sketches to the controller.
         * This is done by sending a command to the cmd prompt.
         */
        try{
            String prefCmd = idePath + "\\arduino_debug.exe --board " + board + " --port " + comPort + " --save-prefs"; 
            System.out.println(prefCmd);
            Process cmdP = Runtime.getRuntime().exec(prefCmd);
            cmdP.waitFor();
            
            BufferedReader cmdBR = new BufferedReader(new InputStreamReader(cmdP.getInputStream())); 
            String cmdOutput;
            while((cmdOutput = cmdBR.readLine())!=null) { 
                System.out.println(cmdOutput); 
            } 
        }
        catch(IOException | InterruptedException ioe){
            System.err.println("initIDEuploadUI: problem: " + ioe);
        }

    }
    
    /**
     * This method uploads a sketch(specified by the passed path string) to the controller and turns it on.
     * It first uploads the sketch and checks for errors in the process.
     * Then, it kills the current sketch prc. running and afterwards kills the clloader prc.
     * When the clloader prc. is killed, its parent prc. restarts it, which in turn restarts the sketch prc. that now uses the newly updated file.
     * The sketch upload is done through the USB connection, by calling a batch script 
     * The process killing is done using the pLink external tool through the ethernet connection.
     * If errors occur during the uploading/compiling, an error log will appear and show the errors.
     * @param skPath the path of the sketch file to be uploaded.
     * @return true if the sketch was complied and uploaded successfully, false otherwise.
     * 
     * Note: the directory where the sketch file is found, must contain only the sketch file itself, and no other sketch or unrelated cpp, 
     * as the compiler will try to link all the present source code files found in the dir.
     */
    private boolean uploadSketch(String skPath){
        File skFile = new File(skPath);
        try{
            skPath = skFile.getCanonicalPath();
        }
        catch(IOException ioex){
            System.err.println("uploadSketch: problem: " + ioex);
        }
        if(skPath.contains(" ")){
            popUpErrorMessage("File path cannot contain spaces in the directory/file names!\n"
                    + "Please move the file to a space-free path");
            return false;
        }
        
        String killSkchCMD = "killall -KILL sketch.elf ; ";
        String killCLLCMD = "killall -KILL clloader";
        
        try{
            String prefCmd = idePath + "\\arduino_debug.exe --upload " + skPath;
            System.out.println(miscPath + uploadBatch + " \"" + prefCmd + "\""  + " \"" + miscPath + uploadLog + "\"");
            Process uploadCMD = Runtime.getRuntime().exec(miscPath + uploadBatch + " \"" + prefCmd + "\"" + " \"" + miscPath + uploadLog + "\"" );
            uploadCMD.waitFor();
            
            boolean exitVal = checkForErrorsUploading();
            if(!exitVal){
                Process errorCMD = Runtime.getRuntime().exec("cmd.exe /c start /wait " + miscPath + exitQuest + " \"" + miscPath + uploadLog + "\"");
                errorCMD.waitFor();
                return false;
            }
            
            
            Process restartCMD = Runtime.getRuntime().exec("cmd.exe /c echo y | " + miscPath + plinkExe + " root@" + hostName + " " + killSkchCMD + killCLLCMD);
            restartCMD.waitFor();

            System.out.println("Sketch uploaded!");
        }
        catch(IOException | InterruptedException ioe){
            System.err.println("uploadSketch Problem: " + ioe);
            return false;
        }
        return true;
    }
    
    /**
     * This method checks for errors which occured during compiling or uploading the sketch.
     * It reads the log file of the upload script, and if it finds certain strings (which imply that an error occured) 
     * It returns false and shows a message dialog window which states the error.
     * @return true if no erros were found, false otherwise.
     */
    private boolean checkForErrorsUploading(){
        File uploadLogFile = new File(miscPath + uploadLog);
        String output = "";
        
        
        try (BufferedReader uLFBR = new BufferedReader(new FileReader (uploadLogFile))) {
            String line;
            while((line = uLFBR.readLine()) != null){
                output += line;
            }
        }
        catch(IOException ioex){
            System.err.println("checkForErrorsUploading: problem: " + ioex);
        }
        
        if(output.contains("Error compiling.")){
            return false;
        }
        else if(output.contains("No such device or address")){
            JOptionPane.showMessageDialog(null, "Check the USB connection to the controller.\nMake sure it's connected "
                    + "and to the right COM port,\nas specified in the  programs setup.");
            return false;
        }
        else if(output.contains("Permission denied")){
            JOptionPane.showMessageDialog(null, "Make sure there isn't any serial terminal running\nconnected to the controller");
            return false;
        }
        else if(output.split("Transfer complete", -1).length == 4){
            return true;
        }
        else{
            System.out.println("Number of TC occurences: " + output.split("Transfer complete", -1).length);
            return false;
        }
        
    }
    
    /**
     * This method is responsible for turning on the monitor sketch, which already exists on the controller.
     * This is done, by simply renaming the current sketch file from "sketch.elf" to "sketch.elf.old" and then copying the
     * "monitor.elf" to "sketch.elf" and restarting the sketch process.
     * This done by killing the current running sketch prc. and afterwards killing the clloader prc.
     * When the clloader prc. is killed, its parent prc. restarts it, which in turn restarts the sketch prc. that now uses the newly updated file.
     * All of the operations are done through the ethernet connection, using pLink.exe.
     */
    private void switchMonSketchON(){
        try{
            // Creating commands as strings
            /// First you "delete" the current sketch and duplicate the monitor sketch to a file named "sketch.elf".
            /// Then, using the "killall" command with the "-KILL" signal to eliminate the sketch.elf proccess.
            /// Finally, using the same "killall -KILL" you kill the clloader proccess.
            /// Then the launcher.sh proc. automatically restarts the clloader which auto. restarts the sketch.elf, 
            /// but this time using the newly copied file "sketch/elf"
            String mvCMD = "mv -f /sketch/sketch.elf /sketch/sketch.elf.old ; ";
            String cpCMD = "cp /sketch/monitorSketch.elf /sketch/sketch.elf ; ";
            String killSkchCMD = "killall -KILL sketch.elf ; ";
            String killCLLCMD = "killall -KILL clloader";
            String plinkCMD = "cmd.exe /c echo y | " + miscPath + plinkExe + " root@" + hostName + " " + mvCMD + cpCMD + killSkchCMD + killCLLCMD; 
            System.out.println(plinkCMD);
            
            // executing the command - running plink through cmd shell
            Process cmdP = Runtime.getRuntime().exec(plinkCMD);
            cmdP.waitFor();
            
            Thread.sleep(2000);
            
            // reading the output of the cmd shell for debugging
            BufferedReader cmdBR = new BufferedReader(new InputStreamReader(cmdP.getInputStream())); 
            String cmdOutput;
            while((cmdOutput = cmdBR.readLine())!=null) { 
                System.out.println(cmdOutput); 
            } 
            System.out.println("switchMonSketchON: finished");
        }
        catch(IOException | InterruptedException ioe){
            System.err.println("switchMonSketchON Problem: " + ioe);
        }
    }
    
    /**
     * This method sets the panel stated by the passed string as the shown panel in the simulation and measurement tabs.
     * The available panels to show are the graph panel and the text area panel.
     * 
     * @param card the string describing the panel to show.
     * @param parent the parent panel which contains both sub-panels in a CardLayout.
     */
    private void switch_RTG_TACT(String card, JPanel parent){
        CardLayout cL = (CardLayout) parent.getLayout();
        cL.show(parent, card);
    }
    
    /**
     * This method reads the code from the file which is described by the passed path string 
     * and writes it to the code text area. 
     * It also paints the bordered sections in case they exist.
     * @param selPath the string which specifies the path of the code file.
     * @param codeArea the code text area to be written to.
     * @param modelOrSimu the string which describes the added text. It is either "selected simu. code:" or "selected model code:"
     * @return true if the reading was successful, and false otherwise.
     */
    private boolean updateCodeArea(String selPath, JTextArea codeArea, String modelOrSimu){
        try (FileReader codeFR = new FileReader(new File(selPath))) {
            codeArea.setText("");
            codeArea.read(codeFR, modelOrSimu);
            codeArea.setTabSize(2);
            //paintSections(codeArea);
            if(modelOrSimu.contains("Simu")){
                codeArea.getDocument().addDocumentListener(new DocumentListener(){
                    @Override
                    public void changedUpdate(DocumentEvent e){                       
                    }

                    @Override
                    public void insertUpdate(DocumentEvent e) {
                        if(!isSimuCodeChanged){ isSimuCodeChanged = true;}
                    }

                    @Override
                    public void removeUpdate(DocumentEvent e) {
                        if(!isSimuCodeChanged){ isSimuCodeChanged = true;}
                    }
                });       
            }
            else{
                codeArea.getDocument().addDocumentListener(new DocumentListener(){
                    @Override
                    public void changedUpdate(DocumentEvent e){
                    }

                    @Override
                    public void insertUpdate(DocumentEvent e) {
                        if(!isModelCodeChanged){ isModelCodeChanged = true;}
                        //System.err.println("isModelChanged: " + isModelCodeChanged);
                    }

                    @Override
                    public void removeUpdate(DocumentEvent e) {
                        if(!isModelCodeChanged){ isModelCodeChanged = true;}
                    }
                });
            }
            return true;                
        }
        catch(IOException ioex){
            System.err.println("updateCodeArea Problem: " + ioex);
            return false;
        }
    }
    
    /**
     * This method is called when the monChannel1 JCheckBox is clicked.
     * In turn, it calls the method updateMonitor_GUI(...).
     * @param evt the event fired when the checkBox was clicked
     */
    private void monChannel1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monChannel1ActionPerformed
        updateMonitor_GUI(1,monChannel1.isSelected());
    }//GEN-LAST:event_monChannel1ActionPerformed

    /**
     * This method is called when the monChannel2 JCheckBox is clicked.
     * In turn, it calls the method updateMonitor_GUI(...).
     * @param evt the event fired when the checkBox was clicked
     */
    private void monChannel2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monChannel2ActionPerformed
        updateMonitor_GUI(2,monChannel2.isSelected());
    }//GEN-LAST:event_monChannel2ActionPerformed
    /**
     * This method is called when the monChannel3 JCheckBox is clicked.
     * In turn, it calls the method updateMonitor_GUI(...).
     * @param evt the event fired when the checkBox was clicked
     */
    private void monChannel3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monChannel3ActionPerformed
        updateMonitor_GUI(3,monChannel3.isSelected());
    }//GEN-LAST:event_monChannel3ActionPerformed
    /**
     * This method is called when the monChannel4 JCheckBox is clicked.
     * In turn, it calls the method updateMonitor_GUI(...).
     * @param evt the event fired when the checkBox was clicked
     */
    private void monChannel4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monChannel4ActionPerformed
        updateMonitor_GUI(4,monChannel4.isSelected());
    }//GEN-LAST:event_monChannel4ActionPerformed
    /**
     * This method is called when the monChannel5 JCheckBox is clicked.
     * In turn, it calls the method updateMonitor_GUI(...).
     * @param evt the event fired when the checkBox was clicked
     */
    private void monChannel5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monChannel5ActionPerformed
        updateMonitor_GUI(5,monChannel5.isSelected());
    }//GEN-LAST:event_monChannel5ActionPerformed
    /**
     * This method is called when the monChannel6 JCheckBox is clicked.
     * In turn, it calls the method updateMonitor_GUI(...).
     * @param evt the event fired when the checkBox was clicked
     */
    private void monChannel6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monChannel6ActionPerformed
        updateMonitor_GUI(6,monChannel6.isSelected());
    }//GEN-LAST:event_monChannel6ActionPerformed

    /**
     * This method is called to update the number of sub-graphes displayed according to the checked check boxes
     * in the monitor tab.
     * It also sends an updated data to the controller, which by now runs the monitorSketch, to add/remove analog input channels.
     * @param chanNum the channel number to modify
     * @param isChanSel true if the channel is checked and should be displayed, false otherwise. 
     */
    private void updateMonitor_GUI(int chanNum, boolean isChanSel){
        UpdatePlotNum.updatePlotNum(monitorRTG.plot, monitorRTG.subp, chanNum-1, isChanSel);
        monChannels[chanNum-1] = isChanSel ? 1 : 0;
        
        if(!monitorRTG.updateChannels_RTG(monChannels)){
            JOptionPane.showMessageDialog(null, "Problem updating graph!\nCheck cable connection and press the \"connect\" button.");
            monitorRTG.closeMonitor();
            monitorConnect.setText("Connect");
            monitorRTG.setTitle(monitorRTG.baseTitle + " - Monitor - Not Connected");
        }
        
    }
    
    /**
     * This method is called when the user switches from one tab to another.
     * It first closes the running server connection and if the selected tab is the monitor, 
     * then it starts the monitor connection.
     * @param evt the event that was fired when the tabs were switched.
     */
    private void tabPanelStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_tabPanelStateChanged
        closeTab(previousTab);
        
        switch(tabPanel.getSelectedIndex()){
            case 0:{
                break;
            }
            case 1:{
                break;
            }
            case 2:{
                monitorTabUI();
                break;
            }
            
        }
        
        previousTab = tabPanel.getSelectedIndex(); 
    }//GEN-LAST:event_tabPanelStateChanged
    
    /**
     * This method is called when user switches to another tab.
     * It simply programatically clicks the "stop" button (if the simu/meas/monitor were running) to stop the running.
     * @param sm an integer to specify which tab was moved from.
     */
    private void closeTab(int sm){
        switch(sm){
            // simuTab closed
            case 0:{
                if(sStartOrStop.getText().equals("Stop")){
                    sStartOrStop.doClick();
                }
                break;
            }
            // modelTab closed
            case 1:{ 
                if(mStartOrStop.getText().equals("Stop")){
                    mStartOrStop.doClick();
                }   
                break;
            }
            // monitorTab closed
            case 2:{
                if(monitorConnect.getText().equals("Stop")){
                    monitorConnect.doClick();
                }
                break;
            }
        }
    }
    
    /**
     * This method is called in start the monitoring of the analog inputs of the controller.
     * The steps are:
     * 1. Initializing the server connection if not already initialized.
     * 2. Sending commands to the controller to turn on the monitor sketch.
     * 3. connecting to the monitor and start the data reception and graph updating.
     * 
     * If there was an error while connecting to the controller, a message will be shown the inform the user.
     */
    private void monitorTabUI(){
        
        if(monitorSaveBut.isVisible()){return;}
        
        boolean isMonitorWorking = false;

        if(monitorRTG.bUM.SUI == null){
            System.out.println("monitorRTG.bU.SUI is null");
            monitorRTG.startServerUI(hostName);
        }
        
        createPopupWindow("Switching on the Monitor - please wait...");
        
        swMonitorStart = new SwingWorker<Boolean, Void>(){
            @Override
            protected Boolean doInBackground() throws InterruptedException {
                switchMonSketchON();
                return connectAndMonitor();
            }
            @Override
            protected void done(){
                loading.setVisible(false);
            }
        };
        swMonitorStart.execute();
        loading.setVisible(true);
        try{
            isMonitorWorking = swMonitorStart.get();
        }
        catch(InterruptedException ie){
            System.err.println("MonitorTabUI IE Problem: " + ie);
        }
        catch(ExecutionException ee){
            System.err.println("MonitorTabUI EE Problem: " + ee);
        }

        /// If there was an error while connecting to the controller, a message will be shown to inform the user.
        if(!isMonitorWorking){
            JOptionPane.showMessageDialog(null, "Controller Not Connected! \nPlease connect the controller \nand press the \"Connect\" button.");
            monitorRTG.setTitle(monitorRTG.baseTitle + " - Monitor - Not Connected");
            monitorConnect.setText("Connect");
        }
        else{
            /*SwingUtilities.invokeLater(new Runnable(){
                public void run(){
                    monitorRTG.bUM.updateSetsAndDel();
                    System.out.println("monitorTabUI - finished running");
                }
            });*/
            monitorRTG.setTitle(monitorRTG.baseTitle + " - Monitor - Running");
            monitorConnect.setText("Stop");
           
        }
    }
    
    /**
     * This method closes the server connection of the specified tab, so another connection can be 
     * easily established.
     * @param prevSI the number describing the previous Server Interface (prevSI).
     */
    private void closeServerCon_GUI(int prevSI){
        switch(prevSI){
            case 0:{
                if((!isFirstTimeTab)&&(simuRTG.bUSM.SUI != null)){
                    simuRTG.closeSM();
                    System.out.println("AbstractGUI class: simulation sockets closed...");
                }
                break;
            }
            case 1:{
                if(modelRTG.bUSM.SUI != null){
                    modelRTG.closeSM();
                    System.out.println("AbstractGUI class: model sockets closed...");
                }
                break;
            }
            case 2:{
                monitorRTG.closeMonitor();
                System.out.println("AbstractGUI class: monitor sockets closed...");
                break;
            }
        }
            

    }
    
    /**
     * This method is called when parameters are added or removed in the simulation tab, based on the number of parameters to show.
     * It shows the added parameter's label, value and name field and hides and resets the removed parameter's label, value and name.
     * @param evt the event fired when number of parameters to show changes.
     */
    private void simuParamNumStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_simuParamNumStateChanged
        simuParNum = (int)simuParamNum.getValue();
        for (int i=0; i<simuParNum; i++){
            simuParPanel[i].setVisible(true);
        }
        for(int i=10-1; i>=simuParNum; i--){
            simuParPanel[i].setVisible(false);
            simuParam[i].setText("0");
        }
    }//GEN-LAST:event_simuParamNumStateChanged

    /**
     * This method handles the selection of the code to display in the code text area in the simulation tab.
     * If changes were made to the currently loaded code, it will offer the save them before loading a new code.
     * @param evt the action event fired when a new option is selected in the "select code" JComboBox.
     */
    private void sCodeTypeChooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sCodeTypeChooseActionPerformed
        if(isSimuCodeChanged){  /// If there were changes made to the code, offer to save them.
            if (!saveChanges(selSimuPath, storedSimuCodes, sCodeArea)){return;}
            isSimuCodeChanged = false;
        }
        switch(sCodeTypeChoose.getSelectedIndex()){
            case 0: break;
            case 1:{ // choosing from a file
                if(JFC.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
                    selSimuPath = JFC.getSelectedFile().getPath();
                    System.out.println("Selected simulation path is: " + selSimuPath);
                    if(!selSimuPath.endsWith(".ino")){
                        sShowMessageDialog("File should have an \".ino\" extension");
                        return;
                    }
                    if(!updateCodeArea(selSimuPath, sCodeArea, "Selected Simulation Code")){
                        sShowMessageDialog("Problem Opening the file: \n" + selSimuPath);
                        return;
                    }
                    isSimuCodeChanged = false;
                    sCodeNameLabel.setText(JFC.getSelectedFile().getName());
                    sSketchPath.setText(selSimuPath);
                }

                sCodeTypeChoose.setSelectedIndex(0); // return the choice to select
                break;
            }
            default:{
                String codeLabel = sCodeTypeChoose.getSelectedItem().toString();
                String codePath = storedSimuCodes.get(codeLabel);               
                if(!updateCodeArea(codePath, sCodeArea, "Selected Simulation Code")){
                    sShowMessageDialog("Problem Opening the file: \n" + codePath);
                    return;
                }
                isSimuCodeChanged = false;
                selSimuPath = codePath;
                sCodeNameLabel.setText(codeLabel);
                sSketchPath.setText(codePath); 
                break;
            }
        }
    }//GEN-LAST:event_sCodeTypeChooseActionPerformed

    /**
     * This method handles the saving process of a code. It checks if the changed code is from the stored files, and then offers to either overwrite the 
     * existing file, or save to a new file. If the code is not a stored code, then it will overwrite the existing code.
     * @param selPath <code>String</code> - the path of the changed code
     * @param storedCodes <code>Map(String,String)</code> - the list of stored codes
     * @param codeArea <code>JTextArea</code> - the text area containing the code
     * @return <code>True</code> if the saving process was successful, <code>False</code> otherwise.
     */
    private boolean saveChanges(String selPath, Map<String,String> storedCodes, JTextArea codeArea){
        int choice;
        if(storedCodes.containsValue(selPath)){  /// If the changed code was a stored code, offer to save to the stored path or to a new file.
            String key = "";
            for(Map.Entry<String,String> entry : storedCodes.entrySet()){ /// find the label of the path
                if(entry.getValue().equals(selPath)){
                    key = entry.getKey();
                }
            }
            choice = JOptionPane.showConfirmDialog(null, "Would you like to save the changes made in \"" + key + "\"" + " ?");
            if(choice == JOptionPane.YES_OPTION){
                String question = "Would you like to save the changes to the stored file, or to a different file?";
                String title = "Save to stored or to new file";
                String[] newOrStored = {"to stored file","to new file"};
                //// offering to save to stored path or the new file.
                int jopChoice = JOptionPane.showOptionDialog(null, question, title, JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, newOrStored, newOrStored[1]);
                switch(jopChoice){
                    case 0:{
                        if(saveCode(selPath, codeArea)){
                            JOptionPane.showMessageDialog(null, "File Saved!");
                        }
                        break;
                    }
                    case 1:{
                        if(JFC.showSaveDialog(null) == JFileChooser.APPROVE_OPTION){
                            String savePath = JFC.getSelectedFile().getPath();
                            System.out.println("Save Path is: " + savePath );
                            if(saveCode(savePath, codeArea)){
                                JOptionPane.showMessageDialog(null, "File Saved!");
                            }
                            else{
                                sShowMessageDialog("Problem Saving the file: \n" + savePath);
                                return false;
                            }
                        }
                        break;
                    }
                    default: return false;
                }
            }
        }
        else {
            choice = JOptionPane.showConfirmDialog(null, "Would you like to save the changes made in \"" + selPath + "\"" + " ?");
            if(choice == JOptionPane.YES_OPTION){
                if(!selPath.equals("File Path...")){
                    if(!saveCode(selPath, codeArea)){
                        JOptionPane.showMessageDialog(null, "Problem Saving the file: \n" + selPath);
                        return false;
                    }
                }
                else{
                    if(JFC.showSaveDialog(null) == JFileChooser.APPROVE_OPTION){
                        String savePath = JFC.getSelectedFile().getPath();
                        System.out.println("Save Path is: " + savePath );
                        if(saveCode(savePath, codeArea)){
                            JOptionPane.showMessageDialog(null, "File Saved!");
                        }
                        else{
                            sShowMessageDialog("Problem Saving the file: \n" + savePath);
                            return false;
                        }
                    }
                }
            }
        }
        return true;
    }
    
    /**
     * This methoed is responsible for showing a pop-up message window, displaying the erros the passed string.
     * This is called when a probelm occurs in sCodeTypeChooseActionPerformed method in the simulation tab.
     * @param problem the string to display.
     */
    private void sShowMessageDialog(String problem){
        JOptionPane.showMessageDialog(null, problem);
        sCodeTypeChoose.setSelectedIndex(0); // return the choice to select
        selSimuPath = sSketchPath.getText();
        
    }
    
    /**
     * This method saves the code text area created to a file with an .ino extension (assuming it is a source code for the controller.
     * @param savePath the chosen path of the file to be saved.
     * @param ca the code text area which contains the code to save.
     * @return true if the save operation was successful, false otherwise.
     */
    private boolean saveCode(String savePath, JTextArea ca){
        if(!savePath.endsWith(".ino")){
            savePath += ".ino";
        }
        File saveFile = new File(savePath);
        try (FileWriter sfW = new FileWriter(saveFile)) {
            ca.write(sfW);
            return true;
        }
        catch(IOException ioex){
            System.err.println("saveCode Method Problem: " + ioex);
            return false;
        }
    }
    
    /**
     * This method handles the trigger selection in the simulation tab.
     * Based on the selected trigger type in the "trigger shape" JComboBox, it modifies the variable "trigType".
     * When the pulse trigger is selected then the duty cycle is shown, otherwise it is hidden.
     * @param evt the ActionEvent fired when the trigger choice is changed in the "trigger shape" JComboBox.
     */
    private void triggerShapeChooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_triggerShapeChooseActionPerformed
        switch(triggerShapeChoose.getSelectedIndex()){
            case 0:{ // pulse wave with duty cycle      _-_-_-
                trigTyp = 'P';
                setDutyCycVisible(true);
                return;
            }
            case 1:{ // Sine wave without d.c.          ~~~~~~~
                trigTyp = 'S';
                break;
            }
            case 2:{ // Triangular wave                 /\/\/\/\/\/\/\
                trigTyp = 'T';
                break;
            }
            case 3:{ // Ramp wave                       /|/|/|/|
                trigTyp = 'R';
                break;
            }
            default: break;
        }
        setDutyCycVisible(false);
    }//GEN-LAST:event_triggerShapeChooseActionPerformed

    /**
     * This method handles the pressing of the start/stop button in the simulation tab.<p>
     * When the button says "Start" and it's pressed, the method will ask to save any 
     * changes made to the code, and upload the sketch to the controller.<br> It will also start up the graph interface
     * and the background update of it.<p>
     * When the button says "Stop" and it's pressed, the method will show the "save" option, closes the server connection and
     * stop the graph background updating (the graph is still displayed).<p>
     * When the button says "Return to code" and it's pressed, 
     * the method will switch the displays hiding the graph and showing the code/tamplate text areas.<br>
     * Before doing so, it will offer the save the data collected in the simulation from the controller.
     * @param evt the ActionEvent fired when the simulation start/stop button is pressed.
     */
    private void sStartOrStopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sStartOrStopActionPerformed
        int isSimuWorking = 0;
        
        switch(sStartOrStop.getText()){
            case "Start":
            {
                if(isSimuCodeChanged){
                    if(!offerToSaveSimuModelCode(sSketchPath, sCodeArea, "simulation")){return;}
                    isSimuCodeChanged = false;
                }
                
                if(simuRTG.bUSM.SUI == null){
                    simuRTG.startServerUI(hostName);
                }                

                String skPath = sSketchPath.getText();
                createPopupWindow("Uploading Simulation Sketch - please wait...");

                swSimuStart = new SwingWorker<Integer, Void>(){
                    @Override
                    protected Integer doInBackground() throws InterruptedException {
                        if(!uploadSketch(skPath)) {return 1;}
                        try{Thread.sleep(1000);}catch(InterruptedException ie){System.err.println("sStartOrStopActionPerformed: problem: " +ie);}
                        if(!connectAndSM(simuRTG,updateSimuPars())){return 2;}
                        return 0;
                    }
                    @Override
                    protected void done(){
                        loading.setVisible(false);
                    }
                };

                swSimuStart.execute();
                loading.setVisible(true);
                
                try{
                    isSimuWorking = swSimuStart.get();
                }
                catch(InterruptedException|ExecutionException iee){
                    System.err.println("sStartOrStopActPer: Problem: " + iee);
                }
                
                if(isSimuWorking == 1){
                }
                else if(isSimuWorking == 2){
                    JOptionPane.showMessageDialog(null, "Controller Intel® Galileo not connected through Eth.\n"
                            + "Please connect the controller \nand press the \"start\" button again.");
                }
                else{
                    switch_RTG_TACT(RTG, simu_TACT_RTG_panel);
                    sStartOrStop.setText("Stop");
                    sUpdateOrSave.setVisible(true);
                }
                break;
            }
            case "Stop":
            {
                closeServerCon_GUI(0);
                sStartOrStop.setText("Return to code");
                sUpdateOrSave.setText("Save data");
                break;
            }
            case "Return to code":
            {
                switch (sUpdateOrSave.getText()) {
                    case "Save data":
                        if(!offerToSaveSimuModelSession(simuRTG, "simulation")){
                            break;
                        }
                    case "Saved":
                        sUpdateOrSave.setText("Update");
                        sUpdateOrSave.setVisible(false);
                        simuRTG.clearSetsAndFIFO();
                        sStartOrStop.setText("Start");
                        switch_RTG_TACT(TACT, simu_TACT_RTG_panel);
                        break;
                }
                break;
            }
        }
    }//GEN-LAST:event_sStartOrStopActionPerformed
    
    /**
     * This method starts up the server connection to the controller during the simulation/measurements, as well 
     * as the background update of the graph.
     * @param smRtg the graph in the current tab.
     * @param data the String array which contains the data to be sent to the controller - 1 parameter line for the measurements, 
     * and 2 parameter/trigger lines for the simulation.
     * @return true if the connection was successful, false otherwise.
     */
    public boolean connectAndSM(RealTimeGraph_SimuModel smRtg, String[] data){
        if(smRtg.bUSM.startSM(data)){
            smRtg.startBackgroundUpdate();
            return true;
        }
        else{
            return false;
        }
    }
    
    /**
     * This method sets the data line containing the trigger values for the simulation.
     * For each of the fields, it checks if it is a valid entry (otherwise the code won't work as expected and an error message will be displayed),
     * and then adds them to overall line.
     * @return the String containing all the trigger fields, separated with a " ".
     */
    private String setTriggerString(){
        String triggerString;
        String errorPars = "";
        amp = (ampVal.getText());
        if(!checkIfNumber(amp)){
            errorPars += "Amplitude \n";
        }
        
        cyc = (periodVal.getText());
        if(!checkIfNumber(cyc)){
            errorPars += "Period \n";
        }
        
        dcOff =(dcOffsetVal.getText());
        if(!checkIfNumber(dcOff)){
            errorPars += "DC offset \n";
        }
        
        res = timeResVal.getText();
        if(!checkIfNumber(res)){
            errorPars += "Time Resolution \n";
        }
        else{
            simuRTG.updateXAxis(Double.parseDouble(res));
        }
        
        dutyCyc = (dutyCycleVal.getText());
        if(!checkIfNumber(dutyCyc)){
            errorPars += "Duty Cycle \n";
        }
        
        if(durationVal.getText().equals("inf")){
            dur = "0";
        }
        else {
            dur = (durationVal.getText());
            if(!checkIfNumber(dur)){
                errorPars += "Duration \n";
            }
        }

        if(errorPars.length() != 0){
            popUpErrorNumber(errorPars);
            return null;
        }
        
        /// In Simulation need to send 2 lines -
        ///                                     1 line = "O " + triggerDataSend
        ///                                     2 line = "K " + paramsLine
        triggerString ="O" + res + " " + dur + " " + trigTyp + " " + amp + " " + cyc + " " + dcOff + " " + dutyCyc + " ";
        return triggerString;
    }
    
    /**
     * This method pops up a message displaying the errors in the passed string when a checked number can't be
     * parsed to a double.
     * @param parameters the string containing the errors to display.
     */
    private void popUpErrorNumber(String parameters){
        popUpErrorMessage("The following parameters are not numeric:\n" + parameters);
    }
    
    /**
     * This method pops up a message displaying the error passed to it.
     * @param error the String describing the error.
     */
    private void popUpErrorMessage(String error){
        JOptionPane.showMessageDialog(null, error);
    }
    
    /**
     * This method is called when parameters are added or removed in the measurements tab, based on the number of parameters to show.
     * It shows the added parameter's label, value and name field and hides and resets the removed parameter's label, value and name.
     * @param evt the event fired when number of parameters to show changes.
     */
    private void modelParamNumStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_modelParamNumStateChanged
        modelParNum = (int)modelParamNum.getValue();
        for (int i=0; i < modelParNum; i++){
            modelParPanel[i].setVisible(true);
        }
        for(int i=10-1; i >= modelParNum; i--){
            modelParPanel[i].setVisible(false);
        }
    }//GEN-LAST:event_modelParamNumStateChanged

    /**
     * This method handles the selection of the code to display in the code text area in the measurements tab.
     * If changes were made to the currently loaded code, it will offer the save them before loading a new code.
     * @param evt the action event fired when a new option is selected in the "select code" JComboBox.
     */
    private void mCodeTypeChooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mCodeTypeChooseActionPerformed
        if(isModelCodeChanged){
            if (!saveChanges(selModelPath, storedModelCodes, mCodeArea)){return;}
            isModelCodeChanged = false;
        }
        switch(mCodeTypeChoose.getSelectedIndex()){
            case 0: break;
            case 1:{ // choosing from a file
                if(JFC.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
                    selModelPath = JFC.getSelectedFile().getPath();
                    System.out.println("Selected model path is: " + selModelPath);
                    
                    if(!selModelPath.endsWith(".ino")){
                        mShowMessageDialog("File should have an \".ino\" extension!");
                        return;
                    }
                    
                    if(!updateCodeArea(selModelPath, mCodeArea, "Selected Model Code")){
                        mShowMessageDialog("Problem Opening the file: \n" + selModelPath);
                        return;
                    }
                    isModelCodeChanged = false;
                    mCodeNameLabel.setText(JFC.getSelectedFile().getName());
                    mSketchPath.setText(selModelPath);
                }
                mCodeTypeChoose.setSelectedIndex(0);
                break;
            }
            default:{
                String codeLabel = mCodeTypeChoose.getSelectedItem().toString();
                String codePath = storedModelCodes.get(codeLabel);
                if(!updateCodeArea(codePath, mCodeArea, "Selected Model Code")){
                    mShowMessageDialog("Problem Opening the file: \n" + codePath);
                    return;
                }
                isModelCodeChanged = false;
                selModelPath = codePath;
                mCodeNameLabel.setText(codeLabel);
                mSketchPath.setText(codePath);
                break;
            }
        }
    }//GEN-LAST:event_mCodeTypeChooseActionPerformed

    /**
     * This methoed is responsible for showing a pop-up message window, displaying the erros the passed string.
     * This is called when a probelm occurs in mCodeTypeChooseActionPerformed method in the measurements tab.
     * @param problem the string to display.
     */
    private void mShowMessageDialog(String problem){
        JOptionPane.showMessageDialog(null,problem);
        mCodeTypeChoose.setSelectedIndex(0);
        selModelPath = mSketchPath.getText();
    }
    
    /**
     * This method handles the pressing of the start/stop button in the measurements tab.<p>
     * When the button says "Start" and it's pressed, the method will ask to save any 
     * changes made to the code, and upload the sketch to the controller.<br> It will also start up the graph interface
     * and the background update of it.<p>
     * When the button says "Stop" and it's pressed, the method will show the "save" option, closes the server connection and
     * stop the graph background updating (the graph is still displayed).<p>
     * When the button says "Return to code" and it's pressed, 
     * the method will switch the displays, hiding the graph and showing the code/tamplate text areas.<br>
     * Before doing so, it will offer the save the data collected in the measurements from the controller.
     * @param evt the ActionEvent fired when the measurements start/stop button is pressed.
     */    
    private void mStartOrStopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mStartOrStopActionPerformed
        int isModelWorking = 0;
        
        switch(mStartOrStop.getText()){
            case "Start":
            {
                if(isModelCodeChanged){
                    if(!offerToSaveSimuModelCode(mSketchPath, mCodeArea, "measurements")){return;}
                    isModelCodeChanged = false;
                }
                
                if(modelRTG.bUSM.SUI == null){
                    System.out.println("modelRTG.bU.SUI is null");
                    modelRTG.startServerUI(hostName);
                } 
                
                String skPath = mSketchPath.getText();
                createPopupWindow("Uploading Model Sketch - please wait...");

                swModelStart = new SwingWorker<Integer, Void>(){
                    @Override
                    protected Integer doInBackground() throws InterruptedException {
                        if(!uploadSketch(skPath)){ return 1;}
                        try{Thread.sleep(1000);}catch(InterruptedException ie){System.err.println("sStartOrStopActionPerformed: problem: " +ie);}
                        if(!connectAndSM(modelRTG, updateModelPars())){ return 2; }
                        return 0;
                    }
                    @Override
                    protected void done(){
                        loading.setVisible(false);
                    }
                };

                swModelStart.execute();
                loading.setVisible(true);


                try{
                    isModelWorking = swModelStart.get();
                }
                catch(InterruptedException|ExecutionException iee){
                    System.err.println("mStartOrStopActPer: Problem: " + iee);
                }                                

                if(isModelWorking == 1){
                }
                else if(isModelWorking == 2){
                    JOptionPane.showMessageDialog(null, "Controller Intel® Galileo not connected through Eth.\n"
                            + "Please connect the controller \nand press the \"start\" button again.");
                }
                else{
                
                    switch_RTG_TACT(RTG, model_TACT_RTG_panel);

                    mStartOrStop.setText("Stop");
                    mUpdateOrSave.setVisible(true);
                }
                break;
            }
            case "Stop":
            {
                //// Do something more
                closeServerCon_GUI(1);
                mStartOrStop.setText("Return to code");
                mUpdateOrSave.setText("Save data");
                break;
            }
            case "Return to code":
            {
                switch (mUpdateOrSave.getText()) {
                    case "Save data":
                        if(!offerToSaveSimuModelSession(modelRTG, "measurements")){
                            break;
                        }
                    case "Saved":
                        mUpdateOrSave.setText("Update Parameters");
                        mUpdateOrSave.setVisible(false);
                        modelRTG.clearSetsAndFIFO();
                        mStartOrStop.setText("Start");
                        switch_RTG_TACT(TACT, model_TACT_RTG_panel);
                        break;
                }
                break;
            }
        }
        
    }//GEN-LAST:event_mStartOrStopActionPerformed

    /**
     * This method offers to save changes made to the simulation or model code, using the passed components.
     * It also checks if the changed code is from the stored files, and then offers to either overwrite the 
     * existing file, or save to a new file.
     * @param sketchPath the <code>JTextField</code> containing the code's path.
     * @param codeArea the <code>JTextArea</code> containing the code with the changes made to it.
     * @param sm the <code>String</code> containing either "Simulation" or "Measurements".
     * @return <code>True</code> if the saving operation was successful, 
     * <code>False</code> if the either saving<br> was canceled or exited, or a problem occured while saving.
     */
    private boolean offerToSaveSimuModelCode(JTextField sketchPath, JTextArea codeArea, String sm){
        Map<String,String> storedCodes = (sm.equals("simulation") ? storedSimuCodes : storedModelCodes);
        int choice;
        if(storedCodes.containsValue(sketchPath.getText())){  /// If the changed code was a stored code, offer to save to the stored path or to a new file.
            String key = "";
            for(Map.Entry<String,String> entry : storedCodes.entrySet()){ /// find the label of the path
                if(entry.getValue().equals(sketchPath.getText())){
                    key = entry.getKey();
                }
            }
            choice = JOptionPane.showConfirmDialog(null, "Would you like to save the changes made in \"" + key + "\"" + " ?");
            if(choice == JOptionPane.YES_OPTION){
                String question = "Would you like to save the changes to the stored file, or to a different file?";
                String title = "Save to stored or to new file";
                String[] newOrStored = {"to stored file","to new file"};
                //// offering to save to stored path or the new file.
                int jopChoice = JOptionPane.showOptionDialog(null, question, title, JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, newOrStored, newOrStored[1]);
                switch(jopChoice){
                    case 0:{
                        if(saveCode(sketchPath.getText(), codeArea)){
                            JOptionPane.showMessageDialog(null, "File Saved!");
                        }
                        break;
                    }
                    case 1:{
                        if(JFC.showSaveDialog(null) == JFileChooser.APPROVE_OPTION){
                            String savePath = JFC.getSelectedFile().getPath();
                            System.out.println("Save Path is: " + savePath );
                            if(saveCode(savePath, codeArea)){
                                JOptionPane.showMessageDialog(null, "File Saved!");
                            }
                            else{
                                sShowMessageDialog("Problem Saving the file: \n" + savePath);
                                return false;
                            }
                        }
                        break;
                    }
                    default: return false;
                }
            }
        }
        else{
            choice = JOptionPane.showConfirmDialog(null, "Would you like to save the changes made in the " + sm + " code?");
            if(choice == JOptionPane.YES_OPTION){
                if(!sketchPath.getText().equals("File Path...")){
                    if(!saveCode(sketchPath.getText(), codeArea)){
                        JOptionPane.showMessageDialog(null, "Problem Saving the file: \n" + sketchPath.getText());
                        return false;
                    }
                }
                else{
                    if(JFC.showSaveDialog(null) == JFileChooser.APPROVE_OPTION){
                        String savePath = JFC.getSelectedFile().getPath();
                        System.out.println("Save Path is: " + savePath );
                        if(!saveCode(savePath, codeArea)){
                            JOptionPane.showMessageDialog(null, "Problem Saving the file: \n" + savePath);
                            return false;
                        }
                        else{
                            sketchPath.setText(savePath);
                        }
                    }
                    else{return false;}
                }
            }
            else if((choice == JOptionPane.CANCEL_OPTION) || (choice == JOptionPane.CLOSED_OPTION)){
                return false;
            }
        }
        return true;
    }
    
    /**
     * This method is called when the user is asked wether he wants to save the data collected in the simulation/measurements session.
     * If user agrees a save method is invoked, otherwise not.
     * @param rtg the <code>RealTimeGrapsh_SimuModel</code> graph from which to save the data.
     * @param sm the <code>String</code> containing either "Simulation" or "Measurements".
     * @return true if the user agreed or disagreed to save, false when the user cancels.
     */
    private boolean offerToSaveSimuModelSession(RealTimeGraph_SimuModel rtg, String sm){
        int choice = JOptionPane.showConfirmDialog(null, "Would you like to save the last " + sm + " session data?");
        switch(choice){
            case JOptionPane.YES_OPTION:{
                return saveSMSession(rtg);
            }
            case JOptionPane.NO_OPTION:{
                return true;
            }
            default:{
                return false;
            }
        }
    }
    
    /**
     * This method is called when the update/save button in the measurements tab is pressed.
     * When the button says "Update Parameters" and it's pressed, it sends data with the updated values of the parameters to the controller.
     * if an error occurs while sending the data, it is assumed that there is a problem in the ethernet connection to the controller - a message pop up
     * window is displayed and the measurement is stopped.
     * When the button says "Save data" or "Saved" and it's pressed, a method is invoked to save the data collected in the graph.
     * @param evt the ActionEvent fired when the button wsa pressed.
     */
    private void mUpdateOrSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mUpdateOrSaveActionPerformed
        switch(mUpdateOrSave.getText()){
            case "Update Parameters":{
                if(!modelRTG.bUSM.update(updateModelPars())){
                    JOptionPane.showMessageDialog(null, "Problem updating the parameters.\nTry checking the Eth. connection to the controller\n"
                            + "and press the \"connect\" button.");
                    mStartOrStop.doClick();
                    mStartOrStop.doClick();
                }
                break;
            }
            case "Saved":
            case "Save data":{
                if(saveSMSession(modelRTG)){
                    mUpdateOrSave.setText("Saved");
                }
                break;
            }
        }
        
    }//GEN-LAST:event_mUpdateOrSaveActionPerformed
    
    /**
     * This method invokes a sub-method to set a string line containing the parameters values, and then returns that line.
     * This is called in the measurements tab.
     * @return String array containing the parameters values line.
     * 
     * Note: a string array is returned rather then just a single string line. This is because the method which sends the data to the controller
     * works both for the measurements and the simulation. In order to support the simulation which has two line sent (trigger in addition to param.)
     * a String array is used in both cases.
     */
    private String[] updateModelPars(){
        String data[] = {setParamString(modelParNum, modelParam)};
        if(data[0] == null){
            return null;
        }
        return data;
    }
    
    /**
     * This method is called when the update/save button in the simulation tab is pressed.
     * When the button says "Update" and it's pressed, it sends data with the updated values of the parameters and trigger fields to the controller.
     * if an error occurs while sending the data, it is assumed that there is a problem in the ethernet connection to the controller - a message pop up
     * window is displayed and the simulation is stopped.
     * When the button says "Save data" or "Saved" and it's pressed, a method is invoked to save the data collected in the graph.
     * @param evt the ActionEvent fired when the button wsa pressed.
     */    
    private void sUpdateOrSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sUpdateOrSaveActionPerformed
        switch(sUpdateOrSave.getText()){
            case "Update":{
                if(!simuRTG.bUSM.update(updateSimuPars())){
                    JOptionPane.showMessageDialog(null, "Problem updating the parameters/trigger.\nTry checking the Eth. connection to the controller\n"
                            + "and press the \"connect\" button.");
                    sStartOrStop.doClick();
                    sStartOrStop.doClick();
                }
                break;
            }
            case "Saved":
            case "Save data":{
                if(saveSMSession(simuRTG)){
                    sUpdateOrSave.setText("Saved");
                }
                break;
            }
        }
        
        
    }//GEN-LAST:event_sUpdateOrSaveActionPerformed

    /**
     * This method handles the saving procces for the simulation and measurements tabs.
     * If the user agrees to save and chooses a valid path to save, a tab-separated file is created, and all the values
     * from the begining of the session are written to that file, including the time calculated in the controller.
     * @param rtg the graph from which to save the data (simulation/measurements).
     * @return True if the save operation was successful, False otherwise.
     */
    public boolean saveSMSession(RealTimeGraph_SimuModel rtg){
        String saveFile;
        switch(JFC.showSaveDialog(null)){
            case JFileChooser.APPROVE_OPTION:{
                saveFile = JFC.getSelectedFile().getPath();
                File save = new File(saveFile);
                if(save.exists()){
                    int choice = JOptionPane.showConfirmDialog(null, "File already exists!\nOverwrite?");
                    switch(choice){
                        case JOptionPane.YES_OPTION:
                            break;
                        default:
                            return false;
                    }
                }
                long j=0;
                try (BufferedWriter bW = new BufferedWriter(new FileWriter(save))) {
                    bW.write("Time[us]\tY0\tY1\tY2\tY3\tY4\tY5"+System.lineSeparator());
                    while(!rtg.fifo.isEmpty()){
                        double[] temp = rtg.fifo.pollLast();
                        for(int i=0; i<temp.length; i++){
                            bW.write(Double.toString(temp[i]));
                            bW.append('\t');
                        }
                        bW.newLine();
                    }
                    System.out.println("Saved stack data to: " + save.getPath());
                }
                catch(IOException ioex){
                    System.err.println("saveMonitorSession: Problem: " + ioex);
                    popUpErrorMessage("Problem saving the session data to file: " + saveFile);
                    return false;
                }
                return true;
            }
            case JFileChooser.CANCEL_OPTION:{
                return false;
            }
            default: return false;
        }
    }
    
    /**
     * This method handles the saving procces for the monitor tab.
     * If the user agrees to save and chooses a valid path to save, a tab-separated file is created, and all the values
     * from the begining of the session are written to that file.
     * @param rtg the graph from which to save the data (monitor).
     * @return True if the save operation was successful, False otherwise.
     */
    public boolean saveMonitorSession(RealTimeGraph_Monitor rtg){
        String saveFile;
        switch(JFC.showSaveDialog(null)){
            case JFileChooser.APPROVE_OPTION:{
                saveFile = JFC.getSelectedFile().getPath();
                File save = new File(saveFile);
                if(save.exists()){
                    int choice = JOptionPane.showConfirmDialog(null, "File already exists!\nOverwrite?");
                    switch(choice){
                        case JOptionPane.YES_OPTION:
                            break;
                        default:
                            return false;
                    }
                }
                long j=0;
                
                try (BufferedWriter bW = new BufferedWriter(new FileWriter(save))) {
                    bW.write("Time[us]\tA0\tA1\tA2\tA3\tA4\tA5"+System.lineSeparator());
                    while(!rtg.fifo.isEmpty()){
                        double[] temp = rtg.fifo.pollLast();
                        for(int i=0; i<temp.length; i++){
                            if(i!=0){ temp[i] = temp[i] * 5 / 4096;}
                            bW.write(Double.toString(temp[i]));
                            bW.append('\t');
                        }
                        bW.newLine();
                    }
                    System.out.println("Saved stack data to: " + save.getPath());
                }
                catch(IOException ioex){
                    System.err.println("saveMonitorSession: Problem: " + ioex);
                }
                return true;
            }
            case JFileChooser.CANCEL_OPTION:{
                return false;
            }
            default: return false;
        }
    }
    
    /**
     * This method is called when the connect/stop button is pressed in the monitor tab.
     * When the button says "Connect" and it's pressed, the method will offer to save data from previous session (if it exists),
     * and will start a new monitor session (by calling a sub-method).
     * When the button says "Stop" and it's pressed, the method stops the seesion and closes the server connection.
     * @param evt the ActionEvent fired when the button is pressed.
     */
    private void monitorConnectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monitorConnectActionPerformed
        switch(monitorConnect.getText()){
            case "Connect":{
                if((monitorSaveBut.isVisible())&&(monitorSaveBut.getText().equals("Save"))){
                    int save = JOptionPane.showConfirmDialog(null, "Would you like to save\nthe previous monitor session?");
                    if(save == JOptionPane.YES_OPTION){
                        saveMonitorSession(monitorRTG);
                    }
                    else if(save == JOptionPane.CANCEL_OPTION){
                        return;
                    }
                }
                restartMonitorSession();
                break;
            }
            case "Stop":{
                monitorSaveBut.setVisible(true);
                monitorSaveBut.setText("Save");
                monitorConnect.setText("Connect");
                closeServerCon_GUI(2); // 2 = tab number of monitor tab
                break;
            }
        }
    }//GEN-LAST:event_monitorConnectActionPerformed

    /**
     * This method is called to restart the monitor session.
     * The data stored from previous session is cleared, and the method which starts the monitor session is called.
     */
    private void restartMonitorSession(){
        monitorRTG.clearSetsAndFIFO();
        monitorSaveBut.setVisible(false);
        monitorTabUI();
    }
    
    /**
     * This method is called when the save button is pressed in the monitor tab.
     * It invokes the saveMonitorSession method to save the data from the session.
     * @param evt the ActionEvent fired when the button is pressed.
     */
    private void monitorSaveButActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monitorSaveButActionPerformed
        if(saveMonitorSession(monitorRTG)){
            monitorSaveBut.setText("Saved"); 
        }
    }//GEN-LAST:event_monitorSaveButActionPerformed

    /**
     * This method handles the saving of a code to a stored list in the app and adding it to the "Select Code" options,
     * in both the simulation and measurements tabs.
     * @param evt the ActionEvent fired when selecting the "Add new code to stored codes...".
     */
    private void addCodeToListOptionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addCodeToListOptionActionPerformed
        String[] choice = {"Only simulation","Only measurements","Both"};
        String question = "Would like to store the code in the simulation list, the measurements list, or both?";
        String title = "Where to save";
        
        int jopChoice = JOptionPane.showOptionDialog(null, question, title, JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, choice, choice[2]);
        if(jopChoice == JOptionPane.CLOSED_OPTION){return;}
        
        if(JFC.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
            String fileToStore = JFC.getSelectedFile().getPath();
            final String check = fileToStore;
            if(!fileToStore.endsWith(".ino")){
                popUpErrorMessage("The selected source file must have an \".ino\" extension");
                return;
            }
            switch(jopChoice){
                case 0: {
                    String[] foundMatch = storedSimuCodes.values().stream().filter((val) -> {
                        return val.endsWith(check.substring(check.lastIndexOf('\\')));
                    }).toArray(size -> new String[size]);
                    if(foundMatch.length>0){
                        switch(JOptionPane.showConfirmDialog(null, "File with the same name is already stored!\n"
                                                            + "Would you like to overwrite the file?")){
                            case JOptionPane.YES_OPTION:
                                handleFoundMatch(storedSimuCodes, foundMatch);
                                break;
                            default:
                                return;
                        }
                    }
                    fileToStore = copyCode(fileToStore);
                    storeCodeInList(storedSimuCodes, fileToStore);
                    loadListToCodeTypeChoose(sCodeTypeChoose, storedSimuCodes);
                    saveCodeToListFile(storedSimuCodes, miscPath + simuStoredList);
                    break;
                }
                case 1: {
                    String[] foundMatch = storedModelCodes.values().stream().filter((val) -> {
                        return val.endsWith(check.substring(check.lastIndexOf('\\')));
                    }).toArray(size -> new String[size]);
                    if(foundMatch.length>0){
                        switch(JOptionPane.showConfirmDialog(null, "File with the same name is already stored!\n"
                                                            + "Would you like to overwrite the file?")){
                            case JOptionPane.YES_OPTION:
                                handleFoundMatch(storedModelCodes, foundMatch);
                                break;
                            default:
                                return;
                        }
                    }
                    fileToStore = copyCode(fileToStore);
                    storeCodeInList(storedModelCodes, fileToStore);
                    loadListToCodeTypeChoose(mCodeTypeChoose, storedModelCodes);
                    saveCodeToListFile(storedModelCodes, miscPath + modelStoredList);
                    break;
                }
                case 2: {
                    boolean dontSaveToSimu = false;
                    boolean dontSaveToModel = false;
                    String[] sfoundMatch = storedSimuCodes.values().stream().filter((val) -> {
                        return val.endsWith(check.substring(check.lastIndexOf('\\')));
                    }).toArray(size -> new String[size]);
                    String[] mfoundMatch = storedModelCodes.values().stream().filter((val) -> {
                        return val.endsWith(check.substring(check.lastIndexOf('\\')));
                    }).toArray(size -> new String[size]);
                    if(sfoundMatch.length>0){
                        switch(JOptionPane.showConfirmDialog(null, "File with the same name is already stored in the simulation list!\n"
                                                            + "Would you like to overwrite the file?")){
                            case JOptionPane.YES_OPTION:
                                handleFoundMatch(storedSimuCodes, sfoundMatch);
                                break;
                            case JOptionPane.NO_OPTION:
                                dontSaveToSimu = true;
                                break;
                            default:
                                return;
                        }                        
                    }
                    if(mfoundMatch.length>0){
                        switch(JOptionPane.showConfirmDialog(null, "File with the same name is already stored in the measurements list!\n"
                                                            + "Would you like to overwrite the file?")){
                            case JOptionPane.YES_OPTION:
                                handleFoundMatch(storedModelCodes, mfoundMatch);
                                break;
                            case JOptionPane.NO_OPTION:
                                dontSaveToModel = true;
                                break;
                            default:
                                return;
                        }                        
                    }
                    
                    if(dontSaveToModel&&dontSaveToSimu){
                        break;
                    }
                    else if(dontSaveToModel){
                        fileToStore = copyCode(fileToStore);
                        storeCodeInList(storedSimuCodes, fileToStore);
                        loadListToCodeTypeChoose(sCodeTypeChoose, storedSimuCodes);
                        saveCodeToListFile(storedSimuCodes, miscPath + simuStoredList);
                    }
                    else if(dontSaveToSimu){
                        fileToStore = copyCode(fileToStore);
                        storeCodeInList(storedModelCodes, fileToStore);
                        loadListToCodeTypeChoose(mCodeTypeChoose, storedModelCodes);
                        saveCodeToListFile(storedModelCodes, miscPath + modelStoredList);
                    }
                    
                    else{
                        fileToStore = copyCode(fileToStore);
                        storeCodeInBothLists(fileToStore);
                        loadListToCodeTypeChoose(sCodeTypeChoose, storedSimuCodes);
                        loadListToCodeTypeChoose(mCodeTypeChoose, storedModelCodes);
                        saveCodeToListFile(storedSimuCodes, miscPath + simuStoredList);
                        saveCodeToListFile(storedModelCodes, miscPath + modelStoredList);
                    }
                    break;
                }
                default: 
            }   
        }
    }//GEN-LAST:event_addCodeToListOptionActionPerformed

    /**
     * This method is called when the user selects the "exit" menu item for the File menu.
     * It calls a method which varifies the user of unsaved changes and offers to save them, and then exits the app.
     * @param evt the <code>ActionEvent</code> fired when the "exit" menu item is selected
     */
    private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
        offerToSaveChangesBeforeExit();
    }//GEN-LAST:event_exitMenuItemActionPerformed

    /**
     * This method removes found matches to a specified file in the stored list of code labels and pathes, in order overwrite the files,
     * and delete the old labels.
     * @param storedList the <code>Map(String,String)</code> containing the existing codes' labels and pathes.
     * @param file the <code>String[]</code> array containing the found matches in the stored list that need to be removed.
     */
    private void handleFoundMatch(Map<String,String> storedList, String[] file){
        
        for(String string : file){
            for(Iterator<Map.Entry<String,String>> it = storedList.entrySet().iterator(); it.hasNext();){
                Map.Entry<String,String> entry = it.next();
                if(entry.getValue().equals(string)){
                    it.remove();
                }
            }
        }
    }
    
    /**
     * This method saves the added code to the passed list.<br>
     * It is called from the {@link #addCodeToListOptionActionPerformed(java.awt.event.ActionEvent) addCodeToListOptionActionPerformed} method.
     * @param storedCodes the <code>Map(String,String)</code> to which store the code and it's label. 
     * @param fileToStore the <code>String</code> containing the path of the code's file.
     */
    private void storeCodeInList(Map<String,String> storedCodes, String fileToStore){
        String codeLabel = JOptionPane.showInputDialog(null, "What is the label of the code?", "code " + storedCodes.size());
        if(codeLabel == null){
            (new File(fileToStore)).delete();
            return;
        }
        while(storedCodes.containsKey(codeLabel)){
            popUpErrorMessage("code label already exists in the simulation list!\nChoose another label.");
            codeLabel = JOptionPane.showInputDialog(null, "What is the label of the code?", "code " + storedCodes.size());
            if(codeLabel == null){
                (new File(fileToStore)).delete();
                return;
            }
        }
        storedCodes.put(codeLabel, fileToStore);
    }
    
    /**
     * This method copies the file located in the passed path to an internal directory in the app's dir.
     * @param fileToStore the path of the original file to copy.
     * @return String containing the path of the copied file.
     */
    private String copyCode(String fileToStore){
        File orig = new File(fileToStore);
        String origName = orig.getName();
        String copyDirPath = storedCodes + "\\" + origName.substring(0, origName.indexOf(".ino"));
        String copyPath = copyDirPath + "\\" + origName;
        File copyDir = new File(copyDirPath);
        copyDir.mkdir();
        File copy = new File(copyPath);
        try{
            if(!copy.exists()){copy.createNewFile();}
            else{copy.delete(); copy.createNewFile();}
            Files.copy(orig.toPath(), copy.toPath(), REPLACE_EXISTING);
        }
        catch(IOException ioex){
            System.err.println("copyCode: problem:" + ioex);
        }
        return copyPath;
    }
    
    /**
     * This method save the selected code path and label to a file.
     * @param storedList the <code>Map(String, String)</code> containing the codes' labels and pathes.
     * @param listFile the path of the file containing the list of codes.
     */
    private void saveCodeToListFile(Map<String,String> storedList, String listFile){
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(new File(listFile)))) {
            bw.write("Label\tPath" + System.lineSeparator());
            storedList.entrySet().stream().forEach((entry) -> {
                try{bw.write(entry.getKey() + "\t" + entry.getValue() + System.lineSeparator());}
                catch(IOException ioex){System.err.println("storeCodeInList: problem: " + ioex);}
            });
        }
        catch(IOException ioex){
            System.err.println("storeCodeInList: problem: " + ioex);
        }
    }
    
    /**
     * This method saves the added code to both existing lists - simulation and measurements.<br>
     * It is called from the addCodeToListOptionActionPerformed method.
     * @param fileToStore the String containing the path of the code's file.
     */
    private void storeCodeInBothLists(String fileToStore){
        String codeLabel = JOptionPane.showInputDialog(null, "What is the label of the code?");
        while((storedSimuCodes.containsKey(codeLabel))||(storedModelCodes.containsKey(codeLabel))){
            popUpErrorMessage("code label already exists in one of the lists!\nChoose another label.");
            codeLabel = JOptionPane.showInputDialog(null, "What is the label of the code?");
        }
        storedSimuCodes.put(codeLabel, fileToStore);
        storedModelCodes.put(codeLabel, fileToStore);
    }
    
    /**
     * This method invokes a sub-method to set 2 string lines containing the parameters values and the trigger values, 
     * and then returns an array containing both lines.
     * This is called in the simulation tab.
     * @return String array containing the parameters values line and the trigger values line.
     */
    private String[] updateSimuPars(){
        String data[] = {setTriggerString(), setParamString(simuParNum, simuParam)};
        if((data[0] == null)||(data[1] == null)){
            return null;
        }
        System.out.println("update Simu data: \n1. " + data[0] + "\n2. " + data[1]);
        return data;
    }
    
    /**
     * This method sets the parameters values string line and returns it.
     * The method is called both in the simulation and measurements tabs when the update button is pressed.
     * It reads the values from the param text field passed to it and adds to the overall string.
     * If one of the values read, is invalid, then an error window will appear stating which parameters not a valid number.
     * @param parNum the number of parameters available
     * @param param the JTextField from which to read the values.
     * @return String containing the parameters values.
     */
    private String setParamString(int parNum, JTextField param[]){
        String paramString = "K";
        String errorPars = "";
        for(int i=0; i < parNum; i++){
            String par = param[i].getText().trim();
            if(checkIfNumber(par)){
                par = Double.toString(Double.parseDouble(par));
                paramString += (par + " ");
            }
            else{
                errorPars += ("Parameter " + Integer.toString(i+1) + " \n");
            }
        }
        
        if(errorPars.length() != 0){
            popUpErrorNumber(errorPars);
            return null;
        }
        
        System.out.println("ParNum is: " + parNum + "\nParamString is: " + paramString);
        return paramString;
    }
    
    /**
     * This method checks if the passed string can be parsed as double type number.
     * @param s the string to check
     * @return True if the string passed can be parsed as Double, False otherwise.
     */
    private boolean checkIfNumber(String s){
        try{
            Double.parseDouble(s);
        }
        catch(NumberFormatException nfe){
            return false;
        }
        return true;
    }

    /**
     * This method starts up the server connection to the controller during the monitor session, as well 
     * as the background update of the graph.
     * @return true if the connection was successful, false otherwise.
     */
    private boolean connectAndMonitor(){
        if(monitorRTG.bUM.startMonitor(monChannels)){
            monitorRTG.startBackgroundUpdate();
            System.out.println("connectAndMonitor: returning true");
            return true;
        }
        return false;
    }
    
    /**
     * This method sets the duty cycle label, value, and unit label visible/invisible, based on the Boolean argument passed.
     * @param setVis the Boolean argument passed - True to show the duty cycle, False to hide.
     */
    private void setDutyCycVisible(boolean setVis){
        dutyCycle.setVisible(setVis);
        dutyCycleVal.setVisible(setVis);
        dutyCyclePercent.setVisible(setVis);
    }
    
    /**
     * This is the main method of the app.
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(IGG.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new IGG().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem addCodeToListOption;
    private javax.swing.JLabel ampUnits;
    private javax.swing.JTextField ampVal;
    private javax.swing.JLabel amplitude;
    private javax.swing.JLabel dcOffset;
    private javax.swing.JLabel dcOffsetUnit;
    private javax.swing.JTextField dcOffsetVal;
    private javax.swing.JLabel duration;
    private javax.swing.JLabel durationUnit;
    private javax.swing.JTextField durationVal;
    private javax.swing.JLabel dutyCycle;
    private javax.swing.JLabel dutyCyclePercent;
    private javax.swing.JTextField dutyCycleVal;
    private javax.swing.JMenuItem exitMenuItem;
    private javax.swing.JMenu file;
    private javax.swing.JLabel infMessageDuration;
    private javax.swing.JPanel mButtonsPanel;
    private javax.swing.JComboBox mCodeTypeChoose;
    private javax.swing.JPanel mSketchChoosePanel;
    private javax.swing.JTextField mSketchPath;
    private javax.swing.JButton mStartOrStop;
    private javax.swing.JButton mUpdateOrSave;
    private javax.swing.JMenuBar mainMenu;
    private javax.swing.JPanel measurments;
    private javax.swing.JLabel modelParCountLabel;
    private javax.swing.JLabel modelParCountMaxLabel;
    private javax.swing.JPanel modelParamCount;
    private javax.swing.JSpinner modelParamNum;
    private javax.swing.JPanel model_TACT_RTG_panel;
    private javax.swing.JCheckBox monChannel1;
    private javax.swing.JCheckBox monChannel2;
    private javax.swing.JCheckBox monChannel3;
    private javax.swing.JCheckBox monChannel4;
    private javax.swing.JCheckBox monChannel5;
    private javax.swing.JCheckBox monChannel6;
    private javax.swing.JPanel monitor;
    private javax.swing.JButton monitorConnect;
    private javax.swing.JPanel monitorRTGpanel;
    private javax.swing.JButton monitorSaveBut;
    private javax.swing.JLabel numOfChannels;
    private javax.swing.JMenu options;
    private javax.swing.JPanel paramPanelModel;
    private javax.swing.JPanel paramPanelSimu;
    private javax.swing.JLabel period;
    private javax.swing.JLabel periodUnit;
    private javax.swing.JTextField periodVal;
    private javax.swing.JPanel sButtonsPanel;
    private javax.swing.JComboBox sCodeTypeChoose;
    private javax.swing.JPanel sSketchChoosePanel;
    private javax.swing.JTextField sSketchPath;
    private javax.swing.JButton sStartOrStop;
    private javax.swing.JButton sUpdateOrSave;
    private javax.swing.JLabel selectModelLabel;
    private javax.swing.JLabel selectSimuLabel;
    private javax.swing.JLabel simuParCountLabel;
    private javax.swing.JLabel simuParCountMaxLabel;
    private javax.swing.JPanel simuParamCount;
    private javax.swing.JSpinner simuParamNum;
    private javax.swing.JPanel simu_TACT_RTG_panel;
    private javax.swing.JPanel simulation;
    private javax.swing.JTabbedPane tabPanel;
    private javax.swing.JLabel timeRes;
    private javax.swing.JLabel timeResUnit;
    private javax.swing.JTextField timeResVal;
    private javax.swing.JPanel triggerPanel;
    private javax.swing.JLabel triggerShape;
    private javax.swing.JComboBox triggerShapeChoose;
    // End of variables declaration//GEN-END:variables
    //////////////// Another variable declaration //////////////////////////////
    /// Trigger fields ///
    /** 
     * Field used for the trigger. <br>
     * These fields are the following: <p>
     * dur - the duration of the simulation - unused. <br>
     * res - the time resolution of the simulation (microseconds).<br>
     * amp - the amplitude of the trigger (millivots). <br>
     * cyc - the period of the trigger (microseconds). <br>
     * dcOff - the DC offset of the trigger (millivolts). <br>
     * dutyCyc - the duty cycle in the case of a Pulse Train wave (%). <br>
     */
    String dur, res, amp,cyc, dcOff, dutyCyc;
    /** Specifies the trigger type. <br>
     * can be: <p>
     * P - pulse train <br>
     * T - triangular wave <br>
     * S - sine wave <br>
     * R - ramp wave <br>
     */
    private char trigTyp = 'P';
    ///////////////////////
    /// Pathes ////////////
    /** The path of the Misc folder in the app's directory (".\\src\\Misc") */ 
    private final String miscPath = ".\\src\\Misc";
    /** The path of the folder which contains the app's stored codes (".\\src\\Misc\\storedCode") */
    private final String storedCodes = miscPath + "\\storedCodes";
    /** The path of the preferences file (".\\src\\PrjGui\\prefsettings.txt") */
    private final String settingsPath = ".\\src\\PrjGui\\prefSettings.txt";  
    /** The path of the simulation template file (".\\src\\Misc\\simulTemplate\\simulTemplate.ino") */
    private final String simuTemplatePath  = "\\simulTemplate\\simulTemplate.ino"; 
    /** The path of the measurements template file (".\\src\\Misc\\modelTemplate\\modelTemplate.ino") */
    private final String modelTemplatePath = "\\modelTemplate\\modelTemplate.ino";
    /** The path of the monitor template file (".\\src\\Misc\\monitorSketch\\monitorSketch.ino") (unused) */
    private final String monitorSketchPath = "\\monitorSketch\\monitorSketch.ino";
    /** The pLink executeable (".\\src\\Misc\\pLink.exe") */
    private final String plinkExe = "\\plink.exe";
    /** The batch which shows the output log of the compile/download process when errors occur (".\\src\\Misc\\exitQuest.bat") */
    private final String exitQuest = "\\exitQuest.bat";
    /** The batch which calls the download to the board (".\\src\\Misc\\uploadBatch.bat") */
    private final String uploadBatch = "\\uploadBatch.bat";
    /** The text log of the compile and download process (".\\src\\Misc\\uploadLog.txt") */
    private final String uploadLog = "\\uploadLog.txt";  
    /** The text file which stores the list of simulation stored codes (".\\src\\Misc\\listOfSimus.txt") */
    private final String simuStoredList = "\\listOfSimus.txt";
    /** The text file which stores the list of measurements stored codes (".\\src\\Misc\\listOfModels.txt") */
    private final String modelStoredList = "\\listOfModels.txt";
    ////////////////////////////////////////////////////
    /// Graph instantiation ///
    /** Stores the previous tab index to tell the app which tab session to close so it won't interfere with a new session */
    private int previousTab = 0;
    /** The graph of the Monitor tab */
    private RealTimeGraph_Monitor monitorRTG;
    /** The graph of the simulation (simu) or measurements (model) tabs*/
    private RealTimeGraph_SimuModel simuRTG, modelRTG;
    /** Contains the graph of the simulation/measurements tabs */
    private JPanel simuRTGpanel, modelRTGpanel;
    //////////////////////////////////////////
    /// Various ///
    /** A welcome string which appears as initial text in the code text area when the app is run */
    private String codeTextRec;
    /** Used for all the loading and saving cases in the app */
    private final JFileChooser JFC;
    /** describes which channel is shown and which is not in the Monitor tab*/
    private int monChannels[] = {1,0,0,0,0,0};
    /** Initial path text in simulation tab */
    private String selSimuPath = "New Code";
    /** Initial path text in measurements tab */
    private String selModelPath = "New Code";
    /** flag to determine whether it's the first time the simulation tab is 
     * switched to (including on startup and buildup)*/
    private boolean isFirstTimeTab;
    ///////////////////////////////////////////////////
    /// Parameters for simulation and measurements ////
    /** The number of shown parameters */
    private int modelParNum = 1;
    /** The number of shown parameters */
    private int simuParNum = 1;
    /** The input field for the value of the parameters */
    private JTextField[] modelParam, simuParam;
    /** The labels of the parameters ("Param 1:", "Param 2:",...) */
    private JLabel[] modelParamL, simuParamL;
    /** The input fields for the label of the paramters (set by the user) */
    private JTextField[] modelParamN, simuParamN;
    /** The Panel containing the parameters */
    private JPanel[] modelParPanel, simuParPanel;
    //////////////////////////////////////////////////////
    ////// Sketch Upload and setup settings vars. declaration /////
    /** 
     * Holds one of the details needed to the app the compile and download the sketch. <br>
     * These details are:<p>
     * board - the board type<br>
     * comPort - the COM# assigned to the board<br>
     * idePath - the path of the Arduino IDE<br>
     * hostName - the IP address of the board<p>
     * These fields are loaded from the preference file.
     */
    private String board, comPort, idePath, hostName;
    ////////////////////////////////////////////////////////////////
    ////// Template Reading vars. declaration //////
    /** Used for reading the template code in the simulation (simu) or measurements (model) tabs*/
    private FileReader simuTempReader, modelTempReader;
    /////////////////////////////////////////////////////////////////
    ////// Popup Window vars. declaration //////
    /** used in the popup window*/
    private JDialog loading;
    /** the popup window every time the app downloads code to the board or when it turns the monitor sketch on */
    private JPanel loadingPanel;
    /** the title of the popup window */
    private JLabel pwLabel;
    /** used when the app turns the monitor sketch on */
    SwingWorker<Boolean, Void> swMonitorStart;
    /** used when the app compiles and downloads simulation (simu) or measurements (model) code to the board */
    SwingWorker<Integer, Void> swSimuStart, swModelStart;
    //////////////////////////////////////////////////////////////////
    ////// Template and Code Text Area / Real Time Graph and labels declaration //////
    /** Identifier for the code text and template text panel */
    private final String TACT = "TACT panel";
    /** Identifier for the graph panel */
    private final String RTG = "RTG panel";
    /** Contains: "Channels to display: " */
    private final String chanDisp = "Channels to display: ";
    ///////////////////////////////////////////////////////////////////
    /// Simulation and Measurements Tab ///////////////
    /** The split panel which splits the user's code and the template panels in the simulation (simu) and measurements (model) tabs */
    private JSplitPane simuSplitPane, modelSplitPane;
    /** Contains the text panel of the user's code in the simulation (s) and measurements (m) tabs */
    private JScrollPane sCodeAreaScrollPane, mCodeAreaScrollPane;
    /** Contains the text panel of the template code in the simulation (s) and measurements (m) tabs */
    private JScrollPane sTempTextAreaScrollPane, mTempTextAreaScrollPane;
    /** Contains the channels' checkboxes in the simulation ((s) and measurements (m) tabs */
    private JPanel sChanPanel, mChanPanel;
    /** Contains both text areas (user's code and template) in the simulation (s) and measurements (m) tabs */
    private JPanel sTextAreaCT_panel, mTextAreaCT_panel;
    /** Contains the user code text panel along with its label in the simulation (s) and measurements (m) tabs */
    private JPanel sCodePanel, mCodePanel;
    /** Contains the template code text panel along with its label in the simulation (s) and measurements (m) tabs */
    private JPanel sTemplatePanel, mTemplatePanel;
    /** Contains the labels of the user code text in the simulation (s) and measurements (m) tabs */
    private JPanel sCodeLabelPanel, mCodeLabelPanel;
    /** the text area of the user code in the simulation (s) and measurements (m) tabs */
    private JTextArea sCodeArea, mCodeArea;
    /** the text area of the template code in the simulation (s) and measurements (m) tabs */
    private JTextPane sTempTextPane, mTempTextPane;
    /** the label of the template text in the simulation (simu) and measurements (model) tabs */
    private JLabel simuTempLabel, modelTempLabel;
    /** the label of the user's code - the name of the file loaded or the stored label in the simulation (s) and measurements (m) tabs */
    private JLabel sCodeNameLabel, mCodeNameLabel;
    /** the "Selected Code: " label in the simulation (s) and measurements (m) tabs */
    private JLabel sSelCodeLabel, mSelCodeLabel;
    /** the Channels to display: " label in the simulation (s) and measurements (m) tabs */
    private JLabel sChanDispLabel, mChanDispLabel;
    /** the channels' checkboxes in the simulation (s) and measurements (m) tabs */
    private JCheckBox sChannel[], mChannel[];
    /** A flag to idicate whether changes were made to the user code through the text in the app in the simulation (simu) and measurements (model) tabs */
    private boolean isSimuCodeChanged, isModelCodeChanged;
    //////////////////////////////////
    //////////////////////////////////////////////////////////////
    /** The list which stores the codes in the app, for the simulation (simu) and measurements (model) tabs. <br>
     * The key is a string with the label given to the code.<br>
     * The value is a string with the path of the code in the app's folder.<br>
     */
    private Map<String,String> storedSimuCodes, storedModelCodes; // first string is name, second is path.
    // End of another variable declaration
}

/**
 * This Class is an action listener for the checkBoxes in the simu/model tabs.
 * It updates the number of channels shown according to the checkboxes checked.
 * @author Gil Aizenshtadt
 */
class checkBoxListener implements ActionListener{
    /** The index of the checkbox in the array. */
    private final int i; 
    /** The graph in which the channels should be updated. */
    private final RealTimeGraph_SimuModel rtg; 
    /** The array of checkboxes. */
    private final JCheckBox channels[]; 
    

    /**
     * This constructor instantiates an instance of the class with the variables' values according the check box it belongs to.
     * @param i the number of the channel the intance belongs to.
     * @param rtg the graph - can be from the simulation or the measurements.
     * @param channels the JCheckBox array describing the channels (can from simu. of meas.).
     */
    public checkBoxListener(int i, RealTimeGraph_SimuModel rtg, JCheckBox channels[]){
        this.i = i;
        this.channels = channels;
        this.rtg = rtg;
    }
    
    /**
     * This method overrides the actionPerformed method of the ActionListener class.
     * It is called when the check box is checked/unchecked and updates the graph accordingly.
     * @param evt the ActionEvent fired when the checkbox is checked/unchecked.
     */
    @Override
    public void actionPerformed(ActionEvent evt){
        UpdatePlotNum.updatePlotNum(rtg.plot,rtg.subp,i,channels[i].isSelected());
        rtg.channels[i] = channels[i].isSelected() ? 1 : 0;
        rtg.restartBackgroundUpdate();
    }
    
}