#!/bin/sh

# clupload script to invoke lsz 
# Copyright (C) 2014 Intel Corporation
# 
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
# 
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
#

echo "starting download script"
echo "Args to shell:" $*

# ARG 1: Path to lsz executable.
# ARG 2: Script to download
# ARG 3: COM port to use.

#path contains \ need to change all to /
path_to_exe=$1
fixed_path=${path_to_exe//\\/\/}

#COM ports are not always setup to be addressed via COM for redirect.
#/dev/ttySx are present. Howwever, COMy -> /dev/ttySx where x = y - 1

com_port_arg=$3
com_port_id=${com_port_arg/COM/}
echo "COM PORT" $com_port_id
tty_port_id=/dev/ttyS$((com_port_id-1))
echo "Converted COM Port" $com_port_arg "to tty port" $tty_port_id

echo "Sending Command String to move to download if not already in download mode"
echo "~sketch downloadGalileo" > $tty_port_id

#Download the file.
host_file_name=$2
host_file_name=${host_file_name//\\/\/}
"$fixed_path/lsz.exe" --escape --binary --overwrite $host_file_name <> $tty_port_id 1>&0

echo "~sketch downloadGalileo" > $tty_port_id
#mv the downloaded file to /sketch/sketch.elf 
target_download_name="${host_file_name##*/}" 
#echo $target_download_name
#echo $host_file_name
#echo $fixed_path
#echo "Moving downloaded file to /sketch/monitorSketch.elf on target"
"$fixed_path/lsz.exe" --escape -c "tr -d '\015' <$target_download_name >/netcon.sh; mv /netcon.sh /etc/init.d/netcon.sh; chmod +x /etc/init.d/netcon.sh" <> $tty_port_id 1>&0
###
# Symbolically linking the script to start
echo "~sketch downloadGalileo" > $tty_port_id
"$fixed_path/lsz.exe" --escape -c "ln -s /etc/init.d/netcon.sh /etc/rc2.d/S99netcon.sh; ln -s /etc/init.d/netcon.sh /etc/rc3.d/S99netcon.sh; ln -s /etc/init.d/netcon.sh /etc/rc4.d/S99netcon.sh" <> $tty_port_id 1>&0
echo "~sketch downloadGalileo" > $tty_port_id
"$fixed_path/lsz.exe" --escape -c "ln -s /etc/init.d/netcon.sh /etc/rc5.d/S99netcon.sh; ln -s /etc/init.d/netcon.sh /etc/rc6.d/S99netcon.sh" <> $tty_port_id 1>&0
###
# Symbolically linking the script to stop
echo "~sketch downloadGalileo" > $tty_port_id
"$fixed_path/lsz.exe" --escape -c "ln -s /etc/init.d/netcon.sh /etc/rc1.d/K99netcon.sh; bash /etc/init.d/netcon.sh start" <> $tty_port_id 1>&0

