#! /bin/sh
###BEGIN INIT INFO
#Provides: net_con
# Should-Start: console-screen dbus network-manager
# Required-Start: $all
# Required-Stop: $all
# Default-Start: 2 3 4 5
# Default-Stop: 0 1 6
# Short-Description: start net_con at boot time
###END INIT INFO
#

case "$1" in
start)
	telnetd -l /bin/sh
	ifconfig eth0 169.254.1.5 netmask 255.255.0.0 up
	;;
stop)
	;;
esac

exit 0
