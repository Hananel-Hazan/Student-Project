
import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import java.util.Arrays;
import java.util.concurrent.ExecutionException;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingWorker;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * This class is the setup app class.<p>
 * This app offers creating and saving a preference file for the main app with the following fields:<br>
 * - Arduino IDE path.<br>
 * - COM port - the COM PORT through which the controller is connected.<br>
 * - Board type - can be either Intel® Galileo or Intel® Galileo Gen2.<br>
 * - Host IP address - the address which will be set as the IP of the controller.<br>
 * - Netmask value - the netmask of the LAN to which the controller is connected.<br>
 * - Main app path.<p>
 * The app saves all the fields except the last two to a prefFile.txt<br>
 * in the main app's directory (the main app doesn't use them).<br>
 * The app also saves a backupPrefFile.txt in it's directory containing all the fields<br>
 * so the next time it is run if it finds the file, and loads the preferences saved.<p>
 * After validating all the fields and saving the prefFile, the app uploads two files<br>
 * to the controller through the USB:<br>
 * - A shell script which sets up the ethernet connection (inclunding embedding the script so it is run on startup).<br>
 * - A sketch for the monitor interface (monitorSketch.elf) so each time the app wants to monitor, it simply uses<br>
 *   the sketch found in the controller, instead of compiling and uploading it.<br>
 * @author Gil Aizenshtadt
 */
public class SIGG extends javax.swing.JFrame {

    /**
     * This contructor creates the app's window and initiates the 
     * popup "waiting" window while uploading files to the controller.
     */
    public SIGG() {
        initComponents();
        initComponentsManual();
        createPopupWindow("Setting up interfaces - please wait...");
    }

    /**
     * This method initiates the file chooser and reads the preferences from the 
     * backup file (if existent).
     */
    private void initComponentsManual(){
        jfc = new JFileChooser();
        jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        
        idePath = "";
        mainPath = "";
        comPort = "";
        
        File backup = new File(backupFilePath);
        String line;
        if(backup.exists()){
            try (BufferedReader br = new BufferedReader(new FileReader(backup))) {
                while((line = br.readLine()) != null){
                    String option = line.substring(0, line.indexOf("="));
                    String value = line.substring(line.indexOf("=")+1);
                    switch (option.trim()) {
                        case "ARDUINO_PATH":
                            idePath = value.trim();
                            idePathText.setText(idePath);
                            break;
                        case "COM_PORT":
                            comPort = value.substring(value.length()-1).trim();
                            comPortText.setText(comPort);
                            break;
                        case "BOARD":
                            boardType = value.trim();
                            switch (boardType) {
                                case "intel:i586-uclibc:izmir_fd":
                                    boardTypeChooser.setSelectedIndex(0);
                                    break;
                                case "intel:i586-uclibc:izmir_fg":
                                    boardTypeChooser.setSelectedIndex(1);
                                    break;
                            }
                            break;
                        case "HOST":
                            hostIP = value.trim();
                            ipText.setText(hostIP);
                            break;
                        case "NETMASK":
                            hostNetMask = value.trim();
                            netMaskText.setText(hostNetMask);
                            break;
                        case "APP_PATH":
                            mainPath = value.trim();
                            mainPathText.setText(mainPath);
                            break;
                        default: break;
                    }
                }
            }
            catch(IOException ioe){
                System.out.println("Problem finding or opening settings file:");
                System.err.println(ioe);
            }
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        guiPane = new javax.swing.JPanel();
        mainPanel = new javax.swing.JPanel();
        boardIpPanel = new javax.swing.JPanel();
        ipLabel = new javax.swing.JLabel();
        ipText = new javax.swing.JTextField();
        netMaskLabel = new javax.swing.JLabel();
        netMaskText = new javax.swing.JTextField();
        boardTypePanel = new javax.swing.JPanel();
        boardTypeLabel = new javax.swing.JLabel();
        boardTypeChooser = new javax.swing.JComboBox();
        comPortPanel = new javax.swing.JPanel();
        comPortLabel = new javax.swing.JLabel();
        comPortText = new javax.swing.JTextField();
        idePathPanel = new javax.swing.JPanel();
        idePathLabel = new javax.swing.JLabel();
        ideBrowseButton = new javax.swing.JButton();
        idePathText = new javax.swing.JTextField();
        ocPanel = new javax.swing.JPanel();
        okButton = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();
        mainPathPanel = new javax.swing.JPanel();
        mainPathLabel = new javax.swing.JLabel();
        mainPathText = new javax.swing.JTextField();
        mainBrowseButton = new javax.swing.JButton();
        welcomePanel = new javax.swing.JPanel();
        welcomeText1 = new javax.swing.JLabel();
        welcomeText2 = new javax.swing.JLabel();
        welcomeText3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("sIGG - Interface Setup for the IGG");
        setResizable(false);

        ipLabel.setText("Board IP:");

        ipText.setText("0.0.0.0");

        netMaskLabel.setText("Netmask:");

        netMaskText.setText("255.255.255.0");

        javax.swing.GroupLayout boardIpPanelLayout = new javax.swing.GroupLayout(boardIpPanel);
        boardIpPanel.setLayout(boardIpPanelLayout);
        boardIpPanelLayout.setHorizontalGroup(
            boardIpPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(boardIpPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ipLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ipText, javax.swing.GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(netMaskLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(netMaskText, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        boardIpPanelLayout.setVerticalGroup(
            boardIpPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(boardIpPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(boardIpPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ipLabel)
                    .addComponent(ipText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(netMaskLabel)
                    .addComponent(netMaskText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        boardTypeLabel.setText("Board:");

        boardTypeChooser.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Intel® Galileo", "Intel® Galileo Gen2" }));

        javax.swing.GroupLayout boardTypePanelLayout = new javax.swing.GroupLayout(boardTypePanel);
        boardTypePanel.setLayout(boardTypePanelLayout);
        boardTypePanelLayout.setHorizontalGroup(
            boardTypePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(boardTypePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(boardTypeLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(boardTypeChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        boardTypePanelLayout.setVerticalGroup(
            boardTypePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(boardTypePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(boardTypePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(boardTypeLabel)
                    .addComponent(boardTypeChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        comPortLabel.setText("COM port number:");

        javax.swing.GroupLayout comPortPanelLayout = new javax.swing.GroupLayout(comPortPanel);
        comPortPanel.setLayout(comPortPanelLayout);
        comPortPanelLayout.setHorizontalGroup(
            comPortPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(comPortPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(comPortLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(comPortText, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        comPortPanelLayout.setVerticalGroup(
            comPortPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, comPortPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(comPortPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comPortLabel)
                    .addComponent(comPortText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        idePathLabel.setText("Arduino IDE path:");

        ideBrowseButton.setText("Browse");
        ideBrowseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ideBrowseButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout idePathPanelLayout = new javax.swing.GroupLayout(idePathPanel);
        idePathPanel.setLayout(idePathPanelLayout);
        idePathPanelLayout.setHorizontalGroup(
            idePathPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(idePathPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(idePathLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(idePathText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ideBrowseButton)
                .addGap(24, 24, 24))
        );
        idePathPanelLayout.setVerticalGroup(
            idePathPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(idePathPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(idePathPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(idePathLabel)
                    .addComponent(ideBrowseButton)
                    .addComponent(idePathText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        okButton.setText("OK");
        okButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okButtonActionPerformed(evt);
            }
        });

        cancelButton.setText("Cancel");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ocPanelLayout = new javax.swing.GroupLayout(ocPanel);
        ocPanel.setLayout(ocPanelLayout);
        ocPanelLayout.setHorizontalGroup(
            ocPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ocPanelLayout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addComponent(okButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cancelButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        ocPanelLayout.setVerticalGroup(
            ocPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ocPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(ocPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(okButton)
                    .addComponent(cancelButton))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        mainPathLabel.setText("Main app path");

        mainBrowseButton.setText("Browse");
        mainBrowseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mainBrowseButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout mainPathPanelLayout = new javax.swing.GroupLayout(mainPathPanel);
        mainPathPanel.setLayout(mainPathPanelLayout);
        mainPathPanelLayout.setHorizontalGroup(
            mainPathPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPathPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(mainPathLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(mainPathText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(mainBrowseButton)
                .addGap(24, 24, 24))
        );
        mainPathPanelLayout.setVerticalGroup(
            mainPathPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPathPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(mainPathPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(mainPathLabel)
                    .addComponent(mainPathText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mainBrowseButton))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(mainPathPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ocPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(idePathPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(comPortPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(boardTypePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(boardIpPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(mainPathPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(idePathPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(comPortPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(boardTypePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(boardIpPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(ocPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        welcomeText1.setText("This app creates the preferences which the main app will use.");

        welcomeText2.setText("It also sets the network and monitor interfaces on the controller.");

        welcomeText3.setText("Please specify the following required details.");

        javax.swing.GroupLayout welcomePanelLayout = new javax.swing.GroupLayout(welcomePanel);
        welcomePanel.setLayout(welcomePanelLayout);
        welcomePanelLayout.setHorizontalGroup(
            welcomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(welcomePanelLayout.createSequentialGroup()
                .addGroup(welcomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(welcomeText1)
                    .addComponent(welcomeText3)
                    .addComponent(welcomeText2))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        welcomePanelLayout.setVerticalGroup(
            welcomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(welcomePanelLayout.createSequentialGroup()
                .addComponent(welcomeText1)
                .addGap(5, 5, 5)
                .addComponent(welcomeText2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(welcomeText3)
                .addGap(0, 11, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout guiPaneLayout = new javax.swing.GroupLayout(guiPane);
        guiPane.setLayout(guiPaneLayout);
        guiPaneLayout.setHorizontalGroup(
            guiPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(guiPaneLayout.createSequentialGroup()
                .addGroup(guiPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(guiPaneLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(welcomePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        guiPaneLayout.setVerticalGroup(
            guiPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(guiPaneLayout.createSequentialGroup()
                .addComponent(welcomePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(mainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(guiPane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(guiPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * This method handles the directory choosing for the IDE path.
     * @param evt the ActionEvent fired when the "browse" button is hit.
     */
    private void ideBrowseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ideBrowseButtonActionPerformed
        if(jfc.showDialog(null, "Select")==JFileChooser.APPROVE_OPTION){
            idePath = jfc.getSelectedFile().getPath();
            idePathText.setText(idePath);
        }
    }//GEN-LAST:event_ideBrowseButtonActionPerformed

    /**
     * This method exits the app when the "cancel" button is hit.
     * @param evt the ActionEvent fired when the "cancel" button is hit.
     */
    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
        System.exit(0);
    }//GEN-LAST:event_cancelButtonActionPerformed

    /**
     * This method handles the directory choosing for the main app path.
     * @param evt the ActionEvent fired when the "browse" button is hit.
     */
    private void mainBrowseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mainBrowseButtonActionPerformed
        if(jfc.showDialog(null, "Select")==JFileChooser.APPROVE_OPTION){
            mainPath = jfc.getSelectedFile().getPath();
            mainPathText.setText(mainPath);
        }
    }//GEN-LAST:event_mainBrowseButtonActionPerformed

    /**
     * This method is called when the "ok" button is hit.<br>
     * It reads the fields, checks for correctnes and validity, and then starts the uploading process.<br>
     * It uploads two files to the controller:<br>
     * - The script which starts up the ethernet connection.<br>
     * - The sketch for the monitoring.<br>
     * @param evt the ActionEvent fired when the "ok" button is hit.
     */
    private void okButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okButtonActionPerformed
        comPort = comPortText.getText();
        hostIP = ipText.getText();
        hostNetMask = netMaskText.getText();
        idePath = idePathText.getText();
        mainPath = mainPathText.getText();
        
        switch(boardTypeChooser.getSelectedIndex()){
            case 0:{
                boardType = "intel:i586-uclibc:izmir_fd";
                break;
            }
            case 1:{
                boardType = "intel:i586-uclibc:izmir_fg";
            }
        }
        
        if(checkCorrectness()){
            monitorUploadScript = mainPath + "\\src\\Misc\\monitorSketch\\uploadMonitorScript.sh";
            monitorSketch = mainPath + "\\src\\Misc\\monitorSketch\\monitorSketch.elf";
            
            savePrefFile();
            JOptionPane.showMessageDialog(null, "Settings were saved to preference file");
            int choice = JOptionPane.showConfirmDialog(null, "If you would like to setup the eth. interface connection to the controller,\n"
                    + "as well as the monitor Interface, please turn-on the controller and wait for the LED near \"USB\" to turn-on,\n"
                    + "and then connect the controller by USB and press \"Yes\".\nOtherwise, hit \"No\" to return or \"Cancel\" to exit.");
            if(choice == JOptionPane.YES_OPTION){
                generateEthScript();
                try{Thread.sleep(2000);}catch(InterruptedException ie){System.err.println("okButtonActionPerformed: problem sleeping: " + ie);}
                sw.execute();
                loading.setVisible(true);
                boolean success = false;
                try{
                    success = sw.get();
                }
                catch(InterruptedException|ExecutionException iee){
                    System.err.println("sStartOrStopActPer: Problem: " + iee);
                }
                
                if(success){
                    JOptionPane.showMessageDialog(null, "Ethernet connection is set-up, as well as the monitor interface.\n"
                        + "You can now run the main app and work with the controller.\nHave a nice day :)");
                    System.exit(0);
                }
            }
            else if(choice == JOptionPane.CANCEL_OPTION){
                System.exit(0);
            }
        }
    }//GEN-LAST:event_okButtonActionPerformed

    /**
     * This method generates the ethernet script using the IP and netmask passsed from the app.
     */
    private void generateEthScript(){
        String cmd = ethScriptGen + " " + hostIP + " " + hostNetMask + " " + ethScript;
        
        try{
            Process cmdP = Runtime.getRuntime().exec(cmd);
            cmdP.waitFor();
        }
        catch(IOException|InterruptedException ioex){
            System.err.println("generateEthScript: problem: " + ioex);
        }
    }
    
    /**
     * This method uploads the passed file to the controller using the passed uploading script.
     * @param scriptToRun <code> String </code> - the uploading script.
     * @param fileToUpload <code> String </code> - the file to upload.
     * @return <code>True</code> if there were no errors during upload, <code>False</code> otherwise.
     */
    private boolean runUploadScript(String scriptToRun, String fileToUpload){
        try{
            scriptToRun = (new File(scriptToRun)).getCanonicalPath();
            fileToUpload = (new File(fileToUpload)).getCanonicalPath();
        }
        catch(IOException ioex){
            System.err.println("runUploadScript: problem: " + ioex);
            return false;
        }
        
        String cmd = idePath + binPath + "\\bash.exe " + scriptToRun + " " + idePath + binPath + " " +  fileToUpload + " COM" + comPort;
        String batCmd = uploadBatch + " \"" + cmd + "\" \"" + logPath + "\"";
        System.out.println(cmd);
        try{
            Process cmdP = Runtime.getRuntime().exec(batCmd);
            cmdP.waitFor();
            
            boolean exitVal = checkForErrorsUploading();
            if(!exitVal){
                Process errorCMD = Runtime.getRuntime().exec("cmd.exe /c start /wait " + exitQuest + " \"" + logPath + "\"");
                errorCMD.waitFor();
                return false;
            }
        }
        catch(IOException|InterruptedException ioex){
            System.err.println("runUploadScript: problem: " + ioex);
            return false;
        }        
        return true;
    }

    /**
     * This method creates the pop-up window which is used when the app uploades a sketch, or connects to monitor the analog inputs of
     * the controller.
     * @param popupTitle the <code>String</code> which appear in the window. for example: "Uploading sketch - please wait..."
     */
    private void createPopupWindow(String popupTitle){
        loading = new JDialog();
        loadingPanel = new JPanel(new BorderLayout());
        pwLabel = new JLabel(popupTitle);
        
        loadingPanel.add(pwLabel, BorderLayout.CENTER);
        loading.setUndecorated(true);
        loading.getContentPane().add(loadingPanel);
        loading.pack();
        loading.setSize(loading.getWidth(),loading.getHeight()+20);
        loading.setLocationRelativeTo(this);
        loading.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        loading.setModal(true);
        
        sw = new SwingWorker<Boolean, Void>(){
            @Override
            protected Boolean doInBackground() throws InterruptedException {
                if(!runUploadScript(ethUploadScript, ethScript)){return false;}
                return runUploadScript(monitorUploadScript, monitorSketch);
            }
            @Override
            protected void done(){
                loading.setVisible(false);
            }
        };
    }
        
    /**
     * This method checks for errors which occured during compiling or uploading the sketch.<br>
     * It reads the log file of the upload script, and if it finds certain strings (which imply that an error occured) 
     * It returns false and shows a message dialog window which states the error.
     * @return <code>True</code> if no erros were found, <code>False</code> otherwise.
     */
    private boolean checkForErrorsUploading(){
        File uploadLogFile = new File(logPath);
        String output = "";
        
        
        try (BufferedReader uLFBR = new BufferedReader(new FileReader (uploadLogFile))) {
            String line;
            while((line = uLFBR.readLine()) != null){
                output += line;
            }
        }
        catch(IOException ioex){
            System.err.println("checkForErrorsUploading: problem: " + ioex);
        }
        
        if(output.contains("No such device or address")){
            JOptionPane.showMessageDialog(null, "Check the USB connection to the controller.\nMake sure it's connected "
                    + "and to the right COM port,\nas specified in the  programs setup.");
            return false;
        }
        else if(output.contains("Permission denied")){
            JOptionPane.showMessageDialog(null, "Make sure there isn't any serial terminal running\nconnected to the controller");
            return false;
        }
        else if(output.split("Transfer complete", -1).length >= 3){
            return true;
        }
        else{
            System.out.println("Number of TC occurences: " + output.split("Transfer complete", -1).length);
            return false;
        }
        
    }    
    
    /**
     * This method saves the preference file to the main app directory,<br>
     * as well as the backup file to it's own directory.<br>
     * The backup file will be used next time the reload the preferences and allow quick modifications.
     */
    private void savePrefFile(){
        String path = mainPath + "\\src\\PrjGui\\prefSettings.txt";
        
        File save = new File(path);
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(save))){
            bw.write("ARDUINO_PATH = " + idePath + System.lineSeparator());
            bw.write("COM_PORT = COM" + comPort + System.lineSeparator());
            bw.write("BOARD = " + boardType + System.lineSeparator());
            bw.write("HOST = " + hostIP + System.lineSeparator());
        }
        catch(IOException ioex){
            System.err.println("savePrefFile: Problem: " + ioex);
        }
        
        File backup = new File(backupFilePath);
        try{
            if(!backup.exists()){backup.createNewFile();}
            Files.copy(save.toPath(), backup.toPath(), REPLACE_EXISTING);
            
            BufferedWriter bw = new BufferedWriter(new FileWriter(backup,true));
            bw.write("NETMASK = " + hostNetMask + System.lineSeparator());
            bw.write("APP_PATH = " + mainPath + System.lineSeparator());
            bw.close();
        }
        catch(IOException ioex){
            System.err.println("savePrefFile: problem:" + ioex);
        }
    }
    
    /**
     * This method checks the correctnes of the fields entered by the users.
     * If one of the fields is invalid, it will show a popup message pointing to it.
     * @return <code>True</code> if all fields are valid, <code>False</code> otherwise.
     */
    private boolean checkCorrectness(){
        String err = "";
        
        if(!checkPath(mainPath)){
            err += "Main App path - invalid path specified.\n";
        }
        if(!checkPath(idePath)){
            err += "IDE path - invalid path specified.\n";
        }
        if(!checkIfNumber(comPort)){
            err += "COM port - entry specified is not a number.\n";
        }
        if(!checkIP(hostIP)){
            err += "Board IP - invalid IP specified";
        }
        if(!checkIP(hostNetMask)){
            err += "Board NetMask - invalid IP specified";
        }
        
        if(err.length()!= 0){
            JOptionPane.showMessageDialog(null, "Problem in the following field(s):\n" + err);
            return false;
        }
        else{
            return true;
        }
    }
    
    /**
     * This method checks if the passed <code>String</code> is a valid IP.
     * @param ip the <code>String</code> containing the IP to check.
     * @return <code>True</code> if the IP is valid, <code>False</code>.
     */
    private boolean checkIP(String ip){
        return IpValidation.isIp(ip);
    }
    
    /**
     * This method checks if the passed string is a valid integer.
     * @param s the <code>String</code> containing the number to check
     * @return <code>True</code> if the number is valid, <code>False</code>.
     */
    private boolean checkIfNumber(String s){
        try{
            Integer.parseInt(s);
        }
        catch(NumberFormatException nfe){
            return false;
        }
        return true;
    }
    
    /**
     * This method checks if the passed string is an existing directory.
     * @param path the <code>String</code> containing the path.
     * @return <code>True</code> if the passed path is an existing directory, <code>False</code>.
     */
    private boolean checkPath(String path){
        File test = new File(path);
        return test.isDirectory() && test.exists();
    }
    /**
     * This is the main method starting up the app.
     * @param args the command line arguments.
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SIGG.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SIGG.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SIGG.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SIGG.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SIGG().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel boardIpPanel;
    private javax.swing.JComboBox boardTypeChooser;
    private javax.swing.JLabel boardTypeLabel;
    private javax.swing.JPanel boardTypePanel;
    private javax.swing.JButton cancelButton;
    private javax.swing.JLabel comPortLabel;
    private javax.swing.JPanel comPortPanel;
    private javax.swing.JTextField comPortText;
    private javax.swing.JPanel guiPane;
    private javax.swing.JButton ideBrowseButton;
    private javax.swing.JLabel idePathLabel;
    private javax.swing.JPanel idePathPanel;
    private javax.swing.JTextField idePathText;
    private javax.swing.JLabel ipLabel;
    private javax.swing.JTextField ipText;
    private javax.swing.JButton mainBrowseButton;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JLabel mainPathLabel;
    private javax.swing.JPanel mainPathPanel;
    private javax.swing.JTextField mainPathText;
    private javax.swing.JLabel netMaskLabel;
    private javax.swing.JTextField netMaskText;
    private javax.swing.JPanel ocPanel;
    private javax.swing.JButton okButton;
    private javax.swing.JPanel welcomePanel;
    private javax.swing.JLabel welcomeText1;
    private javax.swing.JLabel welcomeText2;
    private javax.swing.JLabel welcomeText3;
    // End of variables declaration//GEN-END:variables
    // Additional Variables declaration //////////////////////
    ///////// File chooser for selecting directories /////////
    /** File chooser used for the browsing of the ide path and the main app path */
    private JFileChooser jfc;
    /////////////////////////////////////////////////////////
    ///////// Preferences' fields /////////////////////////////////////////////
    /** preference field. <br> 
     * the fields are:<p>
     * mainPath - the path of the IGG<br>
     * idePath - the path of the Arduino IDE<br>
     * comPort - the number in the COM# the board is assigned to<br>
     * boardType - the type of the board<br>
     * hostIP - the IP address that will be given to the board<br>
     * hostNetMask - the IP address of the Network that will be given to the board<br>
     */
    private String mainPath, idePath, comPort, boardType, hostIP, hostNetMask;
    ///////////////////////////////////////////////////////////////////////////
    ///////// script and files' paths /////////////////////////////////////////
    /** the backup file from the sIGG will load the preferences next time it's run (".\\tools\\backupPrefFile.txt") */
    private final String backupFilePath = ".\\tools\\backupPrefFile.txt";
    /** the Bash script with which the sIGG downloads the network script to the board (".\\tools\\uploadNetConScript.sh") */
    private final String ethUploadScript = ".\\tools\\uploadNetConScript.sh";
    /** the Batch file that generates the network script (".\\tools\\scriptGen.bat") */
    private final String ethScriptGen = ".\\tools\\scriptGen.bat";
    /** the path of the generated network script (".\\tools\\netconDOS.sh") */
    private final String ethScript = ".\\tools\\netconDOS.sh";
    /** the path required by the download scripts ("\\hardware\\tools\\x86\\bin")*/
    private final String binPath = "\\hardware\\tools\\x86\\bin";
    /** the Batch file responsible for downloading files to the board (".\\tools\\uploadBatch.bat") */
    private final String uploadBatch = ".\\tools\\uploadBatch.bat";
    /** the Batch file which opens the output log of the download process if errors occured (".\\tools\\exitQuest.bat") */
    private final String exitQuest = ".\\tools\\exitQuest.bat";
    /** the log file to which the output of the download process is written to (".\\tools\\uploadLog.txt") */
    private final String logPath = ".\\tools\\uploadLog.txt";
    /** the path of the script which downloads the monitor sketch to the board. set at startup or when main app path is set. */
    private String monitorUploadScript; ///// will be initiated at the startup////
    /** the path of the monitor sketch. set at startup or when main app path is set. */
    private String monitorSketch;       ///// will be initiated at the startup////
    ///////////////////////////////////////////////////////////////////////////
    ///////// Components for the "waiting" popup window while uploading. //////
    /** used in the popup window*/
    private JDialog loading;
    /** the popup window every time the app downloads code to the board or when it turns the monitor sketch on */
    private JPanel loadingPanel;
    /** the title of the popup window */
    private JLabel pwLabel;
    /** used when the app downloads the network script and the monitor sketch to the board.
     pops up a wating window when thes tasks are performed.*/
    private SwingWorker<Boolean, Void> sw;
    ///////////////////////////////////////////////////////////////////////////
    // End of Additional Variables declaration ////////////////////////////////
}


/**
 * This class definition was taken from "stackoverflow" forum at:
 * stackoverflow.com/questions/4581877/validating-ipv4-string-in-java<p>
 * 
 * This class checks if a <code>String</code> is a valid IP address.
 * @author Gil Aizenshtadt
 */
class IpValidation{
    /**
     * Check that a string consists of only numbers
     * @param string The string to check
     * @return true if string consists of only numbers, false otherwise
     */
    public static boolean isNumeric(String string){
        for(char c : string.toCharArray()){
            if(c < '0' || c > '9'){
                return false;
            }
        }
        return true;
    }
    
    /**
     * This method checks the passed <code>String</code> for a vaild IP address.
     * @param string the passed <code>String</code>.
     * @return <code>True</code> if the <code>String</code> is a valid IP, <code>False</code>.
     */
    public static boolean isIp(String string){
        /** the numbers of the ip address.*/
        String parts[] = string.split("\\.",-1);
        try{
            return (parts.length == 4)&&(Arrays.stream(parts).filter(IpValidation::isNumeric).map(Integer::parseInt).filter(i -> i <= 255 && i >= 0).count()==4);
        }
        catch(NumberFormatException nfe){
            System.err.println("isIp: Problem: " + nfe);
            return false;
        }
    }
}