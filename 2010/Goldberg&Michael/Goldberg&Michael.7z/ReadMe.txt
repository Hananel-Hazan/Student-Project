Psychophysics Software Suite ( PSS )
  
Coded by: Goldberg Stanislav (317335214) and Michael Lvovsky (307016188) as a part of Haifa  University project for Dr. Karen Banai (Department of Communication Disorders) under GPL (General Public License).
 
Current folder contains: 
1. Docs       - Documentations. 
2. JavaSrc    - Java sources. 
3. MatlabSrc  - Matlab sources. 
4. Tests      - Tests. 
5. ReadMe.txt - Current file. 