
public class RtpBuffer {

	
	public RtpBuffer(int arraySize, int segmentSize, int fs)
	{
		if (arraySize % segmentSize == 0)
		{
			this.rtpArray = new double[arraySize];
			this.segmentSize = segmentSize;
			this.fs = fs;
			
		}
		
	}
	
	private double[] rtpArray;
	private int segmentSize = 0;
	private int pos = 0;
	private int fs = 0;
	private GGSpecSub temp = new GGSpecSub();
	
	public void insertSegment(double[] segment)
	{
		if (this.pos == (this.rtpArray.length )  )
		{
			//shift all the data a segment to the back
			for (int i = 0; i < (this.rtpArray.length - segment.length);i++)
			{
				this.rtpArray[i] = this.rtpArray[i + segment.length];
			}
			//copy the new segment into the front
			for (int i = 0; i < segment.length; i++)
			{
				this.rtpArray[i +(this.rtpArray.length - segment.length)] = segment[i];
			}
			
			double output[] = temp.SSBoll79(this.rtpArray,8000); //ssboll changes the size of the array
			for (int i = 0; i < output.length ; i++)
			{
				this.rtpArray[i] = output[i];
			}
			
			this.pos = (this.rtpArray.length);
			
		}
		else 
		{
			for (int i = 0 ; i < segment.length ; i++)
			{
				this.rtpArray[this.pos + i ] = segment[i];
			}
			this.pos += segment.length;
		}
		
	}
	
	public double[] getSegment()
	{
		double[] tempSegment = new double[this.segmentSize];
		for (int i = 0; i < tempSegment.length; i++)
		{
			tempSegment[i] = this.rtpArray[pos - this.segmentSize + i];
		}
		return tempSegment;
	}

	
	public short[] getBuffer()
	{
		short[] resultBuffer = new short[this.rtpArray.length];
		for(int i = 0 ; i < resultBuffer.length; i++)
		{
			resultBuffer[i] = (short) this.rtpArray[i];
		}
		return resultBuffer;
	}
	
	public double[] getBuffer1()
	{
		double[] resultBuffer = new double[this.rtpArray.length];
		for(int i = 0 ; i < resultBuffer.length; i++)
		{
			resultBuffer[i] = this.rtpArray[i];
		}
		return resultBuffer;
	}
}
