import edu.emory.mathcs.jtransforms.fft.*;
import java.io.*;

public class MyMain {

    public static void main(String[] args) {
    	 try
         {
    		File file = new File("c0dBF1_NOISY.wav");
    		File fileToWrite = new File("outputJava_c0dBF1_NOISY.wav");
            // Open the wav file specified as the first argument
            WavFile wavFile = WavFile.openWavFile(file);
            
            // Display information about the wav file
            wavFile.display();

            // Get the number of audio channels in the wav file
            int numChannels = wavFile.getNumChannels();

            // Create a buffer of 100 frames
            double[] buffer = new double[60944 * numChannels]; //was 100 turned into 70000

            int framesRead;
            int framesWrite;
            double min = Double.MAX_VALUE;
            double max = Double.MIN_VALUE;

            do
            {
               // Read frames into buffer
               framesRead = wavFile.readFrames(buffer, 60944);

               // Loop through frames and look for minimum and maximum value
              // for (int s=0 ; s<framesRead * numChannels ; s++)
              // {
              //    if (buffer[s] > max) max = buffer[s];
              //    if (buffer[s] < min) min = buffer[s];
              // }
            }
            while (framesRead != 0);
            GGSpecSub temp = new GGSpecSub();
            int fs = (int)wavFile.getSampleRate(); //should be LONG and not INT
            double[] output = temp.SSBoll79(buffer,fs);
            // Close the wavFile
            wavFile.close();
            int sampleRate = 10000;    // Samples per second
            double duration = 6.0;     // Seconds

            // Calculate the number of frames required for specified duration
            long numFrames = (long)(duration * sampleRate);

            // Create a wav file with the name specified as the first argument
           // WavFile wavFileWrite = WavFile.newWavFile(fileToWrite, numChannels, numFrames, validBits, sampleRate)
            WavFile wavFileWrite = WavFile.newWavFile(fileToWrite, 1, numFrames, 16, sampleRate);
            wavFileWrite.writeFrames(output, output.length);
            wavFileWrite.close();
            // Output the minimum and maximum value
         //   System.out.printf("Min: %f, Max: %f\n", min, max);
         }
         catch (Exception e)
         {
            System.err.println(e);
         }
      

      
    }

}