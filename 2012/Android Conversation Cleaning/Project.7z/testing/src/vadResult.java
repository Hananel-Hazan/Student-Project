
public class vadResult {

	public boolean noiseFlag;
	public boolean speechFlag;
	public int noiseCounter;
	public double dist;
	
	public vadResult(){
		this.noiseFlag = false;
		this.noiseCounter = 0;
		this.speechFlag = false;
		this.dist = 0;
	}
}
