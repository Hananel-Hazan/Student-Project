
public class MatrixAndSegments 
{

	public int numberOfSegments;
	public double[][] res;
	
	public MatrixAndSegments(int numberOfSegments,double[][] res)
	{
		this.numberOfSegments = numberOfSegments;
		this.res = res;
	}
}
