package noisecancellertester;

import NoiseCanceller.NoiseCanceller;
import NoiseCanceller.SampleBufferFromToDouble;
import WavFile.WavFile;
import java.io.File;

public class NoiseCancellerTester {

    final static private int FRAME_SIZE = 512;
    final static private int SAMPLE_RATE = 8000;

    public static void main(String[] args) {
        try {
            // Open the wav file specified as the first argument
            WavFile wavFile = WavFile.openWavFile(new File("test.wav"));

            // Display information about the wav file
            wavFile.display();

            // Create a buffer of 100 frames
            int duration = 9;
            double[] buffer = new double[FRAME_SIZE]; //was 100 turned into 70000

            long numFrames = (long) (duration * SAMPLE_RATE);
            WavFile wavFileWrite = WavFile.newWavFile(new File("OUTPUT-test.wav"), 1, numFrames, 16, SAMPLE_RATE);
            NoiseCanceller noiseCanceller = new NoiseCanceller(FRAME_SIZE, SAMPLE_RATE);
            SampleBufferFromToDouble sampleBuffer = new SampleBufferFromToDouble(noiseCanceller);
            
            for (int framesRead = 1; framesRead != 0;) {

                framesRead = wavFile.readFrames(buffer, FRAME_SIZE);

                sampleBuffer.process(buffer, 0);

                wavFileWrite.writeFrames(buffer, 0, FRAME_SIZE);
            }

            // Close the wavFile
            wavFile.close();

            // Calculate the number of frames required for specified duration
            wavFileWrite.close();

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e);
        }
    }
}
