package NoiseCanceller;

public class SampleBufferFromToDouble extends SampleBuffer {
    
    public SampleBufferFromToDouble(final NoiseCanceller nc) {
        super(nc);
    }
    
    public void process(double[] sample, int pos) {
        // where to copy our current sample to
        double[] buffer = getCurrentInputSampleBuffer();
        
        // copy sample to current sample buffer
        System.arraycopy(sample, pos, buffer, 0, sample.length);
        
        // process sample and return product (delay of 1 sample)
        double[] product = process();
        
        // overwrite original sample with product
        System.arraycopy(product, pos, sample, 0, sample.length);
    }
}
