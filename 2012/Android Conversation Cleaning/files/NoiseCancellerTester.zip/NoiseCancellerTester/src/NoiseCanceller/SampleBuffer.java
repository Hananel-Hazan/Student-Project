package NoiseCanceller;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class SampleBuffer {
    // circular double frame buffer
    LinkedList<double[]> buffers = new LinkedList<double[]>();;
    
    // algorythm implementor class
    private final NoiseCanceller nc;
    
    // we jump over first sample and return zeroes
    boolean is_first_sample = true;
    
    // half full segments during input
    List<Segment> incomplete = new LinkedList<Segment>();
    
    public SampleBuffer(final NoiseCanceller nc) {
        // keep reference to our algorythm implementor class
        this.nc = nc;
        
        // prepare buffers
        buffers.add(new double[nc.getSampleSize()]);
        buffers.add(new double[nc.getSampleSize()]);
    }
    
    protected double[] getCurrentInputSampleBuffer() {
        return buffers.getLast();
    }
    
    protected double[] process() {
        if (!is_first_sample) {
            // segmentize samples
            segmentize();
            
            // let the algorythm run & combine segments into the product if supposed to
            desegmentize(nc.process());
            
        } else is_first_sample = false;
        
        // cycle samples so on the next sample the previous sample buffer will be overwritten
        buffers.addLast(buffers.removeFirst());
        
        // return the previous sample buffer that should contain the product
        return buffers.getLast();
    }
    
    private void segmentize() {
        // copy contents of previous sample into segments
        double[] prev_sample = buffers.getFirst();
        Segment seg;
        boolean overflow = false;
        
        for (int sample_pos = 0; sample_pos < nc.getSampleSize(); sample_pos += nc.getShiftSize(), overflow = false) {
            seg = nc.getInputSegment();
            
            // fill segment with data
            for (int seg_pos = sample_pos; seg_pos < prev_sample.length && !overflow; seg_pos++)
                overflow = seg.input(prev_sample[seg_pos]);
            
            // store half full segments
            if (seg.isHalfFull()) incomplete.add(seg);
        }
        
        // last segment will be half full - fill it with data from current sample
        double[] current_sample = buffers.getLast();
        
        for (Iterator<Segment> it = incomplete.iterator(); it.hasNext(); overflow = false) {
            seg = it.next();
            seg.markInput(); // we need to know this segment has data from 2 sample buffers
            
            for (int seg_pos = 0; seg_pos < prev_sample.length && !overflow; seg_pos++, overflow = false)
                overflow = seg.input(current_sample[seg_pos]);
        }
        
        // clear incomplete list
        incomplete.clear();
    }
    
    private void desegmentize(boolean act) {
        // replace revious sample with contents of processed segments
        double[] prev_sample = buffers.getFirst();
        
        // fill buffer with zeroes
        if (act) Arrays.fill(prev_sample, 0);
        
        for (int sample_pos = 0; sample_pos < nc.getSampleSize();) {
            Segment seg = nc.getOutputSegment();
            boolean wasHalfFullSegment = seg.isSharingSampleBuffers();
            
            // fill segment with data
            try {
                for (int seg_pos = sample_pos; seg_pos < prev_sample.length; seg_pos++)
                    combineOperation(prev_sample, seg_pos, seg.output(), act);
            } catch (Exception e) {
                // we'll get here if we overflow segment buffer
            }
            
            // inbetweeners always start writing at zero
            if (!wasHalfFullSegment) sample_pos += nc.getShiftSize();
        }
    }
    
    private void combineOperation(double[] buffer, int pos, double value, boolean act) {
        // this is how we combine values (addition)
        if (act) buffer[pos] += value;
    }
}
