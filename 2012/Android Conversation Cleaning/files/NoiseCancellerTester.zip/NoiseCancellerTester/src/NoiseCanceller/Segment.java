package NoiseCanceller;

public class Segment {
    // internal buffer
    private double[] buffer, angle;
    
    // current position in buffer and original position in buffer
    private int from_pos, to_pos;
    
    public Segment(int buffer_size) {
        buffer = new double[buffer_size];
        angle = new double[buffer_size/2];
    }
    
    public void copy(Segment orig) {
        to_pos = orig.to_pos;
        from_pos = orig.from_pos;
        
        System.arraycopy(orig.buffer, 0, buffer, 0, buffer.length);
    }
    
    public void copyPos(Segment seg) {
        to_pos = seg.to_pos;
        from_pos = seg.from_pos;
    }
    
    public void clear() {
        to_pos = 0;
        from_pos = 0;
    }
    
    public void markInput() {
        from_pos = to_pos;
    }
    
    public void markOutput() {
        from_pos = 0;
    }
    
    public boolean input(double value) {
        if (to_pos < buffer.length) {
            buffer[to_pos++] = value;
            return false;
        }
        
        return true;
    }
    
    public double output() {
        return buffer[from_pos++];
    }
    
    public boolean isSharingSampleBuffers() {
        return from_pos != 0;
    }
    
    public boolean isHalfFull() {
        return to_pos != buffer.length;
    }
    
    public double[] getBuffer() {
        return buffer;
    }
    
    public double[] getAngleBuffer() {
        return angle;
    }
    
    public void mean(Segment prev, Segment current, Segment next) {
        for (int i = 0; i < buffer.length; i++) {
            buffer[i] = (prev.buffer[i] + current.buffer[i] + next.buffer[i]) / 3;
        }
    }
}
