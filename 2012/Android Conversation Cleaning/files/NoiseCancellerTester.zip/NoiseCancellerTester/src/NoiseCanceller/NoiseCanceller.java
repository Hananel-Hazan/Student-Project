package NoiseCanceller;

import edu.emory.mathcs.jtransforms.fft.DoubleFFT_1D;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;

public class NoiseCanceller {
    // vad calculation consts
    private final static int HANGOVER_CONST = 8;
    private final static double NOISE_MARGIN = 3;
    private static final int NOISE_LENGTH = 9; // NoiseLength
    
    // a constant that is used for calculating the window size
    private final static double WINDOW_SIZE_CONST = 0.032;
    
    // offset from current window where next window begins
    private final static double SHIFT_PERCENTAGE = 0.5;
    
    // period of time in the beginning of a conversation we consider noise
    private final static double NOISE_PERIOD = 0.25; // NIS
    
    // Ratio for updating noise segment
    private static final int NOISE_AVERAGE_RATIO = 9; // NoiseLength
    
    // coefficient when adding new noise segment
    private static final double BETA = 0.03;
    
    // sample properties
    private final int sample_size;
    
    // window derived properties (from sample properties and constants)
    private final int window_size;
    
    // available to use segments
    LinkedList<Segment> recycled;
    
    // currently used segments
    LinkedList<Segment> segments, preprocessed, noise, processed;
    private ArrayList<Segment> average;
    
    // the location a new window begins relative to previous window
    private final int shift_size;
    
    // claculate fft using this
    DoubleFFT_1D fft;
    
    private Segment hammingWindow, average_noise, NRM, last_in_sample = null;
    
    private int noise_segments;
    
    // convenience array for claculations
    private double[] spectralDist;
    
    // noise count of speech detection
    int noise_count;
    
    public NoiseCanceller(int sample_size, int samples_per_second) {
        this.sample_size = sample_size;
        
        window_size = (int) (samples_per_second * WINDOW_SIZE_CONST);
        shift_size = (int) (window_size * SHIFT_PERCENTAGE);
        
        segments = new LinkedList<Segment>();
        recycled = new LinkedList<Segment>();
        preprocessed = new LinkedList<Segment>();
        noise = new LinkedList<Segment>();
        processed = new LinkedList<Segment>();
        average = new ArrayList<Segment>(sample_size / shift_size + 1);
        
        // calculate number of segments for noise list
	noise_segments = (int)(NOISE_PERIOD * samples_per_second - window_size)/(shift_size) + 1;
        
        // fill recycled list with al lthe segments we might need
        for (int i = 0; i < (sample_size / shift_size + 3) * 3 + noise_segments; i++) {
            recycled.add(new Segment(window_size*2));
        }
        
        // prepare Hamming window
        hammingWindow = new Segment(window_size);
        createHammingWindow(hammingWindow.getBuffer());
        
        // initialize fft calculator
        fft = new DoubleFFT_1D(window_size);
        
        // allocate array
        spectralDist = new double[window_size/2];
        
        // initial NRM
        NRM = new Segment(window_size);
        
        // assume first segments are noise
        noise_count = noise_segments - 2;
    }
    
    public int getSampleSize() { return sample_size; }
    public int getShiftSize() { return shift_size; }

    public Segment getInputSegment() {
        // get a reusable segment
        Segment seg = recycled.removeFirst();
        
        // clear it
        seg.clear();
        
        // place segments in the to be processed segments
        segments.addLast(seg);
        
        return seg;
    }
    
    public Segment getOutputSegment() {
        // first preprocessed segments
        if (!preprocessed.isEmpty()) {
            Segment seg = preprocessed.removeFirst();
            
            // recycle segment
            recycled.add(seg);
            
            return seg;
        }
        
        // second newly processed segments
        if (!processed.isEmpty()) {
            Segment seg = processed.removeFirst();
            
            // does it contain data from 2 samples ?
            if (seg.isSharingSampleBuffers()) {
                // mark for output (from marker set to the begining)
                seg.markOutput();
                
                preprocessed.addLast(seg);
                
            } else recycled.add(seg);
            
            return seg;
        }
        
        return null;
    }
    
    public boolean process() {
        // implement algorythm here on the segements in .. segments
        Segment prev, current, next;

        // process segments
        Iterator<Segment> it, jt;
        for (it = segments.iterator(); it.hasNext();) {
            Segment seg = it.next();

            // apply Hamming window
            applyHammingWindow(seg.getBuffer(), hammingWindow.getBuffer());

            // apply FFT on the segment
            performFFT(seg.getBuffer());

            // calculate angle on FFT results
            calcAngle(seg.getBuffer(), seg.getAngleBuffer());

            // calculate absolute values
            calcABS(seg.getBuffer());

            // collect noise segment
            if (noise.size() < noise_segments) {
                Segment noise_seg = recycled.removeFirst();
                noise_seg.copy(seg);
                
                noise.addLast(noise_seg);
            }
        }

        // calculate mean for noise segments
        if (noise.size() == noise_segments) {
            average_noise = recycled.removeFirst();
            Arrays.fill(average_noise.getBuffer(), 0);
            
            calcMeanNoise(average_noise.getBuffer());

            noise_segments--;

            // if we dont have enough samples for calculating mean noise - return
        } else if (noise.size() < noise_segments) {
            // move segments to processed
            while (!segments.isEmpty())
                processed.addLast(segments.removeFirst());
            
            return false;
        }

        // prepare average segments
        /*it = segments.iterator();
        prev = it.next();
        current = it.next();
        next = it.next();

        Segment average_seg = recycled.removeFirst();
        if (last_in_sample != null) {
            average_seg.mean(last_in_sample, prev, current);
        } else average_seg.copy(prev);
        
        average.add(average_seg);
        
        average_seg = recycled.removeFirst();
        average_seg.mean(prev, current, next);

        average.add(average_seg);
        
        //fix - optimize mean between samples
        for (int i = 1; i < segments.size() - 2; i++) {
            prev = current;
            current = next;
            next = it.next();
            
            average_seg = recycled.removeFirst();
            average_seg.mean(prev, current, next);
            
            average.add(average_seg);
        }

        average_seg = recycled.removeFirst();
        average_seg.copy(next);
        if (last_in_sample == null)
            last_in_sample = recycled.removeFirst();
        last_in_sample.copy(next);
        
        average.add(average_seg);*/
        int i = 0;
        for (it = segments.iterator(); it.hasNext(); i++) {
            Segment average_seg = recycled.removeFirst(), seg = it.next();
            average_seg.copy(seg);
            average.add(average_seg);
        }
        
        // detect voice in each segment and act upon it
        for (it = segments.iterator(), i = 0; it.hasNext(); i++) {
            Segment seg = it.next(), processed_seg = recycled.remove();
            processed_seg.copyPos(seg);

            // voice in this segment ?
            if (hasSpeech(seg.getBuffer(), noise_count)) {
                if (i > 0 && i < average.size() - 2) {
                    minMaxZero(processed_seg.getBuffer(), average.get(i - 1).getBuffer(), average.get(i).getBuffer(), average.get(i + 1).getBuffer(), average_noise.getBuffer(), NRM.getBuffer());
                } else {
                    minMaxZeroSingle(processed_seg.getBuffer(), average.get(i).getBuffer(), average_noise.getBuffer());
                }
            } else {
                // Update and smooth noise
                ratioAverage(average_noise.getBuffer(), seg.getBuffer(), NOISE_LENGTH + 1, NOISE_LENGTH);

                // Update maximum noise residue
                updateMaxNRM(NRM.getBuffer(), average_noise.getBuffer(), average.get(i).getBuffer());

                addMultipliedSegment(processed_seg.getBuffer(), seg.getBuffer(), BETA);
            }

            // add a segment to the tail of processed fft list
            processed.addLast(processed_seg);
        }

        // prepare processed segments to be combined
        for (it = processed.iterator(), jt = segments.iterator(); it.hasNext();) {
            Segment processed_seg = it.next(), seg = jt.next();

            // Calculate exponent using angle (doubles the amount of data)
            performExp(processed_seg.getBuffer(), seg.getAngleBuffer());

            // flip up after conjunctive (doubles amount of data again - currently window_size amount of data)
            reverseComplexArray(processed_seg.getBuffer());

            // perform reverse fft on segments
            performInverseFFT(processed_seg.getBuffer());
        }
        
        // recycle segments
        while (!segments.isEmpty()) {
            recycled.add(segments.remove());
        }
        
        // recycle average
        for (i = average.size(); i > 0; i--)
            recycled.add(average.remove(i -1));
        
        return true;
    }
    
    private void createHammingWindow(double[] buffer) {
        for (int i = 0; i < buffer.length; i++) {
            //buffer[i] = 0.5 * (1.0 - Math.cos(2.0 * Math.PI * i / buffer.length)); // Hanning
            buffer[i] = 0.54 - 0.46 * (Math.cos(2.0 * Math.PI * i / (buffer.length - 1)));
        }
    }
    
    private void applyHammingWindow(double[] buffer, double[] hamming) {
        for (int i = 0; i < hamming.length; i++) {
            buffer[i] *= hamming[i];
        }
    }
    
    private void performFFT(double[] buffer) {
        fft.realForwardFull(buffer);
    }
    
    private void performInverseFFT(double[] buffer) {
        fft.realInverse(buffer, true);
    }
    
    private void calcAngle(double[] buffer, double[] angle) {
        // buffer[real1, img1, real2, img2, ...] -> angle[ang1, ang2, ..]
        for (int i = 0; i < angle.length; i++) {
            angle[i] = Math.atan2(buffer[i*2+1], buffer[i*2]);
        }
    }
    
    private void calcABS(double[] buffer) {
        // buffer[real1, img1, real2, img2, ...] -> buffer[abs1, abs2, ..]
        for (int i = 0; i < buffer.length / 4; i++) {
            buffer[i] = Math.sqrt(buffer[i * 2 + 1] * buffer[i * 2 + 1] + buffer[i * 2] * buffer[i * 2]);
        }
    }
    
    private void calcMeanNoise(double[] buffer) {
        double[] seg_buffer;
        for (Iterator<Segment> it = noise.iterator(); it.hasNext();) {
            seg_buffer = it.next().getBuffer();

            for (int i = 0; i < buffer.length/4; i++) {
                buffer[i] += seg_buffer[i];
            }
        }

        for (int i = 0; i < buffer.length/4; i++) {
            buffer[i] /= noise.size();
        }
    }
    
    private boolean hasSpeech(double[] buffer, int noise_count) {
        double temp, sumSpectralDist = 0, len = average_noise.getBuffer().length/4;

        for (int i = 0; i < len; i++) {
            temp = 20 * (Math.log10(buffer[i] != 0 ? buffer[i] : 0.000001) - Math.log10((average_noise.getBuffer()[i] != 0 ? average_noise.getBuffer()[i] : 0.00001)));
            spectralDist[i] = (temp < 0) ? 0 : temp;
            sumSpectralDist += spectralDist[i];
        }

        if (sumSpectralDist / len < NOISE_MARGIN) {
            noise_count++;
        } else {
            noise_count = 0;
        }

        if (noise_count > HANGOVER_CONST) {
            return false;
        } else {
            return true;
        }
    }
    
    private void minMaxZero(double[] buffer, double[] prev, double[] current, double[] next, double[] noise, double[] NRM) {
        for (int i = 0; i < NRM.length; i++) {
            buffer[i] = current[i] - noise[i];
            
            if (buffer[i] < NRM[i])
                buffer[i] = Math.min(next[i] - noise[i], Math.min(buffer[i], prev[i] - noise[i]));
            
            buffer[i] = Math.max(0, buffer[i]);
        }
    }
    
    private void minMaxZeroSingle(double[] buffer, double[] current, double[] noise) {
        for (int i = 0; i < current.length; i++) {
            buffer[i] = Math.max(0, current[i] - noise[i]);
        }
    }
    
    private void ratioAverage(double[] noise, double[] original, int total, int part) {
        for (int i = 0; i < noise.length/4; i++) {
            noise[i] = (original[i] * (total - part) + noise[i] * part) / total;
        }
    }
    
    private void updateMaxNRM(double[] buffer, double[] average_noise, double[] noise) {
        double temp;

        for (int i = 0; i < buffer.length/2; i++) {
            temp = noise[i] - average_noise[i];
            buffer[i] = (buffer[i] > temp ? buffer[i] : temp);
        }
    }
    
    private void addMultipliedSegment(double[] buffer, double[] original, double N) {
        for (int i = 0; i < buffer.length / 4; i++) {
            buffer[i] = original[i] * N;
        }
    }
    
    private void performExp(double[] buffer, double[] angle) {
        for (int i = buffer.length / 4 - 1; i >= 0; i--) {
            buffer[i * 2] = buffer[i] * Math.cos(angle[i]);
            buffer[i * 2 + 1] = buffer[i] * Math.sin(angle[i]) * -1;
        }

        buffer[1] *= -1;
    }

    private void reverseComplexArray(double[] buffer) {
        double temp;

        for (int i = 0; i < buffer.length / 2; i++, i++) {
            temp = buffer[i];
            buffer[i] = buffer[buffer.length - i - 2];
            buffer[buffer.length - i - 2] = temp;

            temp = buffer[i + 1];
            buffer[i + 1] = buffer[buffer.length - i - 1];
            buffer[buffer.length - i - 1] = temp;
        }
    }
}
